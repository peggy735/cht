/* eslint-disable no-undef */
/* global jQuery */

/*
 * esecure
 * author ben
 * modify zoe
 * varsion 1.0.1
 * date 20241118
 */

class CTCBWebATMWinCtrl {
  constructor() {
    /*debug*/
    this.debug = true
    /*依元件名稱做調整*/
    this.appName = 'CTCBWEBATM.CTCBWebATMCtrl.1'
    /*post server*/
    this.sendUrl = 'https://localhost'
    /*wrapper listen port*/
    this.listenPort = ''
    /*依元件名稱做調整*/
    this.action = 'Activex'
    //設定交易timeout
    this.SetTimeout = 30
    /*設定元件啟用的錯誤訊息*/
    this.startErrMsg = '請確認是否已啟動AP程式及元件註冊'
    /*ajax通訊的錯誤代碼*/
    let ajaxReturnCode = '0'
    /*呼叫AP時的回傳結果*/
    let wrapperReturnCode = '0'
    /*呼叫AP的 error code list*/
    //var errorCodeList = [];
    /*bind port list*/
    const listenPortData = ['48220', '48221', '48222']

    /*error msg List */
    const errorCodeList = {
      1048577: '無法與安控程式連接，請確認安控程式是否正常啟動',
      1048578: '安控程式無提供此功能介面',
      1048579: '安控程式出現錯誤',
      1048580: '與安控服務連接逾時',
      1048581: '與安控連線中斷',
      1048582: '發生未知錯誤',
      1048583: '與安控服務認證失敗',
      1048584: '此為不合法請求，請執行登出後，關閉瀏覽器，再進行測試',
      1048608: '發生未知錯誤'
    }

    const tiemMethodList = {
      AboutBox: 210,
      AccountInquiry: 210,
      AccountPayment: 210,
      AccountPayTax: 210,
      AccountTransfer: 210,
      AccountWithdraw: 210,
      AccountInquiryEx: 210,
      AccountPaymentEx: 210,
      AccountPayTaxEx: 210,
      AccountTransferEx: 210,
      AccountWithdrawEx: 210,
      AccountInquiryEx2: 210,
      AccountPaymentEx2: 210,
      AccountPayTaxEx2: 210,
      AccountTransferEx2: 210,
      AccountWithdrawEx2: 210,
      AccountInquiryEx3: 210,
      AccountInquiryEx3Acc: 210,
      AccountPaymentEx3: 210,
      AccountPayTaxEx3: 210,
      AccountTransferEx3: 210,
      AccountWithdrawEx3: 210,
      AccountInquirySnd: 210,
      AccountPaymentSnd: 210,
      AccountPayTaxSnd: 210,
      AccountTransferSnd: 210,
      AccountWithdrawSnd: 210,
      AccountPurchaseSnd: 210,
      AccountInquirySndEx: 210,
      AccountPaymentSndEx: 210,
      AccountPayTaxSndEx: 210,
      AccountTransferSndEx: 210,
      AccountWithdrawSndEx: 210,
      AccountPurchaseSndEx: 210,
      AccountInquirySndEx2: 210,
      AccountPaymentSndEx2: 210,
      AccountPayTaxSndEx2: 210,
      AccountTransferSndEx2: 210,
      AccountWithdrawSndEx2: 210,
      AccountPurchaseSndEx2: 210,
      AccountInquirySndEx3: 210,
      AccountPaymentSndEx3: 210,
      AccountPayTaxSndEx3: 210,
      AccountTransferSndEx3: 210,
      AccountWithdrawSndEx3: 210,
      AccountPurchaseSndEx3: 210,
      SetupSMSOTP: 210,
      SetupSMSOTPSnd: 210,
      SetupNetAccount: 210,
      SetupNetAccountSnd: 210,
      SetupCommAccount: 210,
      SetupCommAccountSnd: 210,
      TransferProc: 210,
      TransferProcSnd: 210,

      /** 交易-無障礙 */
      AccountInquiryEx2Acc: 210,
      AccountInquirySndEx2Acc: 210,
      AccountInquirySndEx3Acc: 210,
      AccountPaymentEx3Acc: 210,
      AccountPaymentSndEx3Acc: 210,
      AccountPayTaxEx3Acc: 210,
      AccountPayTaxSndEx3Acc: 210,
      AccountTransferAcc: 210,
      AccountTransferEx2Acc: 210,
      AccountTransferEx3Acc: 210,
      AccountTransferSndAcc: 210,
      AccountTransferSndEx2Acc: 210,
      AccountTransferSndEx3Acc: 210,

      /**網銀相關 - 無障礙 */
      SetupSMSOTPAcc: 210,
      SetupSMSOTPSndAcc: 210,
      SetupNetAccountAcc: 210,
      SetupNetAccountSndAcc: 210,
      TransferProcAcc: 210,
      TransferProcSndAcc: 210,
      TransferNetProcAcc: 210,
      TransferNetProcSndAcc: 210,

      /** 新增 API */
      TransferNetProc: 210,
      TransferNetProcSnd: 210,

      // 常用帳號 - 無障礙
      SetupCommAccountAcc: 210,
      SetupCommAccountSndAcc: 210
    }

    const that = this

    /*-------------------------------------init---------------------------------------*/
    let component = ''
    init()
    /*-------------------------------------init---------------------------------------*/
    /*------------------------------------common--------------------------------------*/
    this.getReturnCode = function getReturnCode() {
      const getReturnCode = {
        ajaxReturnCode: ajaxReturnCode,
        wrapperReturnCode: wrapperReturnCode
      }
      return getReturnCode
    }

    function PrintLog(title, message) {
      /*var ifrmLog = document.getElementById("divLog");
            if(typeof(ifrmLog)=="object"){
                //ifrmLog = ifrmLog.contentWindow || ifrmLog.contentDocument.document || ifrmLog.contentDocument;
                //ifrmLog.document.open();
                //ifrmLog.document.write("["+ParseDateToStr(new Date)+"]["+title+"] " + message + "<br>");
                //ifrmLog.document.close();
                ifrmLog.innerHTML += "["+ParseDateToStr(new Date)+"]["+title+"] " + message + "<br>";
            }*/
      try {
        console.log('[' + ParseDateToStr(new Date()) + '][' + title + '] ' + message)
      } catch (e) {
        //alert("PrintLog:\n["+ParseDateToStr(new Date)+"]["+title+"] " + message+"");
      }
    }

    function ParseDateToStr(Now) {
      const strYear = Now.getFullYear().toString()
      const iMonth = Now.getMonth() + 1
      let strMonth = iMonth.toString()
      if (strMonth.length < 2) strMonth = '0' + strMonth
      let strDay = Now.getDate().toString()
      if (strDay.length < 2) strDay = '0' + strDay
      let strHour = Now.getHours().toString()
      if (strHour.length < 2) strHour = '0' + strHour
      let strMinute = Now.getMinutes().toString()
      if (strMinute.length < 2) strMinute = '0' + strMinute
      let strSecond = Now.getSeconds().toString()
      if (strSecond.length < 2) strSecond = '0' + strSecond
      const strMilliSecond = Now.getMilliseconds().toString()
      return (
        strYear +
        '/' +
        strMonth +
        '/' +
        strDay +
        ' ' +
        strHour +
        ':' +
        strMinute +
        ':' +
        strSecond +
        '.' +
        strMilliSecond
      )
    }

    function init() {
      //document.cookie =  'RequestToken=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
      PrintLog('strat send port', '')

      try {
        let returnData = null

        for (let i = 0; i < listenPortData.length; i++) {
          ajaxReturnCode = '0'
          wrapperReturnCode = '0'
          returnData = sendFunc(
            that.sendUrl + ':' + listenPortData[i] + '/Server',
            '',
            '',
            '',
            that.debug,
            null,
            null,
            null
          )
          ajaxReturnCode = ajaxReturnCode_
          wrapperReturnCode = wrapperReturnCode_

          if (ajaxReturnCode == '0') {
            that.listenPort = listenPortData[i]
            component = returnData.data
            that.sendUrl += ':' + that.listenPort + '/main'
            if (component == 'eSECUREApplet') {
              that.appName = ''
              that.action = 'applet'
              if (LoadJar() != '0') {
                return false
              }
            }

            console.log('Success:', returnData)
            return
          } else if (returnData.ajaxReturnCode == '1048585') {
            return
          }
        }
      } catch (e) {
        console.log('e', e) //alert("read list port failure");
      }
    }

    function getPort(setPort, returnData) {
      if (returnData.returnValue == '0') {
        that.listenPort = setPort
        component = returnData.data

        that.sendUrl += ':' + that.listenPort + '/main'

        if (component == 'eSECUREApplet') {
          that.appName = ''
          that.action = 'applet'
          //alert("執行eSECUREApplet");
          if (LoadJar() != '0') {
            //alert("Load jar 失敗")
            return false
          }
        } else if (component == 'eSECUREActiveX') {
        }
      }
    }

    function padLeft(str, len) {
      str = ''
      ;+str
      return str.length >= len ? str : new Array(len - str.length + 1).join('0') + str
    }

    function checkTimeout(methodName) {
      let timeoutVal = 0

      for (const j in tiemMethodList) {
        const sub_key = j
        const sub_val = tiemMethodList[j]

        if (sub_key == methodName) {
          timeoutVal = sub_val
        }
      }

      return timeoutVal
    }

    async function callMethodP1(Dispatch, MethodName, Parameters, callBackMethod) {
      // Dispatch
      // DISPATCH_METHOD         0x1
      // DISPATCH_PROPERTYGET    0x2
      // DISPATCH_PROPERTYPUT    0x4
      // DISPATCH_PROPERTYPUTREF 0x8
      let timeout = checkTimeout(MethodName)

      if (timeout != 0) {
        const indexVal = Parameters.indexOf('InsertFlag')

        if (indexVal != -1) {
          const cleanParameters = '[' + Parameters.replace(/[\n\r]+/g, '\\n') + ']'

          const parametersObj = JSON.parse(cleanParameters)
          console.log('Parsed JSON object:', parametersObj)

          for (let i = 0; i < parametersObj.length; i++) {
            if (parametersObj[i].ParameterName == 'InsertFlag') {
              if (parametersObj[i].DataValue.Value == '2') {
                timeout = null
              }
            }
          }
        }
      }

      ajaxReturnCode = '0'
      wrapperReturnCode = '0'
      const paramStr =
        '{"Dispatch":' +
        Dispatch +
        ',"MethodName":"' +
        MethodName +
        '","Parameters":[' +
        Parameters +
        ']}'
      const returnData = await sendFunc(
        that.sendUrl,
        that.action,
        that.appName,
        paramStr,
        that.debug,
        timeout,
        callBackMethod
      )
      console.log('returnData', returnData)
      ajaxReturnCode = returnData.ajaxReturnCode_
      wrapperReturnCode = wrapperReturnCode_
      return returnData
    }

    /*------------------------------------common--------------------------------------*/
    this.releaseActivex = function () {
      const returnData = sendFunc(
        that.sendUrl,
        'ReleaseActivex',
        that.appName,
        '',
        that.debug,
        null,
        null,
        null
      )
      if (returnData == '1048585') {
        sendFunc(that.sendUrl, that.action, that.appName, 'ReStart', that.debug, null, null, null)
      }
    }

    this.restartWrapper = function () {
      sendFunc(that.sendUrl, that.action, that.appName, 'ReStart', that.debug, null, null, null)
    }

    this.ListReaders = function () {
      return callMethodP1(1, 'ListReaders', '')
    }

    this.GetReaderNumber = function () {
      return callMethodP1(1, 'GetReaderNumber', '')
    }

    this.GetReaderName = function (Offset) {
      let paramStr = ''
      if (Offset.length === 0) Offset = 0
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Offset","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Offset +
        '}}'
      return callMethodP1(1, 'GetReaderName', paramStr)
    }

    this.ConnectReader = function (pReaderName) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}'
      return callMethodP1(1, 'ConnectReader', paramStr)
    }

    this.ConnectCard = function (pReaderName) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}'
      return callMethodP1(1, 'ConnectCard', paramStr)
    }

    this.DisconnectReader = function (pReaderName) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}'
      return callMethodP1(1, 'DisconnectReader', paramStr)
    }

    this.ReConnectCard = function (pReaderName, reset_flag) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"reset_flag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        reset_flag +
        '}}'
      return callMethodP1(1, 'ReConnectCard', paramStr)
    }

    this.GetCardStatus = function () {
      return callMethodP1(1, 'GetCardStatus', '')
    }

    this.GetReaderStatus = function (pReaderName, AttribID) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"AttribID","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        AttribID +
        '}}'
      return callMethodP1(1, 'GetReaderStatus', paramStr)
    }

    this.ListReadersAndCards = function () {
      return callMethodP1(1, 'ListReadersAndCards', '')
    }

    this.ListReadersOnly = function () {
      return callMethodP1(1, 'ListReadersOnly', '')
    }

    this.ListEF1001Accounts = function () {
      return callMethodP1(1, 'ListEF1001Accounts', '')
    }

    this.GetEF1001Account = function (AccountNo) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"AccountNo","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        AccountNo +
        '}}'
      return callMethodP1(1, 'GetEF1001Account', paramStr)
    }

    this.GetEF1001TotalAccounts = function () {
      return callMethodP1(1, 'GetEF1001TotalAccounts', '')
    }

    this.ListEF1002Accounts = function () {
      return callMethodP1(1, 'ListEF1002Accounts', '')
    }

    this.GetEF1002Account = function (AccountNo) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"AccountNo","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        AccountNo +
        '}}'
      return callMethodP1(1, 'GetEF1002Account', paramStr)
    }

    this.GetEF1002TotalAccounts = function () {
      return callMethodP1(1, 'GetEF1002TotalAccounts', '')
    }

    this.GetIssuerBank = function () {
      return callMethodP1(1, 'GetIssuerBank', '')
    }

    this.GetICCRemark = function () {
      return callMethodP1(1, 'GetICCRemark', '')
    }

    this.ReadCardSN = function () {
      return callMethodP1(1, 'ReadCardSN', '')
    }

    this.VerifyPIN = function (pPwdStr) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPwdStr","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPwdStr +
        '"}}'
      return callMethodP1(1, 'VerifyPIN', paramStr)
    }

    this.ChangePIN = function (
      pReaderName,
      pOldPwdStr,
      pNewPwdStr,
      pCardSerialNo,
      VerifyFlag,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pOldPwdStr","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pOldPwdStr +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pNewPwdStr","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pNewPwdStr +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"VerifyFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        VerifyFlag +
        '}}'
      return callMethodP1(1, 'ChangePIN', paramStr, callBackMethod)
    }

    this.GetRespSNUM = function () {
      return callMethodP1(1, 'GetRespSNUM', '')
    }

    this.GetRespTAC = function () {
      return callMethodP1(1, 'GetRespTAC', '')
    }

    this.GetRespDateTime = function () {
      return callMethodP1(1, 'GetRespDateTime', '')
    }

    this.VerifyRN1andGenerateRN2 = function (RN1Len, pCpukEncryptedRN1, DsigLen, pSprkSignRN1) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RN1Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        RN1Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncryptedRN1","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncryptedRN1 +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"DsigLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        DsigLen +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSprkSignRN1","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSprkSignRN1 +
        '"}}'
      return callMethodP1(1, 'VerifyRN1andGenerateRN2', paramStr)
    }

    this.getEncryptRN2 = function () {
      return callMethodP1(1, 'GetEncryptRN2', '')
    }

    this.getEncryptHashRN2 = function () {
      return callMethodP1(1, 'GetEncryptHashRN2', '')
    }

    this.getSessionKeyHash = function () {
      return callMethodP1(1, 'GetSessionKeyHash', '')
    }

    this.VerifySessionKeyHash = function (pCpukEncSessionKey, pSessionKeyHash) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}'
      return callMethodP1(1, 'VerifySessionKeyHash', paramStr)
    }

    this.DESEncipher = function (pSessionKeyHash, pCpukEncSessionKey, DataLen, pData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"DataLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        DataLen +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pData +
        '"}}'
      return callMethodP1(1, 'DESEncipher', paramStr)
    }

    this.DESDecipher = function (pSessionKeyHash, pCpukEncSessionKey, DataLen, pData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"DataLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        DataLen +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pData +
        '"}}'
      return callMethodP1(1, 'DESDecipher', paramStr)
    }

    this.ConvertHexToInt = function (inLength, pInval) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"inLength","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        inLength +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pInval","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pInval +
        '"}}'
      return callMethodP1(1, 'ConvertHexToInt', paramStr)
    }

    this.ConvertIntToHex = function (inLength, pInval) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"inLength","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        inLength +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pInval","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pInval +
        '"}}'
      return callMethodP1(1, 'ConvertIntToHex', paramStr)
    }

    this.DES = function (Opflag, KeyLen, KeyVal, inData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Opflag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Opflag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"KeyLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        KeyLen +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"KeyVal","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        KeyVal +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"inData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        inData +
        '"}}'
      return callMethodP1(1, 'DES', paramStr)
    }

    this.MAC = function (KeyLen, KeyVal, ICV, inLen, inData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"KeyLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        KeyLen +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"KeyVal","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        KeyVal +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"ICV","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        ICV +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"inLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        inLen +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"inData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        inData +
        '"}}'
      return callMethodP1(1, 'MAC', paramStr)
    }

    this.GetAPIVersion = function () {
      return callMethodP1(1, 'GetAPIVersion', '')
    }

    this.DisconnectCard = function (pReaderName) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}'
      return callMethodP1(1, 'DisconnectCard', paramStr)
    }

    this.GetRespData = function () {
      return callMethodP1(1, 'GetRespData', '')
    }

    this.GetRespLength = function () {
      return callMethodP1(1, 'GetRespLength', '')
    }

    this.GetLastError = function () {
      return callMethodP1(1, 'GetLastError', '')
    }

    this.AccountInquiry = function (
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountInquiry', paramStr)
    }

    this.AccountPayment = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPayment', paramStr)
    }

    this.AccountPayTax = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPayTax', paramStr)
    }

    this.AccountTransfer = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountTransfer', paramStr)
    }

    this.AccountWithdraw = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountWithdraw', paramStr)
    }

    this.AccountInquiryEx = function (
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountInquiryEx', paramStr)
    }

    this.AccountPaymentEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPaymentEx', paramStr)
    }

    this.AccountPayTaxEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPayTaxEx', paramStr)
    }

    this.AccountTransferEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountTransferEx', paramStr)
    }

    this.AccountWithdrawEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountWithdrawEx', paramStr)
    }

    this.AccountInquiryEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountInquiryEx2', paramStr)
    }

    this.AccountPaymentEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPaymentEx2', paramStr)
    }

    this.AccountPayTaxEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPayTaxEx2', paramStr)
    }

    this.AccountTransferEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountTransferEx2', paramStr)
    }

    this.AccountWithdrawEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountWithdrawEx2', paramStr)
    }

    this.AccountInquiryEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountInquiryEx3', paramStr, callBackMethod)
    }

    this.AccountInquiryEx3Acc = function (
      pReaderName,
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountInquiryEx3Acc', paramStr, callBackMethod)
    }

    this.AccountPaymentEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPaymentEx3', paramStr, callBackMethod)
    }

    this.AccountPayTaxEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPayTaxEx3', paramStr, callBackMethod)
    }

    this.AccountTransferEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountTransferEx3', paramStr, callBackMethod)
    }

    this.AccountWithdrawEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountWithdrawEx3', paramStr)
    }

    this.CheckCardInsert = function (pReaderName) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}'
      return callMethodP1(1, 'CheckCardInsert', paramStr)
    }

    this.ListWinscardInfo = function () {
      return callMethodP1(1, 'ListWinscardInfo', '')
    }

    this.GetWinscardProperty = function (ListNo) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"ListNo","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        ListNo +
        '}}'
      return callMethodP1(1, 'GetWinscardProperty', paramStr)
    }

    this.ListEF1001AccountString = function () {
      return callMethodP1(1, 'ListEF1001AccountString', '')
    }

    this.ListEF1002AccountString = function () {
      return callMethodP1(1, 'ListEF1002AccountString', '')
    }

    this.AccountPurchase = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pStoreID,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pStoreID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pStoreID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPurchase', paramStr)
    }

    this.AccountPurchaseEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pStoreID,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pStoreID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pStoreID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPurchaseEx', paramStr)
    }

    this.AccountPurchaseEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pStoreID,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pStoreID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pStoreID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPurchaseEx2', paramStr)
    }

    this.AccountPurchaseEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pStoreID,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pStoreID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pStoreID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPurchaseEx3', paramStr)
    }

    this.VerifyPINSnd = function () {
      return callMethodP1(1, 'VerifyPINSnd', '')
    }

    this.ChangePINSnd = function (pReaderName, pCardSerialNo, VerifyFlag, callBackMethod) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"VerifyFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        VerifyFlag +
        '}}'
      return callMethodP1(1, 'ChangePINSnd', paramStr, callBackMethod)
    }

    this.AccountInquirySnd = function (
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountInquirySnd', paramStr)
    }

    this.AccountPaymentSnd = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPaymentSnd', paramStr)
    }

    this.AccountPayTaxSnd = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPayTaxSnd', paramStr)
    }

    this.AccountTransferSnd = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountTransferSnd', paramStr)
    }

    this.AccountWithdrawSnd = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountWithdrawSnd', paramStr)
    }

    this.AccountPurchaseSnd = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pStoreID,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pStoreID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pStoreID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPurchaseSnd', paramStr)
    }

    this.AccountInquirySndEx = function (
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountInquirySndEx', paramStr)
    }

    this.AccountPaymentSndEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPaymentSndEx', paramStr)
    }

    this.AccountPayTaxSndEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPayTaxSndEx', paramStr)
    }

    this.AccountTransferSndEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountTransferSndEx', paramStr)
    }

    this.AccountWithdrawSndEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountWithdrawSndEx', paramStr)
    }

    this.AccountPurchaseSndEx = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pStoreID,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pStoreID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pStoreID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPurchaseSndEx', paramStr)
    }

    this.AccountInquirySndEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountInquirySndEx2', paramStr)
    }

    this.AccountPaymentSndEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPaymentSndEx2', paramStr)
    }

    this.AccountPayTaxSndEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPayTaxSndEx2', paramStr)
    }

    this.AccountTransferSndEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountTransferSndEx2', paramStr)
    }

    this.AccountWithdrawSndEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountWithdrawSndEx2', paramStr)
    }

    this.AccountPurchaseSndEx2 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pStoreID,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pStoreID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pStoreID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountPurchaseSndEx2', paramStr)
    }

    this.AccountInquirySndEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountInquirySndEx3', paramStr, callBackMethod)
    }

    this.AccountPaymentSndEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPaymentSndEx3', paramStr, callBackMethod)
    }

    this.AccountPayTaxSndEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPayTaxSndEx3', paramStr, callBackMethod)
    }

    this.AccountTransferSndEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountTransferSndEx3', paramStr, callBackMethod)
    }

    this.AccountWithdrawSndEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountWithdrawSndEx3', paramStr)
    }

    this.AccountPurchaseSndEx3 = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pStoreID,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pSessionKeyHash,
      pCpukEncSessionKey
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pStoreID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pStoreID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPurchaseSndEx3', paramStr)
    }

    this.SetupSMSOTP = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pPassword,
      pSessionID,
      pEncURL,
      pTransactionCode,
      pFdChkCode,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}'
      return callMethodP1(1, 'SetupSMSOTP', paramStr, callBackMethod)
    }

    this.SetupSMSOTPSnd = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pSessionID,
      pEncURL,
      pTransactionCode,
      pFdChkCode,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}'
      return callMethodP1(1, 'SetupSMSOTPSnd', paramStr, callBackMethod)
    }

    this.SetupNetAccount = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pPassword,
      pSessionID,
      pEncURL,
      pTransactionCode,
      pFdChkCode,
      pID,
      pDateBirth,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pDateBirth","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pDateBirth +
        '"}}'
      return callMethodP1(1, 'SetupNetAccount', paramStr, callBackMethod)
    }

    this.SetupNetAccountSnd = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pSessionID,
      pEncURL,
      pTransactionCode,
      pFdChkCode,
      pID,
      pDateBirth,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}},'
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pID +
        '"}},'
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pDateBirth","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pDateBirth +
        '"}}'
      return callMethodP1(1, 'SetupNetAccountSnd', paramStr, callBackMethod)
    }

    this.SetupCommAccount = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pPassword,
      pSessionID,
      pBankCodeList,
      pCommAccountList,
      pEncURL,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pBankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pBankCodeList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCommAccountList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCommAccountList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}'
      return callMethodP1(1, 'SetupCommAccount', paramStr, callBackMethod)
    }

    this.SetupCommAccountSnd = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pSessionID,
      pBankCodeList,
      pCommAccountList,
      pEncURL,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pBankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pBankCodeList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCommAccountList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCommAccountList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}'
      return callMethodP1(1, 'SetupCommAccountSnd', paramStr, callBackMethod)
    }

    this.TransferProc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pPassword,
      SessionID,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      pShowMsg,
      BankCodeList,
      CommAccountList,
      pEncURL,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"SessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        SessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        BankCodeList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        CommAccountList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}'
      return callMethodP1(1, 'TransferProc', paramStr, callBackMethod)
    }

    this.TransferProcSnd = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      SessionID,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      pShowMsg,
      BankCodeList,
      CommAccountList,
      pEncURL,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"SessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        SessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        BankCodeList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        CommAccountList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}'
      return callMethodP1(1, 'TransferProcSnd', paramStr, callBackMethod)
    }

    this.GetInBankCode = function () {
      return callMethodP1(1, 'GetInBankCode', '')
    }

    this.FiscTransmit = function (inLength, inData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"inLength","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        inLength +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"inData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        inData +
        '"}}'
      return callMethodP1(1, 'FiscTransmit', paramStr)
    }

    this.FiscCreateFile = function (inData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"inData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        inData +
        '"}}'
      return callMethodP1(1, 'FiscCreateFile', paramStr)
    }

    this.FiscSelectParentDF = function () {
      return callMethodP1(1, 'FiscSelectParentDF', '')
    }

    this.FiscSelectParentDFWithHeader = function () {
      return callMethodP1(1, 'FiscSelectParentDFWithHeader', '')
    }

    this.FiscSelectDF = function (DF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"DF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        DF +
        '"}}'
      return callMethodP1(1, 'FiscSelectDF', paramStr)
    }

    this.FiscSelectDFWithHeader = function (DF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"DF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        DF +
        '"}}'
      return callMethodP1(1, 'FiscSelectDFWithHeader', paramStr)
    }

    this.FiscSelectEF = function (EF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"EF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        EF +
        '"}}'
      return callMethodP1(1, 'FiscSelectEF', paramStr)
    }

    this.FiscSelectEFWithHeader = function (EF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"EF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        EF +
        '"}}'
      return callMethodP1(1, 'FiscSelectEFWithHeader', paramStr)
    }

    this.FiscLockDF = function () {
      return callMethodP1(1, 'FiscLockDF', '')
    }

    this.FiscUnlockDF = function (DF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"DF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        DF +
        '"}}'
      return callMethodP1(1, 'FiscUnlockDF', paramStr)
    }

    this.FiscReadRecord = function (RecID) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RecID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        RecID +
        '"}}'
      return callMethodP1(1, 'FiscReadRecord', paramStr)
    }

    this.FiscReadAllRecordS = function (RecID, InLe) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RecID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        RecID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InLe","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InLe +
        '}}'
      return callMethodP1(1, 'FiscReadAllRecordS', paramStr)
    }

    this.FiscReadAllRecordE = function (RecID, InLe) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RecID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        RecID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InLe","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InLe +
        '}}'
      return callMethodP1(1, 'FiscReadAllRecordE', paramStr)
    }

    this.FiscWriteRecord = function (RecLen, RecData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RecLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        RecLen +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RecData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        RecData +
        '"}}'
      return callMethodP1(1, 'FiscWriteRecord', paramStr)
    }

    this.FiscWriteRecordWithTAC = function (Kq, IV, RecID, RecLen, Data) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Kq","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Kq +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"IV","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        IV +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RecID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        RecID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RecLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        RecLen +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Data","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Data +
        '"}}'
      return callMethodP1(1, 'FiscWriteRecordWithTAC', paramStr)
    }

    this.FiscUpdateRecord = function (RecN, Len, Data) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"RecN","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        RecN +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Data","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Data +
        '"}}'
      return callMethodP1(1, 'FiscUpdateRecord', paramStr)
    }

    this.FiscEraseEF = function () {
      return callMethodP1(1, 'FiscEraseEF', '')
    }

    this.FiscBinaryAdd = function (Len, Data) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Data","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Data +
        '"}}'
      return callMethodP1(1, 'FiscBinaryAdd', paramStr)
    }

    this.FiscVerifyPIN = function (PINCode) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"PINCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        PINCode +
        '"}}'
      return callMethodP1(1, 'FiscVerifyPIN', paramStr)
    }

    this.FiscGenerateRandomNumber = function () {
      return callMethodP1(1, 'FiscGenerateRandomNumber', '')
    }

    this.FiscTerminalAuthentication = function (KID, EncData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"KID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        KID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"EncData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        EncData +
        '"}}'
      return callMethodP1(1, 'FiscTerminalAuthentication', paramStr)
    }

    this.FiscUnlockKey = function (EFID) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"EFID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        EFID +
        '"}}'
      return callMethodP1(1, 'FiscUnlockKey', paramStr)
    }

    this.FiscUnlockPIN = function () {
      return callMethodP1(1, 'FiscUnlockPIN', '')
    }

    this.FiscCardAuthentication = function (Kq, R1, R3) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Kq","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Kq +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"R1","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        R1 +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"R3","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        R3 +
        '"}}'
      return callMethodP1(1, 'FiscCardAuthentication', paramStr)
    }

    this.FiscReadBinary = function () {
      return callMethodP1(1, 'FiscReadBinary', '')
    }

    this.FiscSetSessionKey = function (Kq, Rand) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Kq","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Kq +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Rand","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Rand +
        '"}}'
      return callMethodP1(1, 'FiscSetSessionKey', paramStr)
    }

    this.FiscUpdateRecordCiphered = function (Len, EncData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"EncData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        EncData +
        '"}}'
      return callMethodP1(1, 'FiscUpdateRecordCiphered', paramStr)
    }

    this.FiscWriteRecordWithSNUMTAC = function (EFID, Len, Data) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"EFID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        EFID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Data","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Data +
        '"}}'
      return callMethodP1(1, 'FiscWriteRecordWithSNUMTAC', paramStr)
    }

    this.FiscReadData = function (P1, P2, rLen) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"P1","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        P1 +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"P2","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        P2 +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"rLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        rLen +
        '}}'
      return callMethodP1(1, 'FiscReadData', paramStr)
    }

    this.FiscUpdateData = function (P1, P2, Len, BData) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"P1","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        P1 +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"P2","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        P2 +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"BData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        BData +
        '"}}'
      return callMethodP1(1, 'FiscUpdateData', paramStr)
    }

    this.FiscListFile = function () {
      return callMethodP1(1, 'FiscListFile', '')
    }

    this.FiscSelectAppletID = function (Len, AppletID) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"AppletID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        AppletID +
        '"}}'
      return callMethodP1(1, 'FiscSelectAppletID', paramStr)
    }

    this.FiscSVCCreatePurseFile = function (Len, PEF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"PEF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        PEF +
        '"}}'
      return callMethodP1(1, 'FiscSVCCreatePurseFile', paramStr)
    }

    this.FiscSVCGetInfoWithRn = function (PEF_ID, rLen) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"PEF_ID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        PEF_ID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"rLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        rLen +
        '}}'
      return callMethodP1(1, 'FiscSVCGetInfoWithRn', paramStr)
    }

    this.FiscSVCLoading = function (PEF, LV, AData_Len, AData, LTAC) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"PEF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        PEF +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LV","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        LV +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"AData_Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        AData_Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"AData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        AData +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LTAC","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        LTAC +
        '"}}'
      return callMethodP1(1, 'FiscSVCLoading', paramStr)
    }

    this.FiscSVCDeduct = function (PEF, DV, AData_Len, AData, DTAC, rLen) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"PEF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        PEF +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"DV","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        DV +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"AData_Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        AData_Len +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"AData","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        AData +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"DTAC","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        DTAC +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"rLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        rLen +
        '}}'
      return callMethodP1(1, 'FiscSVCDeduct', paramStr)
    }

    this.FiscSVCReserval = function () {
      return callMethodP1(1, 'FiscSVCReserval', '')
    }

    this.FiscSVCUpdateKey = function (Type, Block, Ccode) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Type","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Type +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Block","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Block +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"Ccode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        Ccode +
        '"}}'
      return callMethodP1(1, 'FiscSVCUpdateKey', paramStr)
    }

    this.FiscSVCReadBalance = function (PEF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"PEF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        PEF +
        '"}}'
      return callMethodP1(1, 'FiscSVCReadBalance', paramStr)
    }

    this.FiscSVCReadLoadingLog = function (PEF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"PEF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        PEF +
        '"}}'
      return callMethodP1(1, 'FiscSVCReadLoadingLog', paramStr)
    }

    this.FiscSVCReadDeductLog = function (PEF) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"PEF","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        PEF +
        '"}}'
      return callMethodP1(1, 'FiscSVCReadDeductLog', paramStr)
    }

    this.AboutBox = function () {
      return callMethodP1(1, 'AboutBox', '')
    }

    this.SetLanguage = function (LangName) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LangName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        LangName +
        '"}}'
      return callMethodP1(1, 'SetLanguage', paramStr)
    }

    /**交易 - 無障礙 */
    this.AccountInquiryEx2Acc = function (
      pReaderName,
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountInquiryEx2Acc', paramStr)
    }

    this.AccountInquirySndEx2Acc = function (
      pReaderName,
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountInquirySndEx2Acc', paramStr)
    }

    this.AccountInquirySndEx3Acc = function (
      pReaderName,
      pTransactionCode,
      pFdChkCode,
      pAccountNumber,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccountNumber +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountInquirySndEx3Acc', paramStr, callBackMethod)
    }

    this.AccountPaymentEx3Acc = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPaymentEx3Acc', paramStr, callBackMethod)
    }

    this.AccountPaymentSndEx3Acc = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pPaymentType,
      pCancelNo,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPaymentType +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCancelNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPaymentSndEx3Acc', paramStr, callBackMethod)
    }

    this.AccountPayTaxEx3Acc = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPayTaxEx3Acc', paramStr, callBackMethod)
    }

    this.AccountPayTaxSndEx3Acc = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountPayTaxSndEx3Acc', paramStr, callBackMethod)
    }

    this.AccountTransferAcc = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountTransferAcc', paramStr)
    }

    this.AccountTransferEx2Acc = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountTransferEx2Acc', paramStr)
    }

    this.AccountTransferEx3Acc = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pPassword,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountTransferEx3Acc', paramStr, callBackMethod)
    }

    this.AccountTransferSndAcc = function (
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountTransferSndAcc', paramStr)
    }

    this.AccountTransferSndEx2Acc = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}'
      return callMethodP1(1, 'AccountTransferSndEx2Acc', paramStr)
    }

    this.AccountTransferSndEx3Acc = function (
      pReaderName,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pImprtAccnt,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      LogServerFlag,
      LogClientFlag,
      pShowMsg,
      InsertFlag,
      pSessionKeyHash,
      pCpukEncSessionKey,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pImprtAccnt +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogServerFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        LogClientFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        InsertFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}'
      return callMethodP1(1, 'AccountTransferSndEx3Acc', paramStr, callBackMethod)
    }

    /**網銀相關 - 無障礙 */

    this.SetupSMSOTPAcc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pPassword,
      pSessionID,
      pEncURL,
      pTransactionCode,
      pFdChkCode,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}'
      return callMethodP1(1, 'SetupSMSOTPAcc', paramStr, callBackMethod)
    }

    this.SetupSMSOTPSndAcc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pSessionID,
      pEncURL,
      pTransactionCode,
      pFdChkCode,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}'
      return callMethodP1(1, 'SetupSMSOTPSndAcc', paramStr, callBackMethod)
    }

    this.SetupNetAccountAcc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pPassword,
      pSessionID,
      pEncURL,
      pTransactionCode,
      pFdChkCode,
      pID,
      pDateBirth,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pDateBirth","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pDateBirth +
        '"}}'
      return callMethodP1(1, 'SetupNetAccountAcc', paramStr, callBackMethod)
    }

    this.SetupNetAccountSndAcc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pSessionID,
      pEncURL,
      pTransactionCode,
      pFdChkCode,
      pID,
      pDateBirth,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}},'
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pID +
        '"}},'
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pDateBirth","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pDateBirth +
        '"}}'
      return callMethodP1(1, 'SetupNetAccountSndAcc', paramStr, callBackMethod)
    }

    this.TransferProcAcc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      pPassword,
      SessionID,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      pShowMsg,
      BankCodeList,
      CommAccountList,
      pEncURL,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pPassword +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"SessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        SessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        BankCodeList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        CommAccountList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}'
      return callMethodP1(1, 'TransferProcAcc', paramStr, callBackMethod)
    }

    this.TransferProcSndAcc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      SessionID,
      pTransactionCode,
      pFdid,
      pFdChkCode,
      pMoney,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      pShowMsg,
      BankCodeList,
      CommAccountList,
      pEncURL,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"SessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        SessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pTransactionCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pMoney","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pMoney +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pShowMsg +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        BankCodeList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        CommAccountList +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pEncURL +
        '"}}'
      return callMethodP1(1, 'TransferProcSndAcc', paramStr, callBackMethod)
    }

    /**新增 API */
    this.TransferNetProcAcc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      SessionID,
      pFdid,
      pFdChkCode,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      BankCodeList,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"SessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        SessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        BankCodeList +
        '"}}'
      return callMethodP1(1, 'TransferNetProcAcc', paramStr, callBackMethod)
    }
    ;(this.TransferNetProcSndAcc = function (
      pReaderName,
      pSessionKeyHash,
      pCpukEncSessionKey,
      SessionID,
      pFdid,
      pFdChkCode,
      pAccount,
      pCardSerialNo,
      CardNoFlag,
      BankCodeList,
      callBackMethod
    ) {
      let paramStr = ''
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pReaderName +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pSessionKeyHash +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCpukEncSessionKey +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"SessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        SessionID +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdid +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pFdChkCode +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pAccount +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        pCardSerialNo +
        '"}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
        CardNoFlag +
        '}}' +
        ','
      paramStr +=
        '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
        BankCodeList +
        '"}}'
      return callMethodP1(1, 'TransferNetProcSndAcc', paramStr, callBackMethod)
    }),
      (this.TransferNetProc = function (
        pReaderName,
        pSessionKeyHash,
        pCpukEncSessionKey,
        SessionID,
        pFdid,
        pFdChkCode,
        pAccount,
        pCardSerialNo,
        CardNoFlag,
        BankCodeList,
        callBackMethod
      ) {
        let paramStr = ''
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pReaderName +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pSessionKeyHash +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pCpukEncSessionKey +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"SessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          SessionID +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pFdid +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pFdChkCode +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pAccount +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pCardSerialNo +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
          CardNoFlag +
          '}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          BankCodeList +
          '"}}'
        return callMethodP1(1, 'TransferNetProc', paramStr, callBackMethod)
      }),
      (this.TransferNetProcSnd = function (
        pReaderName,
        pSessionKeyHash,
        pCpukEncSessionKey,
        SessionID,
        pFdid,
        pFdChkCode,
        pAccount,
        pCardSerialNo,
        CardNoFlag,
        BankCodeList,
        callBackMethod
      ) {
        let paramStr = ''
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pReaderName +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pSessionKeyHash +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pCpukEncSessionKey +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"SessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          SessionID +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pFdid","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pFdid +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pFdChkCode +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pAccount","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pAccount +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pCardSerialNo +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
          CardNoFlag +
          '}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          BankCodeList +
          '"}}'
        return callMethodP1(1, 'TransferNetProcSnd', paramStr, callBackMethod)
      }),
      (this.GetInBankAccount = function () {
        return callMethodP1(1, 'GetInBankAccount', '')
      }),
      // 常用帳號
      (this.SetupCommAccountAcc = function (
        pReaderName,
        pSessionKeyHash,
        pCpukEncSessionKey,
        pPassword,
        pSessionID,
        pBankCodeList,
        pCommAccountList,
        pEncURL,
        callBackMethod
      ) {
        let paramStr = ''
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pReaderName +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pSessionKeyHash +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pCpukEncSessionKey +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pPassword","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pPassword +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pSessionID +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pBankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pBankCodeList +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pCommAccountList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pCommAccountList +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pEncURL +
          '"}}'
        return callMethodP1(1, 'SetupCommAccountAcc', paramStr, callBackMethod)
      }),
      (this.SetupCommAccountSndAcc = function (
        pReaderName,
        pSessionKeyHash,
        pCpukEncSessionKey,
        pSessionID,
        pBankCodeList,
        pCommAccountList,
        pEncURL,
        callBackMethod
      ) {
        let paramStr = ''
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pReaderName","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pReaderName +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pSessionKeyHash +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pCpukEncSessionKey +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pSessionID","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pSessionID +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pBankCodeList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pBankCodeList +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pCommAccountList","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pCommAccountList +
          '"}}' +
          ','
        paramStr +=
          '{"ParameterType":1,"ParameterName":"pEncURL","DataType":8,"DataValue":{"Type":8,"Encode":0,"Value":"' +
          pEncURL +
          '"}}'
        return callMethodP1(1, 'SetupCommAccountSndAcc', paramStr, callBackMethod)
      })
  }
}
