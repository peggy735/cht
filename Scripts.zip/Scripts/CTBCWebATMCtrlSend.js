/*
return value
0 : 正常
-1 : 無法呼叫到元件的函式
1048577(100001) : Verify Network
1048578(100002) : Requested page not found
1048579(100003) : Internal Server Error.
1048580(100004) : Time out error.
1048581(100005) : Ajax request aborted.
1048582(100006) : Uncaught Error
1048583(100007) :UNAUTHORIZED
1048584(100008) :Bad request
1048585(100009) :Service unavailable
1048608(100020) :Unknow error

*/

const sedDataSec = 8
let isVerify = false
let isServerVerified = false
let Authorization = ''
let ajaxReturnCode_ = 0
let wrapperReturnCode_ = 0
let mySessionId = ''
let myRequestToken = ''
let myCookies = ''
let myAuthenticate = ''

function sendFunc(sendUrl, action, appName, paramStr, debug, processTimeout, callBackMethod) {
  let returnObj = null
  const wrapperNum = ''
  const wrapperAction = 'Create'
  const loopCount = 0

  // Initialize cookies
  if (mySessionId !== '') {
    myCookies = '"WSESSIONID":"' + mySessionId + '"'
  }
  if (myRequestToken !== '') {
    myCookies += ',"RequestToken":"' + myRequestToken + '"'
  }
  if (paramStr === 'Restart') {
    myCookies += ',"ReStart":"1"'
    paramStr = ''
  }
  // Initial AJAX call
  returnObj = sendProcess(sendUrl, action, appName, paramStr, debug, processTimeout, callBackMethod)

  // Handle UNAUTHORIZED (1048583)
  if (
    ajaxReturnCode_ === '1048583' &&
    typeof myAuthenticate !== 'undefined' &&
    myAuthenticate != null
  ) {
    const authenticate = myAuthenticate.split(',')
    const nonce = authenticate[1].replace(/nonce=|\"/g, '')

    // Using genServerRandom directly
    const genResult = genServerRandom(nonce, mySessionId)
    if (genResult.state === '0000') {
      Authorization =
        'Custom realm=\\"CTBCActivexWrapper\\",cnonce=\\"' +
        encodeURIComponent(genResult.cnonce) +
        '\\", qop=\\"auth\\"'

      // Update cookies
      if (mySessionId !== '') {
        myCookies = '"WSESSIONID":"' + mySessionId + '"'
      }
      if (myRequestToken !== '') {
        myCookies += ',"RequestToken":"' + myRequestToken + '"'
      }
      myCookies += ',"Authorization":"' + Authorization + '"'

      // Re-send the request with Authorization header
      returnObj = sendProcess(
        sendUrl,
        action,
        appName,
        paramStr,
        debug,
        processTimeout,
        callBackMethod
      )
      Authorization = ''

      // Handle successful response and server verification
      if (
        returnObj.status === '0' &&
        returnObj.ajaxReturnCode === '0' &&
        returnObj.authenticate != null
      ) {
        isVerify = true
        const authenticate = returnObj.authenticate.split(',')
        const wnonce = authenticate[1].replace(/wnonce=|\"/g, '')

        console.log(mySessionId)
        // Using verifyServerNonce directly
        const verifyResult = verifyServerNonce(wnonce, mySessionId)
        console.log(verifyResult)
        if (verifyResult.state === '0000') {
          isServerVerified = true
        }
      }
    }
  }
  return returnObj
}

function sendProcess(sendUrl, action, appName, paramStr, debug, processTimeout, callBackMethod) {
  let returnObj = []
  returnObj.ajaxReturnCode = '0'
  returnObj.data = ''
  returnObj.errMsg = ''
  returnObj.status = '0'
  returnObj.R_Status = ''
  returnObj.R_Num = 0
  let asyncFlag = false
  const myHeader = {}

  try {
    let sendParamStr = ''
    if (action !== '' && appName !== '') {
      sendParamStr = 'action=' + action + '&AppName=' + appName
    }

    if (paramStr !== '') {
      sendParamStr = sendParamStr + '&AppParam=' + paramStr
    }

    if (myCookies !== '') {
      sendParamStr += '&Cookie={' + myCookies + '}'
    }

    const contentType = 'application/x-www-form-urlencoded; charset=utf-8'

    if (debug) {
      PrintLog('jSendData', 'sendUrl=' + sendUrl + '?' + sendParamStr)
    }

    console.log('typeof callBackMethod', typeof callBackMethod)

    if (typeof callBackMethod === 'function') {
      asyncFlag = true

      if (processTimeout == null) {
        processTimeout = 210
      }
    } else {
      processTimeout = 210
    }

    jQuery.support.cors = true
    returnObj.status = '1'
    jQuery.ajax({
      crossDomain: true,
      type: 'POST',
      timeout: processTimeout * 10000,
      url: sendUrl,
      data: sendParamStr,
      async: asyncFlag,
      dataType: 'html',
      contentType: contentType,
      cache: false,
      xhrFields: {
        withCredentials: true
      },
      success: function (data, textStatus, jqXHR) {
        if (debug) {
          PrintLog(
            'jSendData',
            "ajax.success: 'jqXHR.status=" +
              jqXHR.status +
              ', textStatus=' +
              textStatus +
              ', data=' +
              data +
              "'"
          )
        }

        ajaxReturnCode_ = '0'
        returnObj.authenticate = jqXHR.getResponseHeader('Authorization')
        returnObj.status = '0'
        returnObj.data = decodeURI(data)
        if (action !== '') {
          returnObj = parseReturnData(returnObj)
        } else {
          parseData(data)
        }

        if (asyncFlag) {
          callBackMethod(returnObj)
        }
      },
      error: function (jqXHR, textStatus, exception) {
        PrintLog(
          'jSendData',
          "ajax.error: 'jqXHR.status=" +
            jqXHR.status +
            ', textStatus=' +
            textStatus +
            ', errorThrown=' +
            exception +
            "'"
        )
        returnObj.status = '2'

        if (jqXHR.status === 401) {
          // 提取並解析 Set-Cookie 的內容
          const responseText = jqXHR.responseText
          const setCookieStart = responseText.indexOf('Set-Cookie=')
          if (setCookieStart !== -1) {
            const setCookieData = JSON.parse(responseText.substring(setCookieStart + 11))
            if (setCookieData) {
              // 更新 RequestToken 和 WWW-Authenticate (myAuthenticate)
              myRequestToken = setCookieData.RequestToken || ''
              myAuthenticate = setCookieData['WWW-Authenticate'] || ''
            }
          }

          ajaxReturnCode_ = '1048583'
          returnObj.ajaxReturnCode = '1048583'
          returnObj.errMs = 'UNAUTHORIZED'

          if (asyncFlag) {
            verifyProcess(
              sendUrl,
              action,
              appName,
              paramStr,
              debug,
              processTimeout,
              callBackMethod,
              returnObj
            )
          }
        } else if (jqXHR.status === 0) {
          ajaxReturnCode_ = '1048577'
          returnObj.ajaxReturnCode = '1048577'
          returnObj.errMs = 'Verify Network.'
        } else if (jqXHR.status === 404) {
          ajaxReturnCode_ = '1048578'
          returnObj.ajaxReturnCode = '1048578'
          returnObj.errMs = 'Requested page not found.'
        } else if (jqXHR.status === 500) {
          ajaxReturnCode_ = '1048579'
          returnObj.ajaxReturnCode = '1048579'
          returnObj.errMs = 'Internal Server Error.'
        } else if (exception === 'timeout') {
          ajaxReturnCode_ = '1048580'
          returnObj.ajaxReturnCode = '1048580'
          returnObj.errMs = 'Time out error.'
        } else {
          ajaxReturnCode_ = '1048582'
          returnObj.ajaxReturnCode = '1048582'
          returnObj.errMsg = 'Uncaught Error Status:' + jqXHR.status
        }

        if (action !== '') {
          returnObj = parseReturnData(returnObj)
        }

        if (asyncFlag && ajaxReturnCode_ !== '1048583') {
          callBackMethod(returnObj)
        }
      }
    })
  } catch (e) {
    ajaxReturnCode_ = '1048608'
    PrintLog('jSendData', "AP return error, returnObj.errMsg: '" + e + "'")
    returnObj.errMsg = e

    if (asyncFlag) {
      callBackMethod(returnObj)
    }
  }

  return returnObj
}

function verifyProcess(
  sendUrl,
  action,
  appName,
  paramStr,
  debug,
  processTimeout,
  callBackMethod,
  returnObj
) {
  const authenticate = myAuthenticate.split(',')
  const nonce = authenticate[1].replace(/nonce=|\"/g, '')

  // 使用本地的 genServerRandom
  const genResult = genServerRandom(nonce, mySessionId)
  if (genResult.state === '0000') {
    Authorization =
      'Custom realm=\\"CTBCActivexWrapper\\",cnonce=\\"' +
      encodeURIComponent(genResult.cnonce) +
      '\\", qop=\\"auth\\"'

    // Update cookies
    if (mySessionId !== '') {
      myCookies = '"WSESSIONID":"' + mySessionId + '"'
    }
    if (myRequestToken !== '') {
      myCookies += ',"RequestToken":"' + myRequestToken + '"'
    }
    myCookies += ',"Authorization":"' + Authorization + '"'

    // 發送 AJAX 請求
    sendProcess(sendUrl, action, appName, paramStr, debug, processTimeout, callBackMethod)

    Authorization = ''
    if (
      returnObj.status === '0' &&
      returnObj.ajaxReturnCode === '0' &&
      returnObj.authenticate != null
    ) {
      isVerify = true

      // 從回應中提取 wnonce 並使用本地的 serverVerify
      const authenticate = returnObj.authenticate.split(',')
      const wnonce = authenticate[1].replace(/wnonce=|\"/g, '')
      const verifyResult = serverVerify(wnonce, mySessionId)

      if (verifyResult.state === '0000') {
        serverVerify = true
      }
    }
  }
}

function verifySend(sendUrl, sendParamStr) {
  //alert(sendUrl)
  let returnObj = []
  returnObj.state = '9999'

  jQuery.ajax({
    type: 'POST',
    timeout: 0,
    url: sendUrl,
    data: sendParamStr,
    async: false,
    dataType: 'json',
    contentType: 'application/x-www-form-urlencoded; charset=utf-8',
    cache: false,
    success: function (data, textStatus, jqXHR) {
      returnObj = jQuery.parseJSON(data)
    },
    error: function (jqXHR, textStatus, exception) {
      if (jqXHR.status === 0) {
        returnObj.state = '0004'
      } else if (jqXHR.status == 404) {
        returnObj.state = '0005'
      } else if (jqXHR.status == 500) {
        returnObj.state = '0006'
      } else if (exception === 'timeout') {
        returnObj.state = '0007'
      } else if (exception === 'abort') {
        returnObj.state = '0008'
      } else {
        returnObj.state = '0009'
      }
    }
  })

  return returnObj
}

function parseReturnData(returnData) {
  if (returnData.ajaxReturnCode == '0') {
    returnData = parseData(returnData.data)

    if (returnData.returnCode == '0') {
      if (returnData.RtnData != undefined) {
        if (returnData.RtnData.RtnDataValue != undefined) {
          if (returnData.RtnData.RtnDataValue.Value != undefined) {
            return returnData.RtnData.RtnDataValue.Value
          } else {
            return ''
          }
        }
      }

      return returnData.returnCode
    } else {
      return ''
    }
  } else {
    return returnData.ajaxReturnCode
  }
}

function PrintLog(title, message) {
  /*var ifrmLog = document.getElementById("divLog");
	if(typeof(ifrmLog)=="object"){
		//ifrmLog = ifrmLog.contentWindow || ifrmLog.contentDocument.document || ifrmLog.contentDocument;
		//ifrmLog.document.open();
		//ifrmLog.document.write("["+ParseDateToStr(new Date)+"]["+title+"] " + message + "<br>");
		//ifrmLog.document.close();
		ifrmLog.innerHTML += "["+ParseDateToStr(new Date)+"]["+title+"] " + message + "<br>";
	}*/
  try {
    if (typeof console !== 'undefined') {
      //console.log("[" + ParseDateToStr(new Date) + "][" + title + "] " + message);
    }
  } catch (e) {
    //alert("PrintLog:\n["+ParseDateToStr(new Date)+"]["+title+"] " + message+"");
  }
}

function ParseDateToStr(Now) {
  const strYear = Now.getFullYear().toString()
  const iMonth = Now.getMonth() + 1
  let strMonth = iMonth.toString()
  if (strMonth.length < 2) strMonth = '0' + strMonth
  let strDay = Now.getDate().toString()
  if (strDay.length < 2) strDay = '0' + strDay
  let strHour = Now.getHours().toString()
  if (strHour.length < 2) strHour = '0' + strHour
  let strMinute = Now.getMinutes().toString()
  if (strMinute.length < 2) strMinute = '0' + strMinute
  let strSecond = Now.getSeconds().toString()
  if (strSecond.length < 2) strSecond = '0' + strSecond
  const strMilliSecond = Now.getMilliseconds().toString()
  return (
    strYear +
    '/' +
    strMonth +
    '/' +
    strDay +
    ' ' +
    strHour +
    ':' +
    strMinute +
    ':' +
    strSecond +
    '.' +
    strMilliSecond
  )
}

function waitTime(ms) {
  const start = new Date().getTime()
  let end = start
  while (end < start + ms) {
    end = new Date().getTime()
  }
}

function parseData(data) {
  let returnData = {}
  let returnCode = -1
  try {
    data = data.replace('WWW-Authenticate', 'WWWAuthenticate')

    const paramList = data.split('&')
    /*parse data*/
    if (paramList.length != 0) {
      for (let paramCount = 0; paramCount < paramList.length; paramCount++) {
        if (paramList[paramCount].indexOf('ReturnCode=') != -1) {
          var index1 = 0
          index1 = paramList[paramCount].indexOf('ReturnCode=')
          returnCode = paramList[paramCount].substring(index1 + 11)
          wrapperReturnCode_ = returnCode
        } else if (paramList[paramCount].indexOf('ReturnMessage=') != -1) {
          var index1 = 0
          index1 = paramList[paramCount].indexOf('ReturnMessage=')
          try {
            /*有特殊符號處理*/
            returnData = jQuery.parseJSON(
              paramList[paramCount]
                .substring(index1 + 14)
                .replace(/\/g, '')
                .replace(/\/g, '')
            )
          } catch (e) {}
        } else if (paramList[paramCount].indexOf('Set-Cookie=') != -1) {
          var index1 = 0
          index1 = paramList[paramCount].indexOf('Set-Cookie=')
          /*有特殊符號處理*/
          const cookieObj = jQuery.parseJSON(
            paramList[paramCount]
              .substring(index1 + 11)
              .replace(/\/g, '')
              .replace(/\/g, '')
          )

          if (cookieObj.WSESSIONID != null && typeof cookieObj.WSESSIONID != 'undefined') {
            mySessionId = encodeURIComponent(cookieObj.WSESSIONID)
          }
          if (cookieObj.RequestToken != null && typeof cookieObj.RequestToken != 'undefined') {
            myRequestToken = encodeURIComponent(cookieObj.RequestToken)
          }
          if (
            cookieObj.WWWAuthenticate != null &&
            typeof cookieObj.WWWAuthenticate != 'undefined'
          ) {
            myAuthenticate = cookieObj.WWWAuthenticate
          }
        } else {
          //待擴充
        }
      }
    }

    if (returnData == undefined) {
      returnData = {}
    }

    if (returnData.RtnData == undefined) {
      returnData.RtnData = []
    }

    returnData.returnCode = returnCode
  } catch (e) {
    if (returnData == undefined) {
      returnData = {}
    }

    if (returnData.RtnData == undefined) {
      returnData.RtnData = []
    }

    returnData.returnCode = returnCode
  }
  return returnData
}

function encrypt3DES(plainText, keyHex, ivHex) {
  const key = CryptoJS.enc.Hex.parse(keyHex)
  const iv = CryptoJS.enc.Hex.parse(ivHex)
  const encrypted = CryptoJS.TripleDES.encrypt(CryptoJS.enc.Hex.parse(plainText), key, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.NoPadding
  })
  return encrypted.ciphertext.toString(CryptoJS.enc.Hex)
}

function decrypt3DES(encryptedText, keyHex, ivHex) {
  const key = CryptoJS.enc.Hex.parse(keyHex)
  const iv = CryptoJS.enc.Hex.parse(ivHex)
  const decrypted = CryptoJS.TripleDES.decrypt(
    { ciphertext: CryptoJS.enc.Hex.parse(encryptedText) },
    key,
    {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.NoPadding
    }
  )
  return decrypted.toString(CryptoJS.enc.Hex).toUpperCase()
}

const SECURITY_KEY = '5052444354424357656241544d454f534c53657276696365'
const IV = '0000000000000000'

function getRandomHexString(numchars, sessionId) {
  const hash = CryptoJS.SHA256(sessionId).toString(CryptoJS.enc.Hex)
  return hash.substring(0, numchars)
}

function genServerRandom(wrapperRandomBase64, sessionId) {
  const trimmedBase64 = wrapperRandomBase64.trim()
  const wrapperRandomBytes = CryptoJS.enc.Base64.parse(trimmedBase64)

  if (wrapperRandomBytes.sigBytes !== 16) {
    return { state: '0001' } // wrapper 亂數長度不對
  }

  const serverRandom = getRandomHexString(32, sessionId)
  const combinedRandom = wrapperRandomBytes + serverRandom
  const encryptedCombinedRandom = encrypt3DES(combinedRandom, SECURITY_KEY, IV)

  const serverRandomSha256 = CryptoJS.SHA256(CryptoJS.enc.Hex.parse(serverRandom)).toString(
    CryptoJS.enc.Hex
  )
  const cnonce = encryptedCombinedRandom + serverRandomSha256

  return {
    state: '0000',
    cnonce: CryptoJS.enc.Base64.stringify(CryptoJS.enc.Hex.parse(cnonce))
  }
}

function verifyServerNonce(wnonceBase64, sessionId) {
  const serverRandom = getRandomHexString(32, sessionId)
  const wnonce = CryptoJS.enc.Base64.parse(wnonceBase64).toString(CryptoJS.enc.Hex)

  const decryptedText = decrypt3DES(wnonce, SECURITY_KEY, IV)

  if (decryptedText === serverRandom) {
    return { state: '0000' } // 比對成功
  } else {
    return { state: '0003' } // 比對失敗
  }
}
