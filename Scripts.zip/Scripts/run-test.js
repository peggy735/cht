const path = require('path')
const fs = require('fs')
const os = require('os')
const { Builder, By, until } = require('selenium-webdriver')

const htmlDir = path.resolve(__dirname, '..')
const allHtmlFiles = fs.readdirSync(htmlDir).filter((f) => f.endsWith('.html'))

const testCases = [
  { name: 'AccountInquiry', btn: 'btnAccountInquiry' },
  { name: 'AccountInquiryEx', btn: 'btnAccountInquiryEx' },
  { name: 'AccountInquiryEx2', btn: 'btnAccountInquiryEx2' },
  { name: 'AccountInquiryEx3', btn: 'btnAccountInquiryEx3' },
  { name: 'AccountInquiryEx2Acc', btn: 'btnAccountInquiryEx2Acc' },
  { name: 'AccountInquiryEx3Acc', btn: 'btnAccountInquiryEx3Acc' },
  { name: 'AccountPurchase', btn: 'btnAccountPurchase' },
  { name: 'AccountPurchaseEx', btn: 'btnAccountPurchaseEx' },
  { name: 'AccountPurchaseEx2', btn: 'btnAccountPurchaseEx2' },
  { name: 'AccountPurchaseEx3', btn: 'btnAccountPurchaseEx3' },
  { name: 'AccountPurchaseSnd', btn: 'btnAccountPurchaseSnd' },
  { name: 'AccountPurchaseSndEx', btn: 'btnAccountPurchaseSndEx' },
  { name: 'AccountPurchaseSndEx2', btn: 'btnAccountPurchaseSndEx2' },
  { name: 'AccountPurchaseSndEx3', btn: 'btnAccountPurchaseSndEx3' },
  { name: 'AccountWithdraw', btn: 'btnAccountWithdraw' },
  { name: 'AccountWithdrawEx', btn: 'btnAccountWithdrawEx' },
  { name: 'AccountWithdrawEx2', btn: 'btnAccountWithdrawEx2' },
  { name: 'AccountWithdrawEx3', btn: 'btnAccountWithdrawEx3' },
  { name: 'AccountWithdrawSnd', btn: 'btnAccountWithdrawSnd' },
  { name: 'AccountWithdrawSndEx', btn: 'btnAccountWithdrawSndEx' },
  { name: 'AccountWithdrawSndEx2', btn: 'btnAccountWithdrawSndEx2' },
  { name: 'AccountWithdrawSndEx3', btn: 'btnAccountWithdrawSndEx3' },
  { name: 'AccountPayment', btn: 'btnAccountPayment' },
  { name: 'AccountPaymentEx', btn: 'btnAccountPaymentEx' },
  { name: 'AccountPaymentEx2', btn: 'btnAccountPaymentEx2' },
  { name: 'AccountPaymentEx3', btn: 'btnAccountPaymentEx3' },
  { name: 'AccountPaymentEx3Acc', btn: 'btnAccountPaymentEx3Acc' },
  { name: 'AccountPaymentSnd', btn: 'btnAccountPaymentSnd' },
  { name: 'AccountPaymentSndEx', btn: 'btnAccountPaymentSndEx' },
  { name: 'AccountPaymentSndEx2', btn: 'btnAccountPaymentSndEx2' },
  { name: 'AccountPaymentSndEx3', btn: 'btnAccountPaymentSndEx3' },
  { name: 'AccountPaymentSndEx3Acc', btn: 'btnAccountPaymentSndEx3Acc' },
  { name: 'AccountPayTax', btn: 'btnAccountPayTax' },
  { name: 'AccountPayTaxEx', btn: 'btnAccountPayTaxEx' },
  { name: 'AccountPayTaxEx2', btn: 'btnAccountPayTaxEx2' },
  { name: 'AccountPayTaxEx3', btn: 'btnAccountPayTaxEx3' },
  { name: 'AccountPayTaxEx3Acc', btn: 'btnAccountPayTaxEx3Acc' },
  { name: 'AccountPayTaxSnd', btn: 'btnAccountPayTaxSnd' },
  { name: 'AccountPayTaxSndEx', btn: 'btnAccountPayTaxSndEx' },
  { name: 'AccountPayTaxSndEx2', btn: 'btnAccountPayTaxSndEx2' },
  { name: 'AccountPayTaxSndEx3', btn: 'btnAccountPayTaxSndEx3' },
  { name: 'AccountPayTaxSndEx3Acc', btn: 'btnAccountPayTaxSndEx3Acc' },
  { name: 'AccountTransfer', btn: 'btnAccountTransfer' },
  { name: 'AccountTransferEx', btn: 'btnAccountTransferEx' },
  { name: 'AccountTransferEx2', btn: 'btnAccountTransferEx2' },
  { name: 'AccountTransferEx3', btn: 'btnAccountTransferEx3' },
  { name: 'AccountTransferAcc', btn: 'btnAccountTransferAcc' },
  { name: 'AccountTransferEx2Acc', btn: 'btnAccountTransferEx2Acc' },
  { name: 'AccountTransferEx3Acc', btn: 'btnAccountTransferEx3Acc' },
  { name: 'AccountTransferSnd', btn: 'btnAccountTransferSnd' },
  { name: 'AccountTransferSndAcc', btn: 'btnAccountTransferSndAcc' },
  { name: 'AccountTransferSndEx', btn: 'btnAccountTransferSndEx' },
  { name: 'AccountTransferSndEx2', btn: 'btnAccountTransferSndEx2' },
  { name: 'AccountTransferSndEx2Acc', btn: 'btnAccountTransferSndEx2Acc' },
  { name: 'AccountTransferSndEx3', btn: 'btnAccountTransferSndEx3' },
  { name: 'AccountTransferSndEx3Acc', btn: 'btnAccountTransferSndEx3Acc' },
  { name: 'SetupCommAccount', btn: 'btnSetupCommAccount' },
  { name: 'SetupCommAccountSnd', btn: 'btnSetupCommAccountSnd' },
  { name: 'SetupCommAccountAcc', btn: 'btnSetupCommAccountAcc' },
  { name: 'SetupCommAccountSndAcc', btn: 'btnSetupCommAccountSndAcc' },
  { name: 'SetupNetAccount', btn: 'btnSetupNetAccount' },
  { name: 'SetupNetAccountSnd', btn: 'btnSetupNetAccountSnd' },
  { name: 'SetupNetAccountAcc', btn: 'btnSetupNetAccountAcc' },
  { name: 'SetupNetAccountSndAcc', btn: 'btnSetupNetAccountSndAcc' },
  { name: 'TransferNetProc', btn: 'btnTransferNetProc' },
  { name: 'TransferNetProcSnd', btn: 'btnTransferNetProcSnd' },
  { name: 'TransferNetProcAcc', btn: 'btnTransferNetProcAcc' },
  { name: 'TransferNetProcSndAcc', btn: 'btnTransferNetProcSndAcc' },
  { name: 'TransferProc', btn: 'btnTransferProc' },
  { name: 'TransferProcSnd', btn: 'btnTransferProcSnd' },
  { name: 'TransferProcAcc', btn: 'btnTransferProcAcc' },
  { name: 'TransferProcSndAcc', btn: 'btnTransferProcSndAcc' },
  { name: 'SetupSMSOTP', btn: 'btnSetupSMSOTP' },
  { name: 'SetupSMSOTPSnd', btn: 'btnSetupSMSOTPSnd' },
  { name: 'SetupSMSOTPAcc', btn: 'btnSetupSMSOTPAcc' },
  { name: 'SetupSMSOTPSndAcc', btn: 'btnSetupSMSOTPSndAcc' }
]

const argv = process.argv.slice(2)
let browserName = null

if (argv.includes('--chrome')) browserName = 'chrome'
if (argv.includes('--firefox')) browserName = 'firefox'
if (argv.includes('--edge')) browserName = 'MicrosoftEdge'
if (argv.includes('--safari')) browserName = 'safari'
if (!browserName) browserName = os.platform() === 'darwin' ? 'safari' : 'chrome'

const windowWidth = 1322
const windowHeight = 691

async function getReaderNameValue(driver) {
  try {
    const sel = await driver.findElements(By.css('select[name="txtReaderName"]'))
    if (sel.length > 0) return await sel[0].getAttribute('value')
    const inp = await driver.findElements(By.css('input[name="txtReaderName"]'))
    if (inp.length > 0) return await inp[0].getAttribute('value')
  } catch {}
  return null
}

;(async () => {
  let driver
  try {
    const builder = new Builder().forBrowser(browserName)
    if (browserName === 'chrome') {
      const chrome = require('selenium-webdriver/chrome')
      const options = new chrome.Options()
      options.windowSize({ width: windowWidth, height: windowHeight })
      options.addArguments('--disable-web-security', '--disable-gpu')
      builder.setChromeOptions(options)
    } else if (browserName === 'firefox') {
      const firefox = require('selenium-webdriver/firefox')
      const options = new firefox.Options()
      options.windowSize({ width: windowWidth, height: windowHeight })
      builder.setFirefoxOptions(options)
    }

    driver = await builder.build()

    for (const fileName of allHtmlFiles) {
      try {
        await driver.get(`http://localhost:8081/TestPage/${encodeURIComponent(fileName)}`)

        driver
          .switchTo()
          .alert()
          .then((alert) => alert.dismiss())
          .catch(() => {})

        try {
          await driver.wait(
            until.elementLocated(
              By.css('input[name="txtReaderName"],select[name="txtReaderName"]')
            ),
            2000
          )
        } catch {
          console.log(`${fileName} 沒有 txtReaderName, 跳過`)
          continue
        }

        let reloadCount = 0
        const maxReload = 10
        let readerNameValue = '1048582'

        while (reloadCount < maxReload) {
          try {
            await driver.wait(until.elementLocated(By.css('input[name="btnListReadersOnly"]')), 500)
            const listReaderBtn = await driver.findElement(
              By.css('input[name="btnListReadersOnly"]')
            )
            const oldValue = await getReaderNameValue(driver)

            if (browserName === 'safari') {
              await driver.executeScript('arguments[0].click()', listReaderBtn)
            } else {
              await listReaderBtn.click()
            }

            try {
              await driver.wait(async () => {
                const v = await getReaderNameValue(driver)
                return v !== oldValue && v !== '1048582'
              }, 3000)
            } catch {}

            readerNameValue = await getReaderNameValue(driver)
            if (readerNameValue !== '1048582') break

            reloadCount++
            if (reloadCount >= maxReload) break
            console.warn(`${fileName} Reader Name=1048582，第${reloadCount}次重整`)
            await driver.navigate().refresh()
            await driver.wait(
              until.elementLocated(By.css('input[name="btnListReadersOnly"]')),
              2000
            )
            await driver.wait(
              until.elementLocated(
                By.css('input[name="txtReaderName"],select[name="txtReaderName"]')
              ),
              2000
            )
            await driver.sleep(500)
          } catch (e) {
            console.error(`${fileName} 檢查 Reader Name 流程出錯:`, e)
            break
          }
        }

        if (readerNameValue === '1048582') {
          console.error(`${fileName} Reader Name 連續 ${maxReload} 次都是 1048582，跳過`)
          continue
        }

        const connectCardBtn = await driver.findElements(By.css('input[name="btnConnectCard"]'))
        if (connectCardBtn.length) {
          await driver.executeScript('arguments[0].disabled = false', connectCardBtn[0])
          if (browserName === 'safari') {
            await driver.executeScript('arguments[0].click()', connectCardBtn[0])
          } else {
            await connectCardBtn[0].click()
          }

          try {
            await driver.wait(until.alertIsPresent(), 2000)
            const alert = await driver.switchTo().alert()
            await alert.accept()
          } catch (e) {}
          await driver.sleep(500)
        }

        const pinInput = await driver.findElements(By.css('input[name="txtPIN"]'))
        if (pinInput.length) {
          await driver.executeScript('arguments[0].value = ""', pinInput[0])
          await pinInput[0].sendKeys('13275323')
        }

        await driver.executeScript((cases) => {
          const f = document.forms['form1']
          if (f) {
            cases.forEach((testCase) => {
              if (f[testCase.btn]) f[testCase.btn].disabled = false
            })
          }
        }, testCases)

        for (const test of testCases) {
          const btnArr = await driver.findElements(By.css(`input[name="${test.btn}"]`))
          if (!btnArr.length) {
            console.log(`${fileName} 找不到按鈕 ${test.btn}`)
            continue
          }

          console.log(`${fileName} 準備點擊按鈕: ${test.btn}`)
          await driver.wait(async () => {
            return await driver.executeScript((btnName) => {
              const f = document.forms['form1']
              return f && f[btnName] && f[btnName].disabled === false
            }, test.btn)
          }, 2000)

          const returnCodeArr = await driver.findElements(By.css('input[name="txtReturnCode"]'))
          if (returnCodeArr.length)
            await driver.executeScript('arguments[0].value = ""', returnCodeArr[0])

          if (browserName === 'safari') {
            await driver.executeScript('arguments[0].click()', btnArr[0])
          } else {
            await btnArr[0].click()
          }

          await driver.wait(() => {
            return driver.executeScript(() => {
              const f = document.forms['form1']
              return f && f.txtReturnCode && f.txtReturnCode.value.trim() !== ''
            })
          }, 100000)

          const returnCode = await driver.executeScript(() => {
            return document.forms['form1'].txtReturnCode.value
          })

          if (returnCode === '0') {
            await driver.executeScript('window.scrollTo(0, document.body.scrollHeight)')
            await driver.sleep(300)
            const imgName = `${fileName.replace('.html', '')}_${test.name}.png`
            const image = await driver.takeScreenshot()
            fs.writeFileSync(imgName, image, 'base64')
            console.log(`${fileName} ${test.name} 測試成功，已截圖：${imgName}`)
          } else {
            console.log(`${fileName} ${test.name} 測試失敗，ReturnCode: ${returnCode}`)
          }
          await driver.sleep(1000)
        }
      } catch (err) {
        console.error(`${fileName} 測試過程出錯：`, err)
      }
    }
  } finally {
    if (driver) await driver.quit()
  }
})()
