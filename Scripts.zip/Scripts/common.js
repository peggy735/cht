/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-undef */
let NetWeb

const strLanguage = 'tw'

let isMac = false

let that

function onTestCTCBWEBATM() {
  let OSName = 'Unknown'

  if (window.navigator.userAgent.indexOf('Mac OS X') !== -1) OSName = 'Mac'
  else if (window.navigator.userAgent.indexOf('Windows') !== -1) OSName = 'Windows'

  if (OSName.localeCompare('Mac') === 0) {
    alert('not support OSX')
    return
  }

  isMac = false
  NetWeb = new ActiveXObject('CTCBWEBATM.CTCBWebATMCtrl.1')
  form1.edtTestCase.value = 'CTBCWEBATM ActiveX Object'
  NetWeb.SetLanguage(strLanguage)
}

function onTestWindowsTCPLocalService() {
  isMac = false
  NetWeb = null
  form1.edtTestCase.value = 'TCPLocalService'
  form1.edtTestCase.value += '[Active COM]'
  NetWeb = new CTCBWebATMWinCtrl()
  NetWeb.SetLanguage(strLanguage)
}

function onTestMacTCPLocalService() {
  isMac = true
  NetWeb = null
  form1.edtTestCase.value = 'TCPLocalService'
  form1.edtTestCase.value += '[OSX Framework]'
  NetWeb = new CTCBWebATMMacCtrl()
  NetWeb.SetLanguage(strLanguage)
}

function onTestTCPLocalService() {
  let OSName = 'Unknown'

  if (window.navigator.userAgent.indexOf('Mac OS X') !== -1) OSName = 'Mac'
  else if (window.navigator.userAgent.indexOf('Windows') !== -1) OSName = 'Windows'

  if (OSName.localeCompare('Windows') === 0) {
    onTestWindowsTCPLocalService()
  } else if (OSName.localeCompare('Mac') === 0) {
    onTestMacTCPLocalService()
  } else {
    alert(OSName)
  }
}

function formload() {
  let OSName = 'Unknown'

  if (window.navigator.userAgent.indexOf('Mac OS X') !== -1) OSName = 'Mac'
  else if (window.navigator.userAgent.indexOf('Windows') !== -1) OSName = 'Windows'

  if (OSName.localeCompare('Windows') === 0) {
    //onTestCTCBWEBATM();
    onTestWindowsTCPLocalService()
  } else if (OSName.localeCompare('Mac') === 0) {
    onTestMacTCPLocalService()
  } else {
    alert(OSName)
  }

  return true
}
