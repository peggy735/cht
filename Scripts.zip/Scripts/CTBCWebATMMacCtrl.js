/*
 * esecure
 * author ben
 * modify dennis
 * modify zoe
 * varsion 1.0.3
 * date 20241118
 */

function CTCBWebATMMacCtrl() {
  /*debug*/
  this.debug = true
  /*AppleMac appName 指定 library path*/
  this.appName = '/Applications/CTBCWebATM.app/Contents/Resources/CTBCWebATM.framework/CTBCWebATM'
  /*post server*/
  this.sendUrl = 'https://localhost'
  /*wrapper listen port*/
  this.listenPort = ''
  /*AppleMac為 Clib*/
  this.action = 'Clib'
  /*applet jar path*/
  this.appletPath = '/Library/Application Support/'
  //設定reader name filter
  this.ReaderNameFilter = ''
  //設定交易timeout
  this.SetTimeout = 30
  /*設定元件啟用的錯誤訊息*/
  this.startErrMsg = '請確認是否已啟動AP程式及元件註冊'
  /*呼叫AP時的回傳結果*/
  let sendRetunCode = '0'

  /*ajax通訊的錯誤代碼*/
  let ajaxReturnCode = '0'
  /*呼叫AP時的回傳結果*/
  let wrapperReturnCode = '0'

  /*呼叫AP的 error code list*/
  //var errorCodeList = [];
  /*bind port list*/
  const listenPortData = ['48220', '48221', '48222']

  /*error msg List */
  const errorCodeList = {
    1048577: '無法與安控程式連接，請確認安控程式是否正常啟動',
    1048578: '安控程式無提供此功能介面',
    1048579: '安控程式出現錯誤',
    1048580: '與安控服務連接逾時',
    1048581: '與安控連線中斷',
    1048582: '發生未知錯誤',
    1048583: '與安控服務認證失敗',
    1048584: '此為不合法請求，請執行登出後，關閉瀏覽器，再進行測試',
    1048608: '發生未知錯誤'
  }

  const tiemMethodList = {
    AboutBox: 210,
    AccountInquiry: 210,
    AccountPayment: 210,
    AccountPayTax: 210,
    AccountTransfer: 210,
    AccountWithdraw: 210,
    AccountInquiryEx: 210,
    AccountPaymentEx: 210,
    AccountPayTaxEx: 210,
    AccountTransferEx: 210,
    AccountWithdrawEx: 210,
    AccountInquiryEx2: 210,
    AccountPaymentEx2: 210,
    AccountPayTaxEx2: 210,
    AccountTransferEx2: 210,
    AccountWithdrawEx2: 210,
    AccountInquiryEx3: 210,
    AccountInquiryEx3Acc: 210,
    AccountPaymentEx3: 210,
    AccountPayTaxEx3: 210,
    AccountTransferEx3: 210,
    AccountWithdrawEx3: 210,
    AccountInquirySnd: 210,
    AccountPaymentSnd: 210,
    AccountPayTaxSnd: 210,
    AccountTransferSnd: 210,
    AccountWithdrawSnd: 210,
    AccountPurchaseSnd: 210,
    AccountInquirySndEx: 210,
    AccountPaymentSndEx: 210,
    AccountPayTaxSndEx: 210,
    AccountTransferSndEx: 210,
    AccountWithdrawSndEx: 210,
    AccountPurchaseSndEx: 210,
    AccountInquirySndEx2: 210,
    AccountPaymentSndEx2: 210,
    AccountPayTaxSndEx2: 210,
    AccountTransferSndEx2: 210,
    AccountWithdrawSndEx2: 210,
    AccountPurchaseSndEx2: 210,
    AccountInquirySndEx3: 210,
    AccountPaymentSndEx3: 210,
    AccountPayTaxSndEx3: 210,
    AccountTransferSndEx3: 210,
    AccountWithdrawSndEx3: 210,
    AccountPurchaseSndEx3: 210,
    SetupSMSOTP: 210,
    SetupSMSOTPSnd: 210,
    SetupNetAccount: 210,
    SetupNetAccountSnd: 210,
    SetupCommAccount: 210,
    SetupCommAccountSnd: 210,
    TransferProc: 210,
    TransferProcSnd: 210,

    /** 交易-無障礙 */
    AccountInquiryEx2Acc: 210,
    AccountInquirySndEx2Acc: 210,
    AccountInquirySndEx3Acc: 210,
    AccountPaymentEx3Acc: 210,
    AccountPaymentSndEx3Acc: 210,
    AccountPayTaxEx3Acc: 210,
    AccountPayTaxSndEx3Acc: 210,
    AccountTransferAcc: 210,
    AccountTransferEx2Acc: 210,
    AccountTransferEx3Acc: 210,
    AccountTransferSndAcc: 210,
    AccountTransferSndEx2Acc: 210,
    AccountTransferSndEx3Acc: 210,

    /**網銀相關 - 無障礙 */
    SetupSMSOTPAcc: 210,
    SetupSMSOTPSndAcc: 210,
    SetupNetAccountAcc: 210,
    SetupNetAccountSndAcc: 210,
    TransferProcAcc: 210,
    TransferProcSndAcc: 210,
    TransferNetProcAcc: 210,
    TransferNetProcSndAcc: 210,

    /** 新增 API */
    TransferNetProc: 210,
    TransferNetProcSnd: 210,

    SetupCommAccountAcc: 210,
    SetupCommAccountSndAcc: 210
  }

  const that = this

  /*-------------------------------------init---------------------------------------*/
  let component = ''
  init()
  /*-------------------------------------init---------------------------------------*/

  /*------------------------------------common--------------------------------------*/

  this.getReturnCode = function getReturnCode() {
    const getReturnCode = {
      ajaxReturnCode: ajaxReturnCode,
      wrapperReturnCode: wrapperReturnCode
    }
    return getReturnCode
  }

  function PrintLog(title, message) {
    /*var ifrmLog = document.getElementById("divLog");
		if(typeof(ifrmLog)=="object"){
			//ifrmLog = ifrmLog.contentWindow || ifrmLog.contentDocument.document || ifrmLog.contentDocument;
			//ifrmLog.document.open();
			//ifrmLog.document.write("["+ParseDateToStr(new Date)+"]["+title+"] " + message + "<br>");
			//ifrmLog.document.close();
			ifrmLog.innerHTML += "["+ParseDateToStr(new Date)+"]["+title+"] " + message + "<br>";
		}*/
    try {
      //console.log("["+ParseDateToStr(new Date)+"]["+title+"] " + message);
    } catch (e) {
      //alert("PrintLog:\n["+ParseDateToStr(new Date)+"]["+title+"] " + message+"");
    }
  }

  function ParseDateToStr(Now) {
    const strYear = Now.getFullYear().toString()
    const iMonth = Now.getMonth() + 1
    let strMonth = iMonth.toString()
    if (strMonth.length < 2) strMonth = '0' + strMonth
    let strDay = Now.getDate().toString()
    if (strDay.length < 2) strDay = '0' + strDay
    let strHour = Now.getHours().toString()
    if (strHour.length < 2) strHour = '0' + strHour
    let strMinute = Now.getMinutes().toString()
    if (strMinute.length < 2) strMinute = '0' + strMinute
    let strSecond = Now.getSeconds().toString()
    if (strSecond.length < 2) strSecond = '0' + strSecond
    const strMilliSecond = Now.getMilliseconds().toString()
    return (
      strYear +
      '/' +
      strMonth +
      '/' +
      strDay +
      ' ' +
      strHour +
      ':' +
      strMinute +
      ':' +
      strSecond +
      '.' +
      strMilliSecond
    )
  }

  function init() {
    PrintLog('strat send port', '')

    try {
      let returnData = null

      for (let i = 0; i < listenPortData.length; i++) {
        ajaxReturnCode = '0'
        wrapperReturnCode = '0'
        returnData = sendFunc(
          that.sendUrl + ':' + listenPortData[i] + '/Server',
          '',
          '',
          '',
          that.debug,
          null,
          null,
          null
        )
        ajaxReturnCode = ajaxReturnCode_
        wrapperReturnCode = wrapperReturnCode_
        if (returnData.ajaxReturnCode == '0') {
          that.listenPort = listenPortData[i]
          component = returnData.data
          that.sendUrl += ':' + that.listenPort + '/main'
          if (component == 'eSECUREApplet') {
            that.appName = ''
            that.action = 'applet'
            //alert("執行eSECUREApplet");

            if (LoadJar() != '0') {
              //alert("Load jar 失敗")
              return false
            }
          }
          break
        } else if (returnData.ajaxReturnCode == '1048585') {
          break
        }
      }
    } catch (e) {
      //alert("read list port failure");
    }
  }

  function getPort(setPort, returnData) {
    if (returnData.returnValue == '0') {
      that.listenPort = setPort
      component = returnData.data

      that.sendUrl += ':' + that.listenPort + '/main'

      if (component == 'eSECUREApplet') {
        that.appName = ''
        that.action = 'applet'
        //alert("執行eSECUREApplet");

        if (LoadJar() != '0') {
          //alert("Load jar 失敗")
          return false
        }
      } else if (component == 'eSECUREActiveX') {
      }
    }
  }

  function padLeft(str, len) {
    str = ''
    ;+str
    return str.length >= len ? str : new Array(len - str.length + 1).join('0') + str
  }

  function checkTimeout(methodName) {
    let timeoutVal = 0

    for (const j in tiemMethodList) {
      const sub_key = j
      const sub_val = tiemMethodList[j]

      if (sub_key == methodName) {
        timeoutVal = sub_val
      }
    }

    return timeoutVal
  }

  function callMethodWithReturn(Dispatch, MethodName, Parameters, RtnType, callBackMethod) {
    return new Promise((resolve, reject) => {
      // Dispatch
      // DISPATCH_METHOD         0x1
      // DISPATCH_PROPERTYGET    0x2
      // DISPATCH_PROPERTYPUT    0x4
      // DISPATCH_PROPERTYPUTREF 0x8

      timeout = checkTimeout(MethodName)

      if (timeout != 0) {
        const indexVal = Parameters.indexOf('InsertFlag')

        if (indexVal != -1) {
          const cleanParameters = '[' + Parameters.replace(/[\n\r]+/g, '\\n') + ']'

          const parametersObj = JSON.parse(cleanParameters)
          console.log('Parsed JSON object:', parametersObj)

          for (let i = 0; i < parametersObj.length; i++) {
            if (parametersObj[i].ParameterName == 'InsertFlag') {
              if (parametersObj[i].DataValue.Value == '2') {
                timeout = null
              }
            }
          }
        }
      }

      sendRetunCode = '0'
      let paramStr = '{"Dispatch":' + Dispatch + ',"MethodName":"' + MethodName + '","Parameters":'
      if (Parameters.length > 0) paramStr += '[' + Parameters + ']'
      else paramStr += 'null'

      let rtnType = 3
      if (RtnType.localeCompare('void') === 0) rtnType = 0
      else if (RtnType.localeCompare('long') === 0) rtnType = 3
      else if (RtnType.localeCompare('BSTR') === 0) rtnType = 0x85

      paramStr += ',"RtnData":{"RtnDataType":' + rtnType + '}'

      paramStr += '}'
      ajaxReturnCode = '0'
      wrapperReturnCode = '0'
      const returnData = sendFunc(
        that.sendUrl,
        that.action,
        that.appName,
        paramStr,
        that.debug,
        timeout,
        function (result) {
          resolve(result)
        }
      )
      ajaxReturnCode = ajaxReturnCode_
      wrapperReturnCode = wrapperReturnCode_
    })
  }

  /*------------------------------------common--------------------------------------*/

  this.releaseActivex = function () {
    const returnData = sendFunc(
      that.sendUrl,
      'ReleaseClib',
      that.appName,
      '',
      that.debug,
      null,
      null,
      null
    )
    if (returnData == '1048585') {
      sendFunc(that.sendUrl, that.action, that.appName, 'Restart', that.debug, null, null, null)
    }
  }

  this.restartWrapper = function () {
    sendFunc(that.sendUrl, that.action, that.appName, 'Restart', that.debug, null, null, null)
  }

  this.ListReaders = function () {
    return callMethodWithReturn(1, 'ListReaders', '', 'long')
  }

  this.GetReaderNumber = function () {
    return callMethodWithReturn(1, 'GetReaderNumber', '', 'long')
  }

  this.GetReaderName = function (Offset) {
    let paramStr = ''
    if (Offset.length === 0) Offset = 0
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Offset","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Offset +
      '}}'
    return callMethodWithReturn(1, 'GetReaderName', paramStr, 'BSTR')
  }

  this.ConnectReader = function (pReaderName) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}'
    return callMethodWithReturn(1, 'ConnectReader', paramStr, 'long')
  }

  this.ConnectCard = function (pReaderName) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}'
    return callMethodWithReturn(1, 'ConnectCard', paramStr, 'long')
  }

  this.DisconnectReader = function (pReaderName) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}'
    return callMethodWithReturn(1, 'DisconnectReader', paramStr, 'long')
  }

  this.ReConnectCard = function (pReaderName, reset_flag) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"reset_flag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      reset_flag +
      '}}'
    return callMethodWithReturn(1, 'ReConnectCard', paramStr, 'long')
  }

  this.GetCardStatus = function () {
    return callMethodWithReturn(1, 'GetCardStatus', '', 'BSTR')
  }

  this.GetReaderStatus = function (pReaderName, AttribID) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"AttribID","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      AttribID +
      '}}'
    return callMethodWithReturn(1, 'GetReaderStatus', paramStr, 'BSTR')
  }

  this.ListReadersAndCards = function () {
    return callMethodWithReturn(1, 'ListReadersAndCards', '', 'BSTR')
  }

  this.ListReadersOnly = function () {
    return callMethodWithReturn(1, 'ListReadersOnly', '', 'BSTR')
  }

  this.ListEF1001Accounts = function () {
    return callMethodWithReturn(1, 'ListEF1001Accounts', '', 'long')
  }

  this.GetEF1001Account = function (AccountNo) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"AccountNo","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      AccountNo +
      '}}'
    return callMethodWithReturn(1, 'GetEF1001Account', paramStr, 'BSTR')
  }

  this.GetEF1001TotalAccounts = function () {
    return callMethodWithReturn(1, 'GetEF1001TotalAccounts', '', 'long')
  }

  this.ListEF1002Accounts = function () {
    return callMethodWithReturn(1, 'ListEF1002Accounts', '', 'long')
  }

  this.GetEF1002Account = function (AccountNo) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"AccountNo","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      AccountNo +
      '}}'
    return callMethodWithReturn(1, 'GetEF1002Account', paramStr, 'BSTR')
  }

  this.GetEF1002TotalAccounts = function () {
    return callMethodWithReturn(1, 'GetEF1002TotalAccounts', '', 'long')
  }

  this.GetIssuerBank = function () {
    return callMethodWithReturn(1, 'GetIssuerBank', '', 'BSTR')
  }

  this.GetICCRemark = function () {
    return callMethodWithReturn(1, 'GetICCRemark', '', 'BSTR')
  }

  this.ReadCardSN = function () {
    return callMethodWithReturn(1, 'ReadCardSN', '', 'BSTR')
  }

  this.VerifyPIN = function (pPwdStr) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPwdStr","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPwdStr +
      '"}}'
    return callMethodWithReturn(1, 'VerifyPIN', paramStr, 'long')
  }

  this.ChangePIN = function (
    pReaderName,
    pOldPwdStr,
    pNewPwdStr,
    pCardSerialNo,
    VerifyFlag,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pOldPwdStr","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pOldPwdStr +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pNewPwdStr","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pNewPwdStr +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"VerifyFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      VerifyFlag +
      '}}'
    return callMethodWithReturn(1, 'ChangePIN', paramStr, 'long', callBackMethod)
  }

  this.GetRespSNUM = function () {
    return callMethodWithReturn(1, 'GetRespSNUM', '', 'BSTR')
  }

  this.GetRespTAC = function () {
    return callMethodWithReturn(1, 'GetRespTAC', '', 'BSTR')
  }

  this.GetRespDateTime = function () {
    return callMethodWithReturn(1, 'GetRespDateTime', '', 'BSTR')
  }

  this.VerifyRN1andGenerateRN2 = function (RN1Len, pCpukEncryptedRN1, DsigLen, pSprkSignRN1) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RN1Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      RN1Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncryptedRN1","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncryptedRN1 +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"DsigLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      DsigLen +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSprkSignRN1","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSprkSignRN1 +
      '"}}'
    return callMethodWithReturn(1, 'VerifyRN1andGenerateRN2', paramStr, 'long')
  }

  this.getEncryptRN2 = function () {
    return callMethodWithReturn(1, 'GetEncryptRN2', '', 'BSTR')
  }

  this.getEncryptHashRN2 = function () {
    return callMethodWithReturn(1, 'GetEncryptHashRN2', '', 'BSTR')
  }

  this.getSessionKeyHash = function () {
    return callMethodWithReturn(1, 'GetSessionKeyHash', '', 'BSTR')
  }

  this.VerifySessionKeyHash = function (pCpukEncSessionKey, pSessionKeyHash) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}'
    return callMethodWithReturn(1, 'VerifySessionKeyHash', paramStr, 'long')
  }

  this.DESEncipher = function (pSessionKeyHash, pCpukEncSessionKey, DataLen, pData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"DataLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      DataLen +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pData +
      '"}}'
    return callMethodWithReturn(1, 'DESEncipher', paramStr, 'long')
  }

  this.DESDecipher = function (pSessionKeyHash, pCpukEncSessionKey, DataLen, pData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"DataLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      DataLen +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pData +
      '"}}'
    return callMethodWithReturn(1, 'DESDecipher', paramStr, 'long')
  }

  this.ConvertHexToInt = function (inLength, pInval) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"inLength","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      inLength +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pInval","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pInval +
      '"}}'
    return callMethodWithReturn(1, 'ConvertHexToInt', paramStr, 'BSTR')
  }

  this.ConvertIntToHex = function (inLength, pInval) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"inLength","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      inLength +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pInval","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pInval +
      '"}}'
    return callMethodWithReturn(1, 'ConvertIntToHex', paramStr, 'BSTR')
  }

  this.DES = function (Opflag, KeyLen, KeyVal, inData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Opflag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Opflag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"KeyLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      KeyLen +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"KeyVal","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      KeyVal +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"inData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      inData +
      '"}}'
    return callMethodWithReturn(1, 'DES', paramStr, 'long')
  }

  this.MAC = function (KeyLen, KeyVal, ICV, inLen, inData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"KeyLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      KeyLen +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"KeyVal","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      KeyVal +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"ICV","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      ICV +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"inLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      inLen +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"inData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      inData +
      '"}}'
    return callMethodWithReturn(1, 'MAC', paramStr, 'long')
  }

  this.GetAPIVersion = function () {
    return callMethodWithReturn(1, 'GetAPIVersion', '', 'BSTR')
  }

  this.DisconnectCard = function (pReaderName) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}'
    return callMethodWithReturn(1, 'DisconnectCard', paramStr, 'long')
  }

  this.GetRespData = function () {
    return callMethodWithReturn(1, 'GetRespData', '', 'BSTR')
  }

  this.GetRespLength = function () {
    return callMethodWithReturn(1, 'GetRespLength', '', 'long')
  }

  this.GetLastError = function () {
    return callMethodWithReturn(1, 'GetLastError', '', 'long')
  }

  this.AccountInquiry = function (
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountInquiry', paramStr, 'long', callBackMethod)
  }

  this.AccountPayment = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPayment', paramStr, 'long', callBackMethod)
  }

  this.AccountPayTax = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPayTax', paramStr, 'long', callBackMethod)
  }

  this.AccountTransfer = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountTransfer', paramStr, 'long', callBackMethod)
  }

  this.AccountWithdraw = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountWithdraw', paramStr, 'long', callBackMethod)
  }

  this.AccountInquiryEx = function (
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountInquiryEx', paramStr, 'long', callBackMethod)
  }

  this.AccountPaymentEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPaymentEx', paramStr, 'long', callBackMethod)
  }

  this.AccountPayTaxEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPayTaxEx', paramStr, 'long', callBackMethod)
  }

  this.AccountTransferEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountTransferEx', paramStr, 'long', callBackMethod)
  }

  this.AccountWithdrawEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountWithdrawEx', paramStr, 'long', callBackMethod)
  }

  this.AccountInquiryEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountInquiryEx2', paramStr, 'long')
  }

  this.AccountPaymentEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPaymentEx2', paramStr, 'long')
  }

  this.AccountPayTaxEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPayTaxEx2', paramStr, 'long')
  }

  this.AccountTransferEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountTransferEx2', paramStr, 'long')
  }

  this.AccountWithdrawEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountWithdrawEx2', paramStr, 'long')
  }

  this.AccountInquiryEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountInquiryEx3', paramStr, 'long', callBackMethod)
  }

  this.AccountInquiryEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountInquiryEx3Acc', paramStr, 'long', callBackMethod)
  }

  this.AccountInquiryEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountInquiryEx3Acc', paramStr, 'long', callBackMethod)
  }

  this.AccountPaymentEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPaymentEx3', paramStr, 'long', callBackMethod)
  }

  this.AccountPayTaxEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPayTaxEx3', paramStr, 'long', callBackMethod)
  }

  this.AccountTransferEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountTransferEx3', paramStr, 'long', callBackMethod)
  }

  this.AccountWithdrawEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountWithdrawEx3', paramStr, 'long')
  }

  this.CheckCardInsert = function (pReaderName) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}'
    return callMethodWithReturn(1, 'CheckCardInsert', paramStr, 'long')
  }

  this.ListWinscardInfo = function () {
    return callMethodWithReturn(1, 'ListWinscardInfo', '', 'long')
  }

  this.GetWinscardProperty = function (ListNo) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"ListNo","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      ListNo +
      '}}'
    return callMethodWithReturn(1, 'GetWinscardProperty', paramStr, 'BSTR')
  }

  this.ListEF1001AccountString = function () {
    return callMethodWithReturn(1, 'ListEF1001AccountString', '', 'BSTR')
  }

  this.ListEF1002AccountString = function () {
    return callMethodWithReturn(1, 'ListEF1002AccountString', '', 'BSTR')
  }

  this.AccountPurchase = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pStoreID,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pStoreID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pStoreID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPurchase', paramStr, 'long')
  }

  this.AccountPurchaseEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pStoreID,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pStoreID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pStoreID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPurchaseEx', paramStr, 'long')
  }

  this.AccountPurchaseEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pStoreID,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pStoreID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pStoreID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPurchaseEx2', paramStr, 'long')
  }

  this.AccountPurchaseEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pStoreID,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pStoreID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pStoreID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPurchaseEx3', paramStr, 'long')
  }

  this.VerifyPINSnd = function () {
    return callMethodWithReturn(1, 'VerifyPINSnd', '', 'long')
  }

  this.ChangePINSnd = function (pReaderName, pCardSerialNo, VerifyFlag, callBackMethod) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"VerifyFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      VerifyFlag +
      '}}'
    return callMethodWithReturn(1, 'ChangePINSnd', paramStr, 'long', callBackMethod)
  }

  this.AccountInquirySnd = function (
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountInquirySnd', paramStr, 'long')
  }

  this.AccountPaymentSnd = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPaymentSnd', paramStr, 'long')
  }

  this.AccountPayTaxSnd = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPayTaxSnd', paramStr, 'long')
  }

  this.AccountTransferSnd = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountTransferSnd', paramStr, 'long')
  }

  this.AccountWithdrawSnd = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountWithdrawSnd', paramStr, 'long')
  }

  this.AccountPurchaseSnd = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pStoreID,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pStoreID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pStoreID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPurchaseSnd', paramStr, 'long')
  }

  this.AccountInquirySndEx = function (
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountInquirySndEx', paramStr, 'long')
  }

  this.AccountPaymentSndEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPaymentSndEx', paramStr, 'long')
  }

  this.AccountPayTaxSndEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPayTaxSndEx', paramStr, 'long')
  }

  this.AccountTransferSndEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountTransferSndEx', paramStr, 'long')
  }

  this.AccountWithdrawSndEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountWithdrawSndEx', paramStr, 'long')
  }

  this.AccountPurchaseSndEx = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pStoreID,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pStoreID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pStoreID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPurchaseSndEx', paramStr, 'long')
  }

  this.AccountInquirySndEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountInquirySndEx2', paramStr, 'long')
  }

  this.AccountPaymentSndEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPaymentSndEx2', paramStr, 'long')
  }

  this.AccountPayTaxSndEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPayTaxSndEx2', paramStr, 'long')
  }

  this.AccountTransferSndEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountTransferSndEx2', paramStr, 'long')
  }

  this.AccountWithdrawSndEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountWithdrawSndEx2', paramStr, 'long')
  }

  this.AccountPurchaseSndEx2 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pStoreID,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pStoreID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pStoreID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountPurchaseSndEx2', paramStr, 'long')
  }

  this.AccountInquirySndEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountInquirySndEx3', paramStr, 'long', callBackMethod)
  }

  this.AccountPaymentSndEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPaymentSndEx3', paramStr, 'long', callBackMethod)
  }

  this.AccountPayTaxSndEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPayTaxSndEx3', paramStr, 'long', callBackMethod)
  }

  this.AccountTransferSndEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountTransferSndEx3', paramStr, 'long', callBackMethod)
  }

  this.AccountWithdrawSndEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountWithdrawSndEx3', paramStr, 'long')
  }

  this.AccountPurchaseSndEx3 = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pStoreID,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pSessionKeyHash,
    pCpukEncSessionKey
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pStoreID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pStoreID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPurchaseSndEx3', paramStr, 'long')
  }

  this.SetupSMSOTP = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    pSessionID,
    pEncURL,
    pTransactionCode,
    pFdChkCode,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}'
    return callMethodWithReturn(1, 'SetupSMSOTP', paramStr, 'long', callBackMethod)
  }

  this.SetupSMSOTPSnd = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pSessionID,
    pEncURL,
    pTransactionCode,
    pFdChkCode,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}'
    return callMethodWithReturn(1, 'SetupSMSOTPSnd', paramStr, 'long', callBackMethod)
  }

  this.SetupNetAccount = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    pSessionID,
    pEncURL,
    pTransactionCode,
    pFdChkCode,
    pID,
    pDateBirth,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pDateBirth","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pDateBirth +
      '"}}'
    return callMethodWithReturn(1, 'SetupNetAccount', paramStr, 'long', callBackMethod)
  }

  this.SetupNetAccountSnd = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pSessionID,
    pEncURL,
    pTransactionCode,
    pFdChkCode,
    pID,
    pDateBirth,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}},'
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pID +
      '"}},'
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pDateBirth","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pDateBirth +
      '"}}'
    return callMethodWithReturn(1, 'SetupNetAccountSnd', paramStr, 'long', callBackMethod)
  }

  this.SetupCommAccount = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    pSessionID,
    pBankCodeList,
    pCommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pBankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pBankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'SetupCommAccount', paramStr, 'long', callBackMethod)
  }

  this.SetupCommAccountSnd = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pSessionID,
    pBankCodeList,
    pCommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pBankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pBankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'SetupCommAccountSnd', paramStr, 'long', callBackMethod)
  }

  this.TransferProc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    SessionID,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    pShowMsg,
    BankCodeList,
    CommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      CommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'TransferProc', paramStr, 'long', callBackMethod)
  }

  this.TransferProcSnd = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    SessionID,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    pShowMsg,
    BankCodeList,
    CommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      CommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'TransferProcSnd', paramStr, 'long', callBackMethod)
  }

  this.GetInBankCode = function () {
    return callMethodWithReturn(1, 'GetInBankCode', '', 'BSTR')
  }

  this.FiscTransmit = function (inLength, inData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"inLength","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      inLength +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"inData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      inData +
      '"}}'
    return callMethodWithReturn(1, 'FiscTransmit', paramStr, 'long')
  }

  this.FiscCreateFile = function (inData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"inData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      inData +
      '"}}'
    return callMethodWithReturn(1, 'FiscCreateFile', paramStr, 'long')
  }

  this.FiscSelectParentDF = function () {
    return callMethodWithReturn(1, 'FiscSelectParentDF', '', 'long')
  }

  this.FiscSelectParentDFWithHeader = function () {
    return callMethodWithReturn(1, 'FiscSelectParentDFWithHeader', '', 'long')
  }

  this.FiscSelectDF = function (DF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"DF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      DF +
      '"}}'
    return callMethodWithReturn(1, 'FiscSelectDF', paramStr, 'long')
  }

  this.FiscSelectDFWithHeader = function (DF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"DF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      DF +
      '"}}'
    return callMethodWithReturn(1, 'FiscSelectDFWithHeader', paramStr, 'long')
  }

  this.FiscSelectEF = function (EF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"EF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      EF +
      '"}}'
    return callMethodWithReturn(1, 'FiscSelectEF', paramStr, 'long')
  }

  this.FiscSelectEFWithHeader = function (EF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"EF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      EF +
      '"}}'
    return callMethodWithReturn(1, 'FiscSelectEFWithHeader', paramStr, 'long')
  }

  this.FiscLockDF = function () {
    return callMethodWithReturn(1, 'FiscLockDF', '', 'long')
  }

  this.FiscUnlockDF = function (DF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"DF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      DF +
      '"}}'
    return callMethodWithReturn(1, 'FiscUnlockDF', paramStr, 'long')
  }

  this.FiscReadRecord = function (RecID) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RecID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      RecID +
      '"}}'
    return callMethodWithReturn(1, 'FiscReadRecord', paramStr, 'long')
  }

  this.FiscReadAllRecordS = function (RecID, InLe) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RecID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      RecID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InLe","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InLe +
      '}}'
    return callMethodWithReturn(1, 'FiscReadAllRecordS', paramStr, 'long')
  }

  this.FiscReadAllRecordE = function (RecID, InLe) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RecID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      RecID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InLe","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InLe +
      '}}'
    return callMethodWithReturn(1, 'FiscReadAllRecordE', paramStr, 'long')
  }

  this.FiscWriteRecord = function (RecLen, RecData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RecLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      RecLen +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RecData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      RecData +
      '"}}'
    return callMethodWithReturn(1, 'FiscWriteRecord', paramStr, 'long')
  }

  this.FiscWriteRecordWithTAC = function (Kq, IV, RecID, RecLen, Data) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Kq","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Kq +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"IV","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      IV +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RecID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      RecID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RecLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      RecLen +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Data","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Data +
      '"}}'
    return callMethodWithReturn(1, 'FiscWriteRecordWithTAC', paramStr, 'long')
  }

  this.FiscUpdateRecord = function (RecN, Len, Data) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"RecN","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      RecN +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Data","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Data +
      '"}}'
    return callMethodWithReturn(1, 'FiscUpdateRecord', paramStr, 'long')
  }

  this.FiscEraseEF = function () {
    return callMethodWithReturn(1, 'FiscEraseEF', '', 'long')
  }

  this.FiscBinaryAdd = function (Len, Data) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Data","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Data +
      '"}}'
    return callMethodWithReturn(1, 'FiscBinaryAdd', paramStr, 'long')
  }

  this.FiscVerifyPIN = function (PINCode) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"PINCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      PINCode +
      '"}}'
    return callMethodWithReturn(1, 'FiscVerifyPIN', paramStr, 'long')
  }

  this.FiscGenerateRandomNumber = function () {
    return callMethodWithReturn(1, 'FiscGenerateRandomNumber', '', 'long')
  }

  this.FiscTerminalAuthentication = function (KID, EncData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"KID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      KID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"EncData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      EncData +
      '"}}'
    return callMethodWithReturn(1, 'FiscTerminalAuthentication', paramStr, 'long')
  }

  this.FiscUnlockKey = function (EFID) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"EFID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      EFID +
      '"}}'
    return callMethodWithReturn(1, 'FiscUnlockKey', paramStr, 'long')
  }

  this.FiscUnlockPIN = function () {
    return callMethodWithReturn(1, 'FiscUnlockPIN', '', 'long')
  }

  this.FiscCardAuthentication = function (Kq, R1, R3) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Kq","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Kq +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"R1","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      R1 +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"R3","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      R3 +
      '"}}'
    return callMethodWithReturn(1, 'FiscCardAuthentication', paramStr, 'long')
  }

  this.FiscReadBinary = function () {
    return callMethodWithReturn(1, 'FiscReadBinary', '', 'long')
  }

  this.FiscSetSessionKey = function (Kq, Rand) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Kq","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Kq +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Rand","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Rand +
      '"}}'
    return callMethodWithReturn(1, 'FiscSetSessionKey', paramStr, 'long')
  }

  this.FiscUpdateRecordCiphered = function (Len, EncData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"EncData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      EncData +
      '"}}'
    return callMethodWithReturn(1, 'FiscUpdateRecordCiphered', paramStr, 'long')
  }

  this.FiscWriteRecordWithSNUMTAC = function (EFID, Len, Data) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"EFID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      EFID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Data","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Data +
      '"}}'
    return callMethodWithReturn(1, 'FiscWriteRecordWithSNUMTAC', paramStr, 'long')
  }

  this.FiscReadData = function (P1, P2, rLen) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"P1","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      P1 +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"P2","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      P2 +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"rLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      rLen +
      '}}'
    return callMethodWithReturn(1, 'FiscReadData', paramStr, 'long')
  }

  this.FiscUpdateData = function (P1, P2, Len, BData) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"P1","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      P1 +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"P2","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      P2 +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BData +
      '"}}'
    return callMethodWithReturn(1, 'FiscUpdateData', paramStr, 'long')
  }

  this.FiscListFile = function () {
    return callMethodWithReturn(1, 'FiscListFile', '', 'long')
  }

  this.FiscSelectAppletID = function (Len, AppletID) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"AppletID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      AppletID +
      '"}}'
    return callMethodWithReturn(1, 'FiscSelectAppletID', paramStr, 'long')
  }

  this.FiscSVCCreatePurseFile = function (Len, PEF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"PEF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      PEF +
      '"}}'
    return callMethodWithReturn(1, 'FiscSVCCreatePurseFile', paramStr, 'long')
  }

  this.FiscSVCGetInfoWithRn = function (PEF_ID, rLen) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"PEF_ID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      PEF_ID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"rLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      rLen +
      '}}'
    return callMethodWithReturn(1, 'FiscSVCGetInfoWithRn', paramStr, 'long')
  }

  this.FiscSVCLoading = function (PEF, LV, AData_Len, AData, LTAC) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"PEF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      PEF +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LV","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      LV +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"AData_Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      AData_Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"AData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      AData +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LTAC","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      LTAC +
      '"}}'
    return callMethodWithReturn(1, 'FiscSVCLoading', paramStr, 'long')
  }

  this.FiscSVCDeduct = function (PEF, DV, AData_Len, AData, DTAC, rLen) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"PEF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      PEF +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"DV","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      DV +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"AData_Len","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      AData_Len +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"AData","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      AData +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"DTAC","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      DTAC +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"rLen","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      rLen +
      '}}'
    return callMethodWithReturn(1, 'FiscSVCDeduct', paramStr, 'long')
  }

  this.FiscSVCReserval = function () {
    return callMethodWithReturn(1, 'FiscSVCReserval', '', 'long')
  }

  this.FiscSVCUpdateKey = function (Type, Block, Ccode) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Type","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Type +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Block","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Block +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"Ccode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      Ccode +
      '"}}'
    return callMethodWithReturn(1, 'FiscSVCUpdateKey', paramStr, 'long')
  }

  this.FiscSVCReadBalance = function (PEF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"PEF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      PEF +
      '"}}'
    return callMethodWithReturn(1, 'FiscSVCReadBalance', paramStr, 'long')
  }

  this.FiscSVCReadLoadingLog = function (PEF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"PEF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      PEF +
      '"}}'
    return callMethodWithReturn(1, 'FiscSVCReadLoadingLog', paramStr, 'long')
  }

  this.FiscSVCReadDeductLog = function (PEF) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"PEF","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      PEF +
      '"}}'
    return callMethodWithReturn(1, 'FiscSVCReadDeductLog', paramStr, 'long')
  }

  this.AboutBox = function () {
    return callMethodWithReturn(1, 'AboutBox', '', 'void')
  }

  this.SetLanguage = function (LangName) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LangName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      LangName +
      '"}}'
    return callMethodWithReturn(1, 'SetLanguage', paramStr, 'void')
  }

  /** 網銀相關 - 無障礙 */
  this.SetupSMSOTPAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    pSessionID,
    pEncURL,
    pTransactionCode,
    pFdChkCode,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}'
    return callMethodWithReturn(1, 'SetupSMSOTPAcc', paramStr, 'long', callBackMethod)
  }

  this.SetupSMSOTPSndAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pSessionID,
    pEncURL,
    pTransactionCode,
    pFdChkCode,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}'
    return callMethodWithReturn(1, 'SetupSMSOTPSndAcc', paramStr, 'long', callBackMethod)
  }

  this.SetupNetAccountAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    pSessionID,
    pEncURL,
    pTransactionCode,
    pFdChkCode,
    pID,
    pDateBirth,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pDateBirth","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pDateBirth +
      '"}}'
    return callMethodWithReturn(1, 'SetupNetAccountAcc', paramStr, 'long', callBackMethod)
  }

  this.SetupNetAccountSndAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pSessionID,
    pEncURL,
    pTransactionCode,
    pFdChkCode,
    pID,
    pDateBirth,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}},'
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pID +
      '"}},'
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pDateBirth","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pDateBirth +
      '"}}'
    return callMethodWithReturn(1, 'SetupNetAccountSndAcc', paramStr, 'long', callBackMethod)
  }

  this.TransferProc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    SessionID,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    pShowMsg,
    BankCodeList,
    CommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      CommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'TransferProc', paramStr, 'long', callBackMethod)
  }

  this.TransferProcAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    SessionID,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    pShowMsg,
    BankCodeList,
    CommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      CommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'TransferProcAcc', paramStr, 'long', callBackMethod)
  }

  this.TransferProcSndAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    SessionID,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    pShowMsg,
    BankCodeList,
    CommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      CommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'TransferProcSndAcc', paramStr, 'long', callBackMethod)
  }

  this.TransferNetProcAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    SessionID,
    pFdid,
    pFdChkCode,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    BankCodeList,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}'
    return callMethodWithReturn(1, 'TransferNetProcAcc', paramStr, 'long', callBackMethod)
  }

  this.TransferNetProcSndAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    SessionID,
    pFdid,
    pFdChkCode,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    BankCodeList,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}'
    return callMethodWithReturn(1, 'TransferNetProcSndAcc', paramStr, 'long', callBackMethod)
  }

  /** 交易 - 無障礙 */
  this.AccountInquiryEx2Acc = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountInquiryEx2Acc', paramStr, 'long')
  }

  this.AccountInquirySndEx2Acc = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountInquirySndEx2Acc', paramStr, 'long')
  }

  this.AccountInquirySndEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdChkCode,
    pAccountNumber,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccountNumber","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccountNumber +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountInquirySndEx3Acc', paramStr, 'long', callBackMethod)
  }

  this.AccountPaymentEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPaymentEx3Acc', paramStr, 'long', callBackMethod)
  }

  this.AccountPaymentSndEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pPaymentType,
    pCancelNo,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPaymentType","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPaymentType +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCancelNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCancelNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPaymentSndEx3Acc', paramStr, 'long', callBackMethod)
  }

  this.AccountPayTaxEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPayTaxEx3Acc', paramStr, 'long', callBackMethod)
  }

  this.AccountPayTaxSndEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountPayTaxSndEx3Acc', paramStr, 'long', callBackMethod)
  }

  this.AccountTransferAcc = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountTransferAcc', paramStr, 'long')
  }

  this.AccountTransferEx2Acc = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountTransferEx2Acc', paramStr, 'long')
  }

  this.AccountTransferEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pPassword,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountTransferEx3Acc', paramStr, 'long', callBackMethod)
  }

  this.AccountTransferSndAcc = function (
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountTransferSndAcc', paramStr, 'long')
  }

  this.AccountTransferSndEx2Acc = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}'
    return callMethodWithReturn(1, 'AccountTransferSndEx2Acc', paramStr, 'long')
  }

  this.AccountTransferSndEx3Acc = function (
    pReaderName,
    pTransactionCode,
    pFdid,
    pFdChkCode,
    pMoney,
    pImprtAccnt,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    LogServerFlag,
    LogClientFlag,
    pShowMsg,
    InsertFlag,
    pSessionKeyHash,
    pCpukEncSessionKey,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pTransactionCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pTransactionCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pMoney","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pMoney +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pImprtAccnt","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pImprtAccnt +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogServerFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogServerFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"LogClientFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      LogClientFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pShowMsg","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pShowMsg +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"InsertFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      InsertFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}'
    return callMethodWithReturn(1, 'AccountTransferSndEx3Acc', paramStr, 'long', callBackMethod)
  }

  /**新增 API */
  this.TransferNetProc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    SessionID,
    pFdid,
    pFdChkCode,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    BankCodeList,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}'
    return callMethodWithReturn(1, 'TransferNetProc', paramStr, 'long', callBackMethod)
  }

  this.TransferNetProcSnd = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    SessionID,
    pFdid,
    pFdChkCode,
    pAccount,
    pCardSerialNo,
    CardNoFlag,
    BankCodeList,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"SessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      SessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdid","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdid +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pFdChkCode","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pFdChkCode +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pAccount","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pAccount +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCardSerialNo","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCardSerialNo +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"CardNoFlag","DataType":3,"DataValue":{"Type":3,"Encode":0,"Value":' +
      CardNoFlag +
      '}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"BankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      BankCodeList +
      '"}}'
    return callMethodWithReturn(1, 'TransferNetProcSnd', paramStr, 'long', callBackMethod)
  }

  this.GetInBankAccount = function () {
    return callMethodWithReturn(1, 'GetInBankAccount', '', 'BSTR')
  }

  this.SetupCommAccountAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pPassword,
    pSessionID,
    pBankCodeList,
    pCommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pPassword","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pPassword +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pBankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pBankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'SetupCommAccountAcc', paramStr, 'long', callBackMethod)
  }

  this.SetupCommAccountSndAcc = function (
    pReaderName,
    pSessionKeyHash,
    pCpukEncSessionKey,
    pSessionID,
    pBankCodeList,
    pCommAccountList,
    pEncURL,
    callBackMethod
  ) {
    let paramStr = ''
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pReaderName","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pReaderName +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionKeyHash","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionKeyHash +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCpukEncSessionKey","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCpukEncSessionKey +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pSessionID","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pSessionID +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pBankCodeList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pBankCodeList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pCommAccountList","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pCommAccountList +
      '"}}' +
      ','
    paramStr +=
      '{"ParameterType":1,"ParameterName":"pEncURL","DataType":133,"DataValue":{"Type":5,"Encode":0,"Value":"' +
      pEncURL +
      '"}}'
    return callMethodWithReturn(1, 'SetupCommAccountSndAcc', paramStr, 'long', callBackMethod)
  }
}
