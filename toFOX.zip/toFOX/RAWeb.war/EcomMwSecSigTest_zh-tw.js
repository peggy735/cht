﻿//Larry 20190104 跨瀏覽器 =================================
document.write("<object id='CTBCPKIAPI' type='application/x-sm2certplugin' width='0' height='0'></object>");

//var ServletPath = "http://192.168.33.23:7003/RAWeb/signTest.do";
//document.write("<object id='CTBCPKIAPI' type='application/x-sm2certplugin'><param name='onload' value='pluginLoaded' /></object>");
//var ServletPath = "http://192.168.33.23:7003/RAWeb/dealTransEx.do";

//++Seek 20140417 url adjust to raweb location //seek 20160407 change to dynamic assignment
var urlpart = window.location.href.split("/");
var urllocation = urlpart[0] + "//" + urlpart[2];
//urllocation example: "http://192.168.33.23:7003";
//var urllocation = "http://10.0.4.11";
//end of ++Seek 20140417 url adjust to raweb location

var ServletPath = urllocation + "/RAWeb/signTest.do";
var ObjectVer="1.0.0.1"  //元件版號 元件換版後該變數要跟著調整 中間以"."號分隔

var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var base64DecodeChars = new Array(
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63,
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1,
    -1,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1,
    -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);

var component="";
checkComponentInstall();

function checkComponentInstall(){
	var rv = -1;
	
	var ua = navigator.userAgent;
  	if (navigator.appName == 'Microsoft Internet Explorer'){
	    var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
	    if (re.exec(ua) != null){
	    	rv = parseFloat( RegExp.$1 );
	      	var agentWeb = 'Microsoft webgolds';
	    }
 	} else if (navigator.appName == 'Netscape'){
	    var re  = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");  //for IE 11
	    if (re.exec(ua) != null)
	    rv = parseFloat( RegExp.$1 );
  	}
	

	var CTBC_FB = document.getElementById("CTBCPKIAPI");
	var ReturnValue = CTBC_FB.version;
	////console.log("CTBC_FB.version = "+ReturnValue);
	
	if(typeof ReturnValue != "undefined"){
		component = "activex"; 
		
	}else{
		//Larry 20180817
		if(rv==8||rv==9){
			component = "activex";
			alert("Please install component");
			
			//Larry 1018 language寫死
			//window.location.href="./Envdownload.jsp?lang=0";
			return;
		}

		component = "localserver";
  		
		
	}
}
	
/* fbtleSecure*/
function plugin0()
{
	return document.getElementById('CTBCPKIAPI');
}
//Larry 20180309
//SP11FileUpload_Control = plugin0();
if(component == "activex"){
	SP11FileUpload_Control = plugin0;
}

function load()
{
    //0 為英文 1為繁體中文 2為簡體中文 3為日文
    SP11FileUpload_Control().strLanguage=0;  //chrome第一次load網頁時，在此對property設值無效。因此需在每個script function內重新設值                         
}
function pluginLoaded() {
    //alert("Plugin Page loaded!");
}

function pluginValid()
{
    if(SP11FileUpload_Control().valid){
//        alert(SP11FileUpload_Control().echo("This plugin seems to be working!"));
          alert("This plugin seems to be working!");
    } else {
        alert("Plugin is not working :(");
    }
}

function showVersion()
{
alert(SP11FileUpload_Control().version);
}

function utf16to8(str) {
    var out, i, len, c;

    out = "";
    len = str.length;
    for(i = 0; i < len; i++) {
 c = str.charCodeAt(i);
 if ((c >= 0x0001) && (c <= 0x007F)) {
     out += str.charAt(i);
 } else if (c > 0x07FF) {
     out += String.fromCharCode(0xE0 | ((c >> 12) & 0x0F));
     out += String.fromCharCode(0x80 | ((c >>  6) & 0x3F));
     out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
 } else {
     out += String.fromCharCode(0xC0 | ((c >>  6) & 0x1F));
     out += String.fromCharCode(0x80 | ((c >>  0) & 0x3F));
 }
    }
    return out;
}

function base64encode(str) {
    var out, i, len;
    var c1, c2, c3;
    if (str == null) str = "";
 str = utf16to8(str);
 
 len = str.length;
    i = 0;
    out = "";
    while(i < len) {
 c1 = str.charCodeAt(i++) & 0xff;
 if(i == len)
 {
     out += base64EncodeChars.charAt(c1 >> 2);
     out += base64EncodeChars.charAt((c1 & 0x3) << 4);
     out += "==";
     break;
 }
 c2 = str.charCodeAt(i++);
 if(i == len)
 {
     out += base64EncodeChars.charAt(c1 >> 2);
     out += base64EncodeChars.charAt(((c1 & 0x3)<< 4) | ((c2 & 0xF0) >> 4));
     out += base64EncodeChars.charAt((c2 & 0xF) << 2);
     out += "=";
     break;
 }
 c3 = str.charCodeAt(i++);
 out += base64EncodeChars.charAt(c1 >> 2);
 out += base64EncodeChars.charAt(((c1 & 0x3)<< 4) | ((c2 & 0xF0) >> 4));
 out += base64EncodeChars.charAt(((c2 & 0xF) << 2) | ((c3 & 0xC0) >>6));
 out += base64EncodeChars.charAt(c3 & 0x3F);
    }
    //document.all['txt2'].value = out;
    return out;
}
//++Seek 20151106 generate DisplayXML for Feitian token
function genDisplayXML(input) {
    
	var line_patt = new RegExp("LINE=(.*?)\\|");
    var res = line_patt.exec(input);
	if (res[1] == null){
		alert("Display string error @ LINE");
		return -1;
	}
    var line = res[1];
	
    
    var elements = [];
    var res, patt;
	for (var i = 1; i <= line; i++) {
		patt = new RegExp("\\|TAG" + i + "=(.*?)\\|");
		res = patt.exec(input);
		if (res[1] == null){
			alert("display string error @ TAG"+i);
			return -1;
		}
		elements.push(res[1]);
	
		patt = new RegExp("\\|VALUE" + i + "=(.*?)\\|");
		if (i == line)
			patt = new RegExp("\\|VALUE" + i + "=(.*?)$");
	
		res = patt.exec(input);
		if (res[1] == null){
			alert("display string error @ VALUE"+i);
			return -1;
		}
		elements.push(res[1]);
	
		//alert(elements);
    }
	
	var displayXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><T><D>";
	for (var i=0;i<line*2;i+=2){
		displayXML+="<M><k>"+elements[i]+"</k>";
		displayXML+="<v>"+elements[i+1]+"</v></M>";
	}
	displayXML+="</D></T>";
	
	return displayXML;
}
//end of ++Seek 20151106 generate DisplayXML for Feitian token
function SecureData(choice,displayString) {
	////console.log("language="+document.getElementById("language").value);
	if(component == "activex"){
	
        document.getElementById('TextResult').innerHTML = '';
        document.getElementById('FileUploadResult').innerHTML = '';
         
		//SP11FileUpload_Control().strLanguage ="1"; 
		SP11FileUpload_Control().strLanguage = document.getElementById("language").value;//0 en, 1  cht,  2 zn

        //檢查抽拔卡狀態 //seek 20151217 no pinpad on Feitian
        //for (var idx = 0; idx < document.StockOrderForm.PullDeviceOut.length; idx++) {
        //  if (document.StockOrderForm.PullDeviceOut[idx].checked) {
        //      SP11FileUpload_Control().strPullDeviceOut=document.StockOrderForm.PullDeviceOut[idx].value;
        //      break;
        //  }
        //}
        
        //檢查動態鍵盤 //seek 20151217 no pinpad on Feitian
        //for (var idx = 0; idx < document.StockOrderForm.PinPad.length; idx++) {
        //  if (document.StockOrderForm.PinPad[idx].checked) {
        //      SP11FileUpload_Control().strPinPad=document.StockOrderForm.PinPad[idx].value;
        //      break;
        //  }
        //}

        //檢查動態圖形驗證碼
        //for (var idx = 0; idx < document.StockOrderForm.Captcha.length; idx++) {
       //   if (document.StockOrderForm.Captcha[idx].checked) {
        //      SP11FileUpload_Control().strCaptcha=document.StockOrderForm.Captcha[idx].value;
        //      SP11FileUpload_Control().strCaptchaLength=document.StockOrderForm.CaptchaLength.value;          
        //      break;
        //  }
       // }   
         SP11FileUpload_Control().strCaptcha = 1;
		 
		SP11FileUpload_Control().strUrl = ServletPath;
		SP11FileUpload_Control().strIssureName = "";
		SP11FileUpload_Control().strKeyUsage = "";//oca31:192
		SP11FileUpload_Control().strSubject = "OU=8220901-CTCB, OU=FXML";
		//SP11FileUpload_Control().strSubject="OU=8220901-CTCB&&OU=FXML";
		SP11FileUpload_Control().strNotAfter = "0";		                      
	   
	  //掃 所有的form data
		var submission_string = "";
		var nRc = 0;
		var strTxCode = "nothing", strFunction = "nothing", strBizId = "nothing", strSESSIONID = "nothing", strVERIFYUSER = "nothing", strCOUNTRYCODE = "nothing", strCUSTOMERID = "nothing", strUSERID = "nothing", strCAID = "nothing", strP1 = "nothing", strP2 = "nothing", strP3 = "nothing", strP4 = "nothing", strP5 = "nothing";
		var strSessionID = "nothing";
		var isUpload = "false"; //seek 20140427
		for (var form_loop = 0; form_loop < document.forms.length; form_loop++) {
			for (var elems = 0; elems < document.forms[form_loop].length; elems++) {
				if (document.forms[form_loop].elements[elems].name != "" && document.forms[form_loop].elements[elems].name != "szAToBCipher") {
					if (document.forms[form_loop].elements[elems].type == "radio" || document.forms[form_loop].elements[elems].type == "checkbox") {
						if (document.forms[form_loop].elements[elems].checked) {
							document.forms[form_loop].elements[elems].checked = true;
							submission_string += document.forms[form_loop].elements[elems].name + "=" + base64encode(document.forms[form_loop].elements[elems].value) + "&";
						} else {
							document.forms[form_loop].elements[elems].checked = false;
						}
					} else {
						if (document.forms[form_loop].elements[elems].type == "file") {
							//submission_string += "|S;e;P;a;R;a;T;e|!!" + document.forms[form_loop].elements[elems].name + "//" + "=" + document.forms[form_loop].elements[elems].value + "&";
				submission_string += "|S;e;P;a;R;a;T;e|!!" + document.forms[form_loop].elements[elems].name + "//" + "=" + base64encode(document.forms[form_loop].elements[elems].value) + "&";
							//seek 20140427
							if (document.forms[form_loop].elements[elems].value!=""){
								//alert(document.forms[form_loop].elements[elems].value);
								isUpload = "true";
							}
							//end of seek 20140427
						} else {
							submission_string += document.forms[form_loop].elements[elems].name + "=" + base64encode(document.forms[form_loop].elements[elems].value) + "&";
						}
						
					}
				}
			}
		}

	   //++Seek 20140509 add ip and mac parameter
		nRc = SP11FileUpload_Control().GetClientAddress();
		if (nRc != 0) {
			ShowErrorMessageCHT(nRc);
			return false;
		} else {
			submission_string += "ClientIP="+base64encode(SP11FileUpload_Control().strIPAddress)+"&";
			submission_string += "ClientMAC="+base64encode(SP11FileUpload_Control().strMacAddress)+"&";
		}
		//end of Seek 20140509 add ip and mac parameter
		
		//組MIME Data
		strSessionID = "TxCode=" + strTxCode + "&&Function=" + strFunction + "&&BizID=" + strBizId + "&&SESSIONID=" + strSESSIONID;
		strSessionID = strSessionID + "&&VERIFYUSER=" + strVERIFYUSER + "&&COUNTRYCODE=" + strCOUNTRYCODE + "&&CUSTOMERID=" + strCUSTOMERID;
		strSessionID = strSessionID + "&&CAID=" + strCAID + "&&P1=" + strP1 + "&&P2=" + strP2 + "&&P3=" + strP3 + "&&P4=" + strP4 + "&&P5=" + strP5 + "&&";
		SP11FileUpload_Control().strSessionID = strSessionID;
		//document.all.SignRowData.value = submission_string;
		//SP11FileUpload_Control().CreateMIMEEx(submission_string);
		var APURL = "";
		APURL = document.forms(0).action;
		//seek 20140427 mod
		if (choice=="1")
			SP11FileUpload_Control().strType = 1; //0:正式之上傳檔案;1:簽章測試;2:上傳測試
		else{
			SP11FileUpload_Control().strType = 0;
		}
		
		//end of seek 20140427 mod
		//SP11FileUpload_Control().strSubject = "OU=8220901-CTCB&&OU=FXML";
		SP11FileUpload_Control().strSubject = "CTBC";	//seek 20140514 for CFCA
		SP11FileUpload_Control().strNotAfter = "1";
		SP11FileUpload_Control().strIssureName = "";
		//SP11FileUpload_Control().strKeyUsage = "128&&192";//簽章憑證指定128&&192
		//SP11FileUpload_Control().strKeyUsage="192";//seek 20140514 for CFCA
		SP11FileUpload_Control().strKeyUsage="";//oca31:192
		SP11FileUpload_Control().strCertExpireBefore="30";//憑證到期前ㄧ個月預警
		//nRc = SP11FileUpload_Control().GenP11Signature(APURL, "", "");
		//SP11FileUpload_Control().strCaptchaType=document.all.strCaptchaType.value;	//圖形驗證碼類型	
	  
		//assign wording
		SetUIwordingCHT(SP11FileUpload_Control());
	  
		//++Seek 2011106 for Feitian token
		//var displayXML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><T><D><M><k>Receiver Name: </k><v>Mr.Chang简体</v></M><M><k>Amount: </k><v>123.23</v></M></D><E><M><k>Swift Number: </k><v>12345678</v></M></E></T>"
		var displayXML = genDisplayXML(displayString);
		if (displayXML == -1)
			return false;
		SP11FileUpload_Control().displayXML = displayXML;
		//end of ++Seek 2011106 for feitian token
		
		nRc = SP11FileUpload_Control().UploadP7SignedData(submission_string);

		
		if (nRc != 0) {
			//alert(nRc);
			ShowErrorMessageCHT(nRc); //seek 20140116
			//ParseErrorMessage(SP11FileUpload_Control().errMsg, 'DETAIL', nRc);
					if ( choice == 1 ){
					  document.getElementById("TextResult").innerHTML = "Fail";
					}else if ( choice == 2 ){
					  document.getElementById("FileUploadResult").innerHTML = "Fail";
					}
			
					
			//alert(SP11FileUpload_Control().errMsg);
			return false;
		} else {
				if(SP11FileUpload_Control().strCertExpireBefore!=""&&SP11FileUpload_Control().strExpireTime!="")
			{
				  //alert(SP11FileUpload_Control().strExpireTime);
					//var myObject = new Object();
				//myObject.deadline = SP11FileUpload_Control().strExpireTime;
				
				if(document.getElementById("language").value=="zh_TW")
				{	        	
					window.open(urllocation + "/RAWeb/RenewalNotice1.jsp?deadline="+ SP11FileUpload_Control().strExpireTime,"","Height=210px, Width=380px, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, status=no");
				}
				else if(document.getElementById("language").value=="zh_CN")
				{
					window.open(urllocation + "/RAWeb/RenewalNotice2.jsp?deadline="+ SP11FileUpload_Control().strExpireTime,"","Height=210px, Width=380px, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, status=no");
				}
				else //language = en_US
				{
					window.open(urllocation + "/RAWeb/RenewalNotice3.jsp?deadline="+ SP11FileUpload_Control().strExpireTime,"","Height=210px, Width=380px, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, status=no");
				}
			}
			//alert(ParseErrorMessage(SP11FileUpload_Control().errMsg, 'DETAIL'));
			//alert(SP11FileUpload_Control().szgenerateCipherData);  //簽章壓縮後的資料
			//alert(SP11FileUpload_Control().errMsg);
			
					if ( choice == 1 ){
					  document.getElementById("TextResult").innerHTML = "OK";
					}else if ( choice == 2 ){
					  document.getElementById("FileUploadResult").innerHTML = "OK";
					}
			
			
			return true;
		}
	}else{
		document.getElementById('TextResult').innerHTML = '';
        document.getElementById('FileUploadResult').innerHTML = '';
	
		$.blockUI({ fadeIn: 0 });
		var request = {
			func: 'UploadP7SignedData'
		};
	
		request.strLanguage = document.getElementById("language").value;//0 en, 1  cht,  2 zn
		request.strUrl = ServletPath;
		request.strIssureName = "";
		request.strKeyUsage = "";
		request.strSubject = "OU=8220901-CTCB, OU=FXML";
		request.strNotAfter = "0";
		
		//掃 所有的form data
		var submission_string = "";
		var nRc = 0;
		var strTxCode = "nothing", strFunction = "nothing", strBizId = "nothing", strSESSIONID = "nothing", strVERIFYUSER = "nothing", strCOUNTRYCODE = "nothing", strCUSTOMERID = "nothing", strUSERID = "nothing", strCAID = "nothing", strP1 = "nothing", strP2 = "nothing", strP3 = "nothing", strP4 = "nothing", strP5 = "nothing";
		var strSessionID = "nothing";
		for (var form_loop = 0; form_loop < document.forms.length; form_loop++) {
			for (var elems = 0; elems < document.forms[form_loop].length; elems++) {
				if (document.forms[form_loop].elements[elems].name != "" && document.forms[form_loop].elements[elems].name != "szAToBCipher") {
					if (document.forms[form_loop].elements[elems].type == "radio" || document.forms[form_loop].elements[elems].type == "checkbox") {
						if (document.forms[form_loop].elements[elems].checked) {
							document.forms[form_loop].elements[elems].checked = true;
							submission_string += document.forms[form_loop].elements[elems].name + "=" + base64encode(document.forms[form_loop].elements[elems].value) + "&";
							//submission_string += document.forms[form_loop].elements[elems].name + "=" + (document.forms[form_loop].elements[elems].value) + "&";
						} else {
							document.forms[form_loop].elements[elems].checked = false;
						}
					} else {
						if (document.forms[form_loop].elements[elems].type == "file") {									                         					
							var filename = document.forms[form_loop].elements[elems].name;
							submission_string += "|S;e;P;a;R;a;T;e|!!" + filename + "//" + "=" + base64encode("") + "&";
							
						} else {				
							submission_string += document.forms[form_loop].elements[elems].name + "=" + base64encode(document.forms[form_loop].elements[elems].value) + "&";
						}
					}
				}
			}
		}
		
		//組MIME Data
		strSessionID = "TxCode=" + strTxCode + "&&Function=" + strFunction + "&&BizID=" + strBizId + "&&SESSIONID=" + strSESSIONID;
		strSessionID = strSessionID + "&&VERIFYUSER=" + strVERIFYUSER + "&&COUNTRYCODE=" + strCOUNTRYCODE + "&&CUSTOMERID=" + strCUSTOMERID;
		strSessionID = strSessionID + "&&CAID=" + strCAID + "&&P1=" + strP1 + "&&P2=" + strP2 + "&&P3=" + strP3 + "&&P4=" + strP4 + "&&P5=" + strP5 + "&&";
		request.strSessionID = strSessionID;
		

		//seek 20140427 mod
		if (choice=="1")
			request.strType = choice; //0:正式之上傳檔案;1:簽章測試;2:上傳測試
		else{
			if (isUpload == "false")
				request.strType = 1;
			else
				request.strType = 0;
		}
		
		request.strSubject = "CTBC";
		request.strNotAfter = "1";
		request.strIssureName = "";
		request.strKeyUsage="";//oca31:192
		request.strFileMaxNum=1;	//max upload file
		
		var displayXML = genDisplayXML(displayString);
		
		//console.log("displayXML="+displayXML);
		
		if (displayXML == -1)
			return false;
		request.displayXML = displayXML;
		//end of ++Seek 2011106 for feitian token
		
		/** GetClientAddress **/
		var request_ipmac = {
			func: 'GetClientAddress'
		};
	
		sendHttpRequest(getCertServerUrl(), 'POST', JSON.stringify(request_ipmac), {
			onSuccess: function (responseText) {
				if (responseText) {
					var data = JSON.parse(responseText);
					var nRc = data.ret;
					if (nRc == 0) {
						submission_string += "ClientIP=" + base64encode(data.strIPAddres) + "&";
						submission_string += "ClientMAC=" + base64encode(data.strMacAddress) + "&";
						//console.log("submission_string := " + submission_string);
						request.submission_string = submission_string;
						UploadP7SignedDataCallback(request,choice);
					} else {
						if ( choice == 1 ){
							document.getElementById("TextResult").innerHTML = "Fail";
						}else if ( choice == 2 ){
							document.getElementById("FileUploadResult").innerHTML = "Fail";
						}
						
						alert(errorCode2Message(nRc, data));
						//console.log(errorCode2Message(nRc, data));
					}
				}
				
			},
			onError: function(nRc, data){
				alert(errorCode2Message(nRc, data));
				//console.log(errorCode2Message(nRc, data));
				$.unblockUI();
			}
		}, true);
	}
}

function UploadP7SignedDataCallback(request,choice) {
	//console.log(request);
	sendHttpRequest(getCertServerUrl(), 'POST', JSON.stringify(request), {
		onSuccess: function (responseText) {
			if (responseText) {
				//console.log(responseText);
				var data = JSON.parse(responseText);
				var nRc = data.ret;
				if (nRc == 0x0) {
					if (data.strCertExpireBefore != "" && data.strExpireTime != "") {
						if(document.getElementById("language").value=="zh_TW")
						{	        	
							window.open(urllocation + "/RAWeb/RenewalNotice1.jsp?deadline="+ data.strExpireTime,"","Height=210px, Width=380px, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, status=no");
						}
						else if(document.getElementById("language").value=="zh_CN")
						{
							window.open(urllocation + "/RAWeb/RenewalNotice2.jsp?deadline="+ data.strExpireTime,"","Height=210px, Width=380px, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, status=no");
						}
						else //language = en_US
						{
							window.open(urllocation + "/RAWeb/RenewalNotice3.jsp?deadline="+ data.strExpireTime,"","Height=210px, Width=380px, toolbar=no, menubar=no, scrollbars=no, resizable=no, location=no, status=no");
						}
					}
					alert(ParseErrorMessage(data.errMsg, 'DETAIL'));
					//updateTransResult(true); 
					if ( choice == 1 ){
					  document.getElementById("TextResult").innerHTML = "OK";
					}else if ( choice == 2 ){
					  document.getElementById("FileUploadResult").innerHTML = "OK";
					}
					
					$.unblockUI();
				} else {
					if ( choice == 1 ){
					  document.getElementById("TextResult").innerHTML = "Fail";
					}else if ( choice == 2 ){
					  document.getElementById("FileUploadResult").innerHTML = "Fail";
					}
					alert(errorCode2Message(nRc, data));
					//updateTransResult(false); 
					$.unblockUI();
				}
			}
		},
		onError: function(nRc, data){
			alert(errorCode2Message(nRc, data));
			$.unblockUI();
		}
	}, true);
}

//++Seek 20140318 change ui lang dynamically
function SetUIwordingCHT(component){
	switch (component.strLanguage){
		case 0: //en
		case "0":
		{
			component.strStaticPINWinText = "Enter PIN Code"; //"輸入PIN視窗";
			component.strStaticChangePINWinText = "Change Password"; // "輸入Change PIN dlg視窗";  	
			component.strStaticEnterPIN = "Please Enter Token PIN Code"; // "输入PIN";
			component.strStaticCaptcha = "Captcha"; // "Captcha";
			component.strStaticOldPIN = "Old Password"; // "Old PIN";
			component.strStaticNewPIN = "New Password"; // "New PIN";
			component.strStaticREenterPIN = "Confirm Password"; // "REenter PIN";
			component.strStaticCert = "Selected Cert CN"; // "Cert CN";	
			component.strStaticBtnCancel = "Cancel";
			component.strStaticChangePINDefault = "Please do not enter default password";
			component.strStaticChangePINMismatch = "Content of New PIN Code and confirm PIN Code are not consistent";
			component.strStaticPINLock = "Token has been locked";
			component.strStaticLoginWinText = "Certificate management";
			component.strStaticPINError = "Password Error";
			component.strStaticLoginFail = "Password Error";
			component.strStaticFileWinText = "File List";
			component.strStaticFilePath = "File Path";
			component.strStaticFileAdd = "Add";
			component.strStaticFileClear = "Clear";
			component.strStaticFileUpload = "Upload";
			component.strStaticFileLimitWinText = "Upload file number limit";
			component.strStaticFileNumLimit = "Max upload file number";
			//component.strStaticFileProgressWinText = "Chinatrust";
			component.strStaticFileProgressWinText = "Data Processing";
			component.strStaticSec = "Sec";
			component.strStaticRePlug = "Please pull out and plug in the certificate device";
			component.strStaticCertWinText = "Please choose a certificate";
			component.strStaticCertSub = "Subject";
			component.strStaticCertNotAfter = "Expire";
			component.strStaticProgressWinText = "Data Processing";
			component.strStaticBtnOK = "Confirm";
			component.strStaticBtnClear = "Correct";
		}
		break;
		case 1: //tw
		case "1":
		{
			component.strStaticPINWinText = "輸入密碼"; //"輸入PIN視窗";
			component.strStaticChangePINWinText = "變更密碼"; // "輸入Change PIN dlg視窗";  	
			component.strStaticEnterPIN = "請輸入憑證載具密碼"; // "输入PIN";
			component.strStaticCaptcha = "圖形驗證碼"; // "Captcha";
			component.strStaticOldPIN = "舊密碼"; // "Old PIN";
			component.strStaticNewPIN = "新密碼"; // "New PIN";
			component.strStaticREenterPIN = "確認新密碼"; // "REenter PIN";
			component.strStaticCert = "已選取Cert CN"; // "Cert CN";
			component.strStaticLoginFail = "密碼錯誤";
			
			component.strStaticBtnCancel = "取消";
			component.strStaticChangePINDefault = "請勿輸入預設密碼";
			component.strStaticChangePINMismatch = "新密碼和確認新密碼不一致";
			component.strStaticPINLock = "已鎖碼";
			component.strStaticLoginWinText = "憑證管理";
			component.strStaticPINError = "密碼錯誤";
			component.strStaticFileWinText = "檔案列表";
			component.strStaticFilePath = "檔案路徑";
			component.strStaticFileAdd = "加入";
			component.strStaticFileClear = "清除";
			component.strStaticFileUpload = "上傳";
			component.strStaticFileLimitWinText = "上傳檔案限制";
			component.strStaticFileNumLimit = "最多上傳檔案數量";
			//component.strStaticFileProgressWinText = "中國信託";
			component.strStaticFileProgressWinText = "資料處理中";
			component.strStaticSec = "秒";
			component.strStaticRePlug = "請拔插憑證載具";
			component.strStaticCertWinText = "請選擇一張憑證";
			component.strStaticCertSub = "主旨";
			component.strStaticCertNotAfter = "到期日";
			component.strStaticProgressWinText = "資料處理中";
			component.strStaticBtnOK = "確認";
			component.strStaticBtnClear = "更正";
		}
		break;
		case 2: //cn
		case "2":
		{
			component.strStaticPINWinText = "输入密码"; //"輸入PIN視窗";
			component.strStaticChangePINWinText = "变更密码"; // "輸入Change PIN dlg視窗";  	
			component.strStaticEnterPIN = "请输入证书载具密码"; // "输入PIN";
			component.strStaticCaptcha = "图形验证码"; // "Captcha";
			component.strStaticOldPIN = "旧密码"; // "Old PIN";
			component.strStaticNewPIN = "新密码"; // "New PIN";
			component.strStaticREenterPIN = "确认新密码"; // "REenter PIN";
			component.strStaticCert = "已选取Cert CN"; // "Cert CN";
			component.strStaticLoginFail = "密码错误";
			
			component.strStaticBtnCancel = "取消";
			component.strStaticChangePINDefault = "请勿输入预设密码";
			component.strStaticChangePINMismatch = "新密码和确认新密码不一致";
			component.strStaticPINLock = "已锁码";
			component.strStaticLoginWinText = "证书管理";
			component.strStaticPINError = "密码错误";
			component.strStaticFileWinText = "档案列表";
			component.strStaticFilePath = "档案路径";
			component.strStaticFileAdd = "加入";
			component.strStaticFileClear = "清除";
			component.strStaticFileUpload = "上传";
			component.strStaticFileLimitWinText = "上传档案限制";
			component.strStaticFileNumLimit = "最多上传档案数量";
			//component.strStaticFileProgressWinText = "中国信托";
			component.strStaticFileProgressWinText = "资料处理中";			
			component.strStaticSec = "秒";
			component.strStaticRePlug = "请拔插证书载具";
			component.strStaticCertWinText = "请选择一张证书";
			component.strStaticCertSub = "主旨";
			component.strStaticCertNotAfter = "到期日";
			component.strStaticProgressWinText = "资料处理中";
			component.strStaticBtnOK = "确认";
			component.strStaticBtnClear = "更正";
		}
		break;
	}
}
//end of Seek 20140318 change ui lang dynamically

function getErrorCode(errMsg, name){
  var vars = errMsg.split("&&");
  var varStr = '';
  for (var i=0; i < vars.length; i++) {
     var pair = vars[i].split("=");
     if ( pair[0] == name ) {
     	varStr=pair[1];
     }	
  }	
  return varStr;
}

function ParseErrorMessage(errMsg, name){
  var vars = errMsg.split("&&");
  var varStr = '';
  for (var i=0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if ( pair[0] == name ) {
      var rep = pair[1].replace(/\\u/g, "||");
      //alert("rep --> " + rep.toUpperCase() + "---");
      rep = rep.toUpperCase();
      var varArr = rep.split("||");
      for (var j=1; j < varArr.length; j++) {
          var uni = '"\\u' + varArr[j]+'"';
          //alert(varArr[j]  );
          if (/^[A-F\d]{4}$/.test(varArr[j])){
            varStr = varStr + eval(uni);
          }
          //alert("varStr = " + varStr);
      }      
      return varStr;
    }
  }
  alert('Query Variable ' + name  + ' not found');
  //ShowErrorMessage(nRc);
}

//++Seek 20140110
/* CHT元件所使用的顯示錯誤訊息函式(新增) - Start */
function GetErrorMessageCHT(nRc) {
	//console.log("nRc="+nRc);
  if(nRc == 0x82000001)
  {/* 0x82開頭為自訂Token的錯誤代碼 */
  	ret_msg = "錯誤代碼：0x82000001  說明：CRYPTO_PKCS7_TYPE_ERROR: Crypto TYPE錯誤";
  }else if(nRc == 0x82000002)
  {
    ret_msg = "錯誤代碼：0x82000002  說明：CRYPTO_PKCS7_GET_SIGNER: Crypto SIGNE錯誤";
  }else if(nRc == 0x82000003)
  {
    ret_msg = "錯誤代碼：0x82000003  說明：CRYPTO_PKCS7_SIGN_ERROR: Crypto SIGN錯誤";
  }else if(nRc == 0x82000004)
  {
		ret_msg = "錯誤代碼：0x82000004  說明：CRYPTO_PKCS7_VERIFY_FAIL: Crypto VERIFY錯誤"; 
  }else if(nRc == 0x82000005)
  {
		ret_msg = "錯誤代碼：0x82000005  說明：CRYPTO_PKCS7_ENCRYPT_ERROR: Crypto ENCRYPT錯誤";
  }else if(nRc == 0x82000006)
  {
		ret_msg = "錯誤代碼：0x82000006  說明：CRYPTO_PKCS7_DECRYPT_FAIL: Crypto DECRYPT錯誤";
  }else if(nRc == 0x82000026)
  {
		ret_msg = "錯誤代碼：0x82000026  說明：憑證解析錯誤(X509_NAME_get_index_by_NID錯誤)";
  }else if(nRc == 0x82000011)
  {
		ret_msg = "錯誤代碼：0x82000011  說明：時間格式轉換錯誤";
  }else if(nRc == 0x82000021)
  {
		ret_msg = "錯誤代碼：0x82000021  說明：找不到載具驅動函式庫";
  }else if(nRc == 0x82000022)
  {
		ret_msg = "錯誤代碼：0x82000022  說明：產生CSR過程中發生X509_REQ_sign錯誤";
  }else if(nRc == 0x82000023)
  {
		ret_msg = "錯誤代碼：0x82000023  說明：檢驗CSR內容時發現找不到金鑰";
  }else if(nRc == 0x82000024)
  {
		ret_msg = "錯誤代碼：0x82000024  說明：檢驗CSR內容時發現X509_REQ_verify錯誤";
  }else if(nRc == 0x82000025)
  {
		ret_msg = "錯誤代碼：0x82000025  說明：憑證內容讀取錯誤(X509_NAME_print_ex錯誤)";
  }else if(nRc == 0x82000026)
  {
		ret_msg = "錯誤代碼：0x82000026  說明：憑證解析錯誤(X509_NAME_get_index_by_NID錯誤)";
  }else if(nRc == 0x82000031)
  {
		ret_msg = "錯誤代碼：0x82000031  說明：載具內找不到特定的object";
  }else if(nRc == 0x81000001)
  {/* 0x81開頭為元件所定義的錯誤代碼 */
		ret_msg = "錯誤代碼：0x81000001  說明：使用者取消操作";
  }else if(nRc == 0x81000002)
  {
		ret_msg = "錯誤代碼：0x81000002  說明：未輸入載具密碼";
  }else if(nRc == 0x81000003)
  {
		ret_msg = "錯誤代碼：0x81000003  說明：未輸入圖形辨識碼";
  }else if(nRc == 0x81000004)
  {
		ret_msg = "錯誤代碼：0x81000004  說明：圖形辨識碼輸入錯誤";
  }else if(nRc == 0x81000005)
  {
		ret_msg = "錯誤代碼：0x81000005  說明：動態鍵盤確定鍵輸入錯誤";
  }else if(nRc == 0x81000006)
  {
		ret_msg = "錯誤代碼：0x81000006  說明：輸入新密碼與再次輸入新密碼不相符";
  }else if(nRc == 0x81000007)
  {
		ret_msg = "錯誤代碼：0x81000007  說明：未在指定時間內執行插拔載具動作";
  }else if(nRc == 0x81000008)
  {
		ret_msg = "錯誤代碼：0x81000008  說明：非合法網域使用";
  }else if(nRc == 0x81000009)
  {
		ret_msg = "錯誤代碼：0x81000009  說明：找不到載具驅動函式庫";
  }else if(nRc == 0x8100000A)
  { 
		ret_msg = "錯誤代碼：0x8100000A  說明：找不到載具";
  }else if(nRc == 0x8100000B)
  {
		ret_msg = "錯誤代碼：0x8100000B  說明：憑證不存在或使用者未點選";
  }else if(nRc == 0x8100000C)
  {
		ret_msg = "錯誤代碼：0x8100000C  說明：載具中不存在任何金鑰";
  }else if(nRc == 0x8100000D)
  {
		ret_msg = "錯誤代碼：0x8100000D  說明：憑證有錯誤";
  }else if(nRc == 0x8100000E)
  {
		ret_msg = "錯誤代碼：0x8100000E  說明：找不到和憑證相對應的金鑰";
  }else if(nRc == 0x8100000F)
  {
		ret_msg = "錯誤代碼：0x8100000F  說明：載具中找不到Object(金鑰和憑證)";
  }else if(nRc == 0x81000010)
  {
		ret_msg = "錯誤代碼：0x81000010  說明：簽章輸出資料錯誤(長度=0)";
  }else if(nRc == 0x81000011)
  {
		ret_msg = "錯誤代碼：0x81000011  說明：拒絕重複寫入憑證"; 
  }else if(nRc == 0x81000012)
  {
		ret_msg = "錯誤代碼：0x81000012  說明：載具Session開啟失敗"; 
  }else if(nRc == 0x81000013)
  {
		ret_msg = "錯誤代碼：0x81000013  說明：讀取載具資訊失敗"; 
  }else if(nRc == 0x81000100)
  {
		ret_msg = "錯誤代碼：0x81000100  說明：找不到Cilent端IP資訊";
  }else if(nRc == 0x81000101)
  {
		ret_msg = "錯誤代碼：0x81000101  說明：找不到Cilent端MAC資訊";
  }else if(nRc == 0x81000102)
  {
		ret_msg = "錯誤代碼：0x81000102  說明：MIME Encode過程發生錯誤";
  }else if(nRc == 0x81000103)
  {
		ret_msg = "錯誤代碼：0x81000103  說明：MIME Encode attach檔案時發生錯誤";
  }else if(nRc == 0x81000104)
  {
		ret_msg = "錯誤代碼：0x81000104  說明：註冊檔資料型態錯誤";		
  }
  //++Seek 20140417 from chars: p11 error code changed to single error msg again.
  else if(nRc < 0x81000000)
  {
		ret_msg = "錯誤代碼："+"0x"+parseInt(nRc, 10).toString(16)+"  說明：PKCS#11 錯誤";
  }
  // else if(nRc == 0x00000001)
  // {/* 若非0x80或0x81開頭為PKCS11函式庫定義的錯誤代碼(由PKCS #11 模組回覆) */
			// ret_msg = "錯誤代碼：0x00000001  說明：CKR_CANCEL: 函式異常終止";
  // }else if(nRc == 0x00000002)
  // {
		// ret_msg = "錯誤代碼：0x00000002  說明：CKR_HOST_MEMORY: 記憶體配置失敗";
  // }else if(nRc == 0x00000003)
  // {
		// ret_msg = "錯誤代碼：0x00000003  說明：CKR_SLOT_ID_INVALID: 指定的slot ID無效";
  // }else if(nRc == 0x00000005)
  // {
		// ret_msg = "錯誤代碼：0x00000005  說明：CKR_GENERAL_ERROR: 遇到了一個無法恢復的錯誤";
  // }else if(nRc == 0x00000006)
  // {
		// ret_msg = "錯誤代碼：0x00000006  說明：CKR_FUNCTION_FAILED: 請求的函式無法被執行";
  // }else if(nRc == 0x00000007)
  // {
		// ret_msg = "錯誤代碼：0x00000007  說明：CKR_ARGUMENTS_BAD: 輸入參數錯誤";
  // }else if(nRc == 0x00000020)
  // {
		// ret_msg = "錯誤代碼：0x00000020  說明：CKR_DATA_INVALID: 加密操作的明文輸入數據是無效的";
  // }else if(nRc == 0x00000021)
  // {
		// ret_msg = "錯誤代碼：0x00000021  說明：CKR_DATA_LEN_RANGE: 加密操作的明文輸入數據長度有誤";
  // }else if(nRc == 0x00000030)
  // {
		// ret_msg = "錯誤代碼：0x00000030  說明：CKR_DEVICE_ERROR: 載具異常";
  // }else if(nRc == 0x00000031)
  // {
		// ret_msg = "錯誤代碼：0x00000031  說明：CKR_DEVICE_MEMORY: 載具沒有足夠的記憶體空間";
  // }else if(nRc == 0x00000032)
  // {
		// ret_msg = "錯誤代碼：0x00000032  說明：CKR_DEVICE_REMOVED: 函式執行過程中載具被移除";
  // }else if(nRc == 0x00000040)
  // {
		// ret_msg = "錯誤代碼：0x00000040  說明：CKR_ENCRYPTED_DATA_INVALID: 解密操作的加密輸入為無效密文";
  // }else if(nRc == 0x00000041)
  // {
		// ret_msg = "錯誤代碼：0x00000041  說明：CKR_ENCRYPTED_DATA_LEN_RANGE: 解密操作的加密輸入長度有誤而成為無效密文";
  // }else if(nRc == 0x00000050)
  // {
		// ret_msg = "錯誤代碼：0x00000050  說明：CKR_FUNCTION_CANCELED: 函式在執行中被取消";
  // }else if(nRc == 0x00000051)
  // {
		// ret_msg = "錯誤代碼：0x00000051  說明：CKR_FUNCTION_NOT_PARALLEL: 在指定的session中沒有函式併行執行";
  // }else if(nRc == 0x00000054)
  // {
		// ret_msg = "錯誤代碼：0x00000054  說明：CKR_FUNCTION_NOT_SUPPORTED: Cryptoki函式庫不支援該請求函式";
  // }else if(nRc == 0x00000060)
  // {
		// ret_msg = "錯誤代碼：0x00000060  說明：CKR_KEY_HANDLE_INVALID: 指定的密鑰handle無效";
  // }else if(nRc == 0x00000062)
  // {
		// ret_msg = "錯誤代碼：0x00000062  說明：CKR_KEY_SIZE_RANGE: 儘管請求密鑰加密操作原則上可以執行，但該Cryptoki函式庫實際上並不能完成，這是因為提供的密鑰的尺寸超出了它能管理的密鑰尺寸的範圍";
  // }else if(nRc == 0x00000063)
  // {
		// ret_msg = "錯誤代碼：0x00000063  說明：CKR_KEY_TYPE_INCONSISTENT: 指定的密鑰不是配合指定的機制使用的正確類型的密鑰";
  // }else if(nRc == 0x00000082)
  // {
		// ret_msg = "錯誤代碼：0x00000082  說明：CKR_OBJECT_HANDLE_INVALID: object handle無效";
  // }else if(nRc == 0x000000A0)
  // {
		// ret_msg = "錯誤代碼：0x000000A0  說明：CKR_PIN_INCORRECT: 密碼驗證失敗";
  // }else if(nRc == 0x000000A1)
  // {
		// ret_msg = "錯誤代碼：0x000000A1  說明：CKR_PIN_INVALID: 輸入的PIN碼含無效字符，或與密碼強度設定不符";
  // }else if(nRc == 0x000000A2)
  // {
		// ret_msg = "錯誤代碼：0x000000A2  說明：CKR_PIN_LEN_RANGE: 輸入的PIN碼長度太長或太短";
  // }else if(nRc == 0x000000A3)
  // {
		// ret_msg = "錯誤代碼：0x000000A3  說明：CKR_PIN_EXPIRED: 載具PIN碼到期";
  // }else if(nRc == 0x000000A4)
  // {
		// ret_msg = "錯誤代碼：0x000000A4  說明：CKR_PIN_LOCKED: 載具PIN碼鎖定";
  // }else if(nRc == 0x000000B0)
  // {
		// ret_msg = "錯誤代碼：0x000000B0  說明：CKR_SESSION_CLOSED: 函式執行過程中Session被關閉";
  // }else if(nRc == 0x000000B1)
  // {
		// ret_msg = "錯誤代碼：0x000000B1  說明：CKR_SESSION_COUNT: Session開啟失敗，因為載具已開啟太多Session";
  // }else if(nRc == 0x000000B3)
  // {
		// ret_msg = "錯誤代碼：0x000000B3  說明：CKR_SESSION_HANDLE_INVALID: Session handle無效";
  // }else if(nRc == 0x000000B4)
  // {
		// ret_msg = "錯誤代碼：0x000000B4  說明：CKR_SESSION_PARALLEL_NOT_SUPPORTED: 載具不支援併行Session";
  // }else if(nRc == 0x000000B5)
  // {
		// ret_msg = "錯誤代碼：0x000000B5  說明：CKR_SESSION_READ_ONLY: Session為唯讀因此無法完成想要的執行動作";
  // }else if(nRc == 0x000000B6)
  // {
		// ret_msg = "錯誤代碼：0x000000B6  說明：CKR_SESSION_EXISTS: Session已經開啟因此載具無法被初始化";
  // }else if(nRc == 0x000000B7)
  // {
		// ret_msg = "錯誤代碼：0x000000B7  說明：CKR_SESSION_READ_ONLY_EXISTS: 唯讀Session已經存在因此SO無法登入";
  // }else if(nRc == 0x000000B8)
  // {
		// ret_msg = "錯誤代碼：0x000000B8  說明：CKR_SESSION_READ_WRITE_SO_EXISTS: 讀寫SO Session已經存在，因此無法開啟唯讀Session";
  // }else if(nRc == 0x000000C0)
  // {
		// ret_msg = "錯誤代碼：0x000000C0  說明：CKR_SIGNATURE_INVALID: 簽章無效";
  // }else if(nRc == 0x000000C1)
  // {
		// ret_msg = "錯誤代碼：0x000000C1  說明：CKR_SIGNATURE_LEN_RANGE: 簽章長度有誤而成為無效簽章";
  // }else if(nRc == 0x000000E0)
  // {
		// ret_msg = "錯誤代碼：0x000000E0  說明：CKR_TOKEN_NOT_PRESENT: 載具不存在";
  // }else if(nRc == 0x000000E1)
  // {
		// ret_msg = "錯誤代碼：0x000000E1  說明：CKR_TOKEN_NOT_RECOGNIZED: Cryptoki函式庫或slot無法識別該載具";
  // }else if(nRc == 0x000000E2)
  // {
		// ret_msg = "錯誤代碼：0x000000E2  說明：CKR_TOKEN_WRITE_PROTECTED: 載具有防止寫入保護，因此無法執行請求的動作";
  // }else if(nRc == 0x00000100)
  // {
		// ret_msg = "錯誤代碼：0x00000100  說明：CKR_USER_ALREADY_LOGGED_IN: 該使用者已經登入，無法允許重複登入";
  // }else if(nRc == 0x00000101)
  // {
		// ret_msg = "錯誤代碼：0x00000101  說明：CKR_USER_NOT_LOGGED_IN: 使用者未登入";
  // }else if(nRc == 0x00000102)
  // {
		// ret_msg = "錯誤代碼：0x00000102  說明：CKR_USER_PIN_NOT_INITIALIZED: PIN碼尚未被初始化";
  // }else if(nRc == 0x00000103)
  // {
		// ret_msg = "錯誤代碼：0x00000103  說明：CKR_USER_TYPE_INVALID: 使用者類型無效(有效類型為CKU_SO/CKU_USER)";
  // }else if(nRc == 0x00000104)
  // {
		// ret_msg = "錯誤代碼：0x00000104  說明：CKR_USER_ANOTHER_ALREADY_LOGGED_IN:已經有其他使用者透過同一個應用程式登入，因此無法再允許登入";
  // }else if(nRc == 0x00000105)
  // {
		// ret_msg = "錯誤代碼：0x00000105  說明：CKR_USER_TOO_MANY_TYPES: 已經有其他使用者透過另一個應用程式登入，因此無法再允許登入";
  // }else if(nRc == 0x00000150)
  // {
		// ret_msg = "錯誤代碼：0x00000150  說明：CKR_BUFFER_TOO_SMALL: 緩衝區不足";
  // }else if(nRc == 0x00000190)
  // {
		// ret_msg = "錯誤代碼：0x00000190  說明：CKR_CRYPTOKI_NOT_INITIALIZED: Cryptoki函式庫未初始化因而函數不能執行";
  // }
  //end of ++Seek 20140417 from chars: p11 error code changed to single error msg again.
  //++Seek 20151106 add new error msgs for feitian
  else if(("0x"+parseInt(nRc, 10).toString(16)).substring(0,8)== 0x830000)
  {
	  var CSPErrorCode = SP11FileUpload_Control().strCSPErrorCode;
	  
	  if(CSPErrorCode == "80090020")
	  {
		  ret_msg = "錯誤代碼：0x80090020  說明：交易未完成, 動作已取消";
	  }
	  else if(CSPErrorCode == "8010006e")
	  {
		  ret_msg = "錯誤代碼：0x8010006e  說明：SCARD_W_CANCELLED_BY_USER: 使用者取消";
	  }
	  else if(CSPErrorCode == "80090009")
	  {
		  ret_msg = "錯誤代碼：0x80090009  說明：Invalid flags specified: 寫憑證發生錯誤, 已經有憑證再使用相同containerName";
	  }
	  else if(CSPErrorCode == "8009000f")
	  {
		  ret_msg = "錯誤代碼：0x8009000f  說明：Object already exists: 產生金鑰錯誤, 使用相同containerName";
	  }
	  else if(CSPErrorCode == "8009000d")
	  {
		  ret_msg = "錯誤代碼：0x8009000d  說明：Key Does Not Exist: 寫憑證發生錯誤, 已產生container但沒有產生金鑰";
	  }
	  else if(CSPErrorCode == "80090016")
	  {
		  ret_msg = "錯誤代碼：0x80090016  說明：Keyset does not exist: 寫憑證發生錯誤, 空載具沒有container";
	  }
	  else if(CSPErrorCode == "8010002a")
	  {
		  ret_msg = "錯誤代碼：0x8010002a  說明：SCARD_E_INVALID_CHV: PIN碼錯誤";
	  }
	  else if(CSPErrorCode != "0")
	  {
		  ret_msg = "錯誤代碼：0x"+parseInt(nRc, 10).toString(16) +", 說明：CSP錯誤, LastError: 0x" + CSPErrorCode;
	  }
	  else
	  {
		ret_msg = "錯誤代碼：0x"+parseInt(nRc, 10).toString(16) +", 說明：CSP錯誤";
	  }
  }
  //end of seek 20151106 add new error msgs for feitian
  //++Seek 20140214
  else if(nRc == 0x81000200)
  {
			ret_msg = "錯誤代碼：0x81000200  說明：交易時連線錯誤:與主機連線發生問題";		
  }else if(nRc == 0x81000201)
  {
			ret_msg = "錯誤代碼：0x81000201  說明：交易時連線錯誤:接收主機回應訊息逾時";		
  }else if(nRc == 0x81000202)
  {
		   ret_msg = "錯誤代碼：0x81000202  說明：交易時連線錯誤:主機回應資料訊息格式不正確";
  }else if(nRc == 0x81000203)
  {
			ret_msg = "錯誤代碼：0x81000203  說明：交易時連線錯誤:主機無回應訊息";																						
  }else if(nRc == 0x81100001)
  {/* 0x811開頭為元件定義: 上傳資料後，OpMode=EXEC連線回應的RETURNCODE值加上元件自定義值0x81100000，詳細錯誤需查閱property: ERRORCODE */
			ret_msg = SP11FileUpload_Control().errMsg;
  }else if(nRc == 0x81100002)
  {	
			errorCode=getErrorCode(SP11FileUpload_Control().errMsg, 'ERRORCODE');
			if ( errorCode=="015" ){
			  ret_msg = "錯誤代碼：CA-Server 015  說明：驗證客戶資料時發生問題，請確認是否插入正確的憑證";
			}else if( errorCode=="018" ){
			  ret_msg = ParseErrorMessage(SP11FileUpload_Control().errMsg, 'DETAIL');
			}else if( errorCode=="019" ){
			  ret_msg = ParseErrorMessage(SP11FileUpload_Control().errMsg, 'DETAIL');
			}else if( errorCode=="026" ){
			  ret_msg = ParseErrorMessage(SP11FileUpload_Control().errMsg, 'DETAIL');				
			}else if( errorCode=="008" ){
			  ret_msg = ParseErrorMessage(SP11FileUpload_Control().errMsg, 'DETAIL');
			}else{
			  ret_msg = "錯誤代碼：CA-Server "+ errorCode + "  說明：系統發生錯誤，請聯絡相關人員";
			}		
  }else if(nRc == 0x81100003)
  {
  	  	errorCode=getErrorCode(SP11FileUpload_Control().errMsg, 'ERRORCODE');
        ret_msg = "錯誤代碼：CA-Server "+ errorCode + "  說明：系統發生錯誤，請聯絡相關人員";
  }else if(nRc == 0x81100004)
  {
			ret_msg = ParseErrorMessage(SP11FileUpload_Control().errMsg, 'DETAIL');
  }else if(nRc == 0x81100005)
  {
			ret_msg = SP11FileUpload_Control().strErrorCode;
  }else if(nRc == 0x81100006)
  {
			//document.write(SP11FileUpload_Control().errMsg);
			ret_msg = SP11FileUpload_Control().errMsg;
  }
  //Seek 20140214 end
  //++Seek 20151106 add new error msgs
  else if(("0x"+parseInt(nRc, 10).toString(16)).substring(0,8)== 0x830000)
  {
	// 暫時使用
		ret_msg = "錯誤代碼：0x"+parseInt(nRc, 10).toString(16) +", 說明：CSP錯誤, LastError: 0x" + SP11FileUpload_Control().strCSPErrorCode;
  }
  //end of seek 20151106 add new error msgs
  else if((nRc >= 0x81200001) && (nRc <= 0x812FFFFF))
  {
		ret_msg = "錯誤代碼："+"0x"+parseInt(nRc, 10).toString(16)+"  說明：存取Windows Registry錯誤。錯誤碼："+"0x"+parseInt(nRc-0x81200000, 10).toString(16);
  }else{            		 
		ret_msg = "0x"+parseInt(nRc, 10).toString(16);
  }		    
  return ret_msg;
}

//++Seek 20140214
function ShowErrorMessageCHT(nRc) {
	alert(GetErrorMessageCHT(nRc));
}

/* cht元件所使用的顯示錯誤訊息函式(新增) - End */
