﻿var timer=null;
var delaytime=5000;

function sleep(milliseconds) {
	var start = new Date().getTime();
	for (var i = 0; i< 1e7; i++) {
		if((new Date().getTime() - start) > milliseconds) {
			break;
		}
	}
}

function right(e) {
    if (navigator.appName =='Netscape'&& (e.which ==3|| e.which ==2))
        return false;
    else if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2|| event.button ==3)) {
        //alert("版權所有中國信託");
        alert("Copyright by CTBC");
        return false;
    } 
    return true;
}

document.onmousedown=right;
if (document.layers) window.captureEvents(Event.MOUSEDOWN);
    window.onmousedown=right;
file:


function stop() {
    clearTimeout(timer);
}

function start() {
    var time=new Date();
    var year=time.getFullYear();
    var month=time.getMonth();
    month=month+1;
    month=((month < 10) ? "0" : "") + month;
    var date=time.getDate();
    date=((date < 10) ? "0" : "") + date;
    var hours=time.getHours();
    var minutes=time.getMinutes();
    minutes=((minutes < 10) ? "0" : "") + minutes;
    var seconds=time.getSeconds();
    seconds=((seconds < 10) ? "0" : "") + seconds;
    var clock=year + "/" + month + "/" +date + " " + hours + ":" + minutes + ":" + seconds;
    document.forms[0].display.value=clock;
    timer=setTimeout("start()",1000);
}

function writeCertinfo() {
	var d=new Date();
	var sec=d.getSeconds();
	var language = determineLanguage();
	
	if (language == 1) {
      if(sec%4==0)
          document.getElementById("hint").innerHTML="憑證寫入中➠";  
      else if(sec%4==1)
          document.getElementById("hint").innerHTML="憑證寫入中➠➠";
      else if(sec%4==2)
          document.getElementById("hint").innerHTML="憑證寫入中➠➠➠";  
      else
          document.getElementById("hint").innerHTML="憑證寫入中➠➠➠➠";  
	} else if (language == 2) { 
      if(sec%4==0)
          document.getElementById("hint").innerHTML="凭证写入中➠";  
      else if(sec%4==1)
          document.getElementById("hint").innerHTML="凭证写入中➠➠";
      else if(sec%4==2)
          document.getElementById("hint").innerHTML="凭证写入中➠➠➠";  
      else
          document.getElementById("hint").innerHTML="凭证写入中➠➠➠➠"; 
	} else {
      if(sec%4==0)
          document.getElementById("hint").innerHTML="Writing Certificate➠";  
      else if(sec%4==1)
          document.getElementById("hint").innerHTML="Writing Certificate➠➠";
      else if(sec%4==2)
          document.getElementById("hint").innerHTML="Writing Certificate➠➠➠";  
      else
          document.getElementById("hint").innerHTML="Writing Certificate➠➠➠➠"; 
	}		
	timerID=setTimeout("writeCertinfo()",1000);
}

function sendToCAinfo() {
	var language = determineLanguage();
	var d=new Date();
	var sec=d.getSeconds();
	
	if(language == 1) {
		  if(sec%4==0)
			    document.getElementById("hint").innerHTML="資料傳送至CA中➠";  
		  else if(sec%4==1)
			    document.getElementById("hint").innerHTML="資料傳送至CA中➠➠";
		  else if(sec%4==2)
			    document.getElementById("hint").innerHTML="資料傳送至CA中➠➠➠";  
		  else
		  	  document.getElementById("hint").innerHTML="資料傳送至CA中➠➠➠➠";  
	} else if (language == 2) { 
      if(sec%4==0)
          document.getElementById("hint").innerHTML="资料传送至CA中➠";  
      else if(sec%4==1)
          document.getElementById("hint").innerHTML="资料传送至CA中➠➠";
      else if(sec%4==2)
          document.getElementById("hint").innerHTML="资料传送至CA中➠➠➠";  
      else
          document.getElementById("hint").innerHTML="资料传送至CA中➠➠➠➠"; 
	} else {
      if(sec%4==0)
          document.getElementById("hint").innerHTML="Send to CA➠";  
      else if(sec%4==1)
          document.getElementById("hint").innerHTML="Send to CA➠➠";
      else if(sec%4==2)
          document.getElementById("hint").innerHTML="Send to CA➠➠➠";  
      else
          document.getElementById("hint").innerHTML="Send to CA➠➠➠➠"; 
	}
	timerID=setTimeout("sendToCAinfo()",1000);
}

function checkComponentInstall(){
    rv = -1;
    
    var ua = navigator.userAgent;
    if (navigator.appName == 'Microsoft Internet Explorer') {
        var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
        if (re.exec(ua) != null) {
            rv = parseFloat( RegExp.$1 );
            var agentWeb = 'Microsoft webgolds';
        }
    } else if (navigator.appName == 'Netscape'){
        var re  = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");  //for IE 11
        if (re.exec(ua) != null)
        rv = parseFloat( RegExp.$1 );
    }
    
    var CTBC_FB = document.getElementById("CTBCPKIAPI");
    var ReturnValue = CTBC_FB.version;
    
    if(typeof ReturnValue != "undefined") { 
        document.getElementById("component").value = "activex";
		if(document.getElementById("CHTCertObj") != null)
			document.getElementById("CHTCertObj").style.backgroundColor="#CC00FF";
    } else {
        if(rv==8||rv==9) {
            alert(componentnotinstallmsg());
            window.location.href="./Envdownload.jsp";
        }
		document.getElementById("component").value = "localserver";
		if(initCheckPort()){
        load();      
        }
    } 
}

function checkComponent() {
    var CTBC_FB = document.getElementById("CTBCPKIAPI");
    var ReturnValue = CTBC_FB.version;
    
    if (typeof ReturnValue != "undefined") {
        document.getElementById("component").value = "activex";
        if (document.getElementById("CHTCertObj")!=null) {
            document.getElementById("CHTCertObj").style.backgroundColor="#CC00FF";
        }
    } else { 
        document.getElementById("component").value = "localserver";
    }
}

function checkCHTCert() {
  var CHTObj;
  try {
      CHTObj = new ActiveXObject("CTBC.ctbccryptoapi");
      if(CHTObj!=null) {
          delete CHTObj;
          return true;
      } else {
          return false;
      }
  } catch (e) {
      return false;
  }
}


function checkDISKCERTSTORE()
{
	return false;
}

function checkECOM4SP()
{
	return false;
}


	


