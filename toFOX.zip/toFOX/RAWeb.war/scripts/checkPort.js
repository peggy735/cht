window.CTBCConfig = window.CTBCConfig || {};
window.CTBCConfig.isEnvTestSupported = true;

// 配置常數
var CONFIG = {
  PORTS: [16016, 16017, 16018, 16019, 16020],
  MIN_VERSION: "2.0.10.7",
  ALERT_TIMEOUT: 10000,
  BASE_URL: "https://127.0.0.1",
  ENDPOINT: "/CHTCertTokenServer/",
  DOWNLOAD_URL: "https://pkicb.ctbcbank.com.cn/RAWeb/CAdownload.jsp?language=zh-cn"
};

// 語言訊息配置
var MESSAGES = {
  1: {
    versionTooLow: '當前交易元件版本過低，無法使用。請於網銀首頁-下載中心-安全控制項體驗與下載安裝新版元件。下載連結:https://pkicb.ctbcbank.com.cn/RAWeb/CAdownload.jsp?language=zh-tw'
  },
  2: {
    versionTooLow: '当前交易元件版本过低，无法使用。请于网银首页-下载中心-安全控件体验与下载安装新版元件。下载链接:https://pkicb.ctbcbank.com.cn/RAWeb/CAdownload.jsp?language=zh-cn'
  },
  default: {
    versionTooLow: 'The current transaction component version is too low and cannot be used. Please go to the homepage of online banking - Download Center - Security Control Experience and Download and install the new version of the component. Download link: https://pkicb.ctbcbank.com.cn/RAWeb/CAdownload.jsp?language=en-us'
  },
  common: {
    noPortAvailable: '無法連接到任何可用的 port，請確認元件是否已啟動。'
  }
};

var PortChecker = {
  isValidVersion: function (version) {
    return /^\d+(\.\d+)*$/.test(version);
  },

  compareVersions: function (v1, v2) {
    var v1Parts = v1.split(".").map(function (part) { return parseInt(part, 10); });
    var v2Parts = v2.split(".").map(function (part) { return parseInt(part, 10); });

    for (var i = 0; i < Math.max(v1Parts.length, v2Parts.length); i++) {
      var part1 = v1Parts[i] || 0;
      var part2 = v2Parts[i] || 0;
      if (part1 > part2) return 1;
      if (part1 < part2) return -1;
    }
    return 0;
  },

  createAlertElement: function (message, linkUrl) {
    var alert = document.createElement('div');
    alert.style.position = 'fixed';
    alert.style.top = '50%';
    alert.style.left = '50%';
    alert.style.transform = 'translate(-50%, -50%)';
    alert.style.padding = '20px';
    alert.style.backgroundColor = '#fff';
    alert.style.border = '1px solid #000';
    alert.style.zIndex = '1000';
    alert.style.textAlign = 'center';
    alert.innerHTML = message + ' <a href="' + linkUrl + '" target="_blank">點此下載</a>';
    return alert;
  },

  showCustomAlert: function (message, linkUrl) {
    var self = this;
    var alert = this.createAlertElement(message, linkUrl);
    document.body.appendChild(alert);
    setTimeout(function () {
      if (document.body.contains(alert)) {
        document.body.removeChild(alert);
      }
    }, CONFIG.ALERT_TIMEOUT);
  },

  checkSinglePort: function (port) {
    var self = this;
    return new Promise(function (resolve) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', CONFIG.BASE_URL + ':' + port + CONFIG.ENDPOINT);
      xhr.timeout = 5000; // 5 秒超時

      xhr.onload = function () {
        if (xhr.status === 200) {
          try {
            var data = JSON.parse(xhr.responseText);
            console.log('Port ' + port + ' is alive, response:', data);

            if (data.versionLS) {
              self.handleVersionCheck(data.versionLS);
            }
            resolve(true);
          } catch (e) {
            console.error('解析回應失敗:', e);
            resolve(false);
          }
        } else {
          resolve(false);
        }
      };

      xhr.onerror = function () {
        console.log('Port ' + port + ' is not available');
        resolve(false);
      };

      xhr.ontimeout = function () {
        console.log('Port ' + port + ' request timed out');
        resolve(false);
      };

      xhr.send();
    });
  },

  handleVersionCheck: function (version) {
    if (!this.isValidVersion(version)) {
      console.error("版本格式不正確:", version);
      return;
    }

    if (this.compareVersions(version, CONFIG.MIN_VERSION) < 0) {
      var language = determineLanguage();
      var message = MESSAGES[language] ? MESSAGES[language].versionTooLow : MESSAGES.default.versionTooLow;

      if (language === "2") {
        this.showCustomAlert(message, CONFIG.DOWNLOAD_URL);
      } else {
        alert(message);
      }
      window.CTBCConfig.isEnvTestSupported = false;

    }
  },

  checkAllPorts: function () {
    var self = this;
    var currentIndex = 0;

    function checkNext() {
      if (currentIndex >= CONFIG.PORTS.length) {
        alert(MESSAGES.common.noPortAvailable);
        return;
      }

      self.checkSinglePort(CONFIG.PORTS[currentIndex]).then(function (success) {
        if (!success) {
          currentIndex++;
          checkNext();
        }
      });
    }

    checkNext();
  }
};

function initCheckPort() {
  if (oca21Enable === "FALSE") {
    PortChecker.checkAllPorts();
  }
}