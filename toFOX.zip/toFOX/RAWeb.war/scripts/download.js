﻿var os = OperatingSystem();
function setEnvOSName() {
  if ('os_name0' in window)
    os_name0.innerText = os;

  //Larry 20190114
  if ('os_name01' in window)
    os_name01.innerText = os;

  if ('os_name02' in window)
    os_name02.innerText = os;

  setchtSize();

}

function setOSName() {
  os_name0.innerText = os;
  os_name1.innerText = os;
  os_name2.innerText = os;
  //os_name3.innerText = os;
  //os_name4.innerText = os;
  //os_name5.innerText = os;
  //os_name7.innerText = os;
  //os_name8.innerText = os; //seek 20151225
  setchtSize();
  setfeitianSize();//seek 20151225
  //setGemPKCSSize();
  //setIKeySize();
  //setEZ100PUSize();
  //setGemPC410Size();
}
function setchtSize() {
  //Larry 20190114
  //cht_size.innerText = "1,056KB";
  if ('cht_size' in window)
    cht_size.innerText = "1,056KB";

  if ('cht_size1' in window)
    cht_size1.innerText = "5,203KB";
}
//++Seek 20151225
function setfeitianSize() {
  if ('feitian_size' in window)
    feitian_size.innerText = "977KB";
}
//end of ++Seek 20151225
function setGemPKCSSize() {
  gempkcs_size.innerText = "9,303KB";
}

function setIKeySize() {
  /*
  if ((os == "Windows Vista") || (os=="Windows 7") || (os=="Windows 8")) {
    ikey_size.innerText = "6,259KB";
  }
  else if((os=="Windows Vista X64")||(os=="Windows 7 X64") || (os=="Windows 8 X64")){
      ikey_size.innerText = "7,312KB";
  } 
  else { //non vista
    ikey_size.innerText = "12,917KB";
  }
  */
  ikey_size.innerText = "56,524KB";
}

function setEZ100PUSize() {
  if ((os == "Windows 98") || (os == "Windows 98 SE")) {
    ez100pu_size.innerText = "3,774KB";
  } else if ((os == "Windows 2000") || (os == "Windows XP")) {
    ez100pu_size.innerText = "3,758KB";
  } else { //Windows Vista
    ez100pu_size.innerText = "24,062KB";
  }
}

function setGemPC410Size() {
  gempc410_size.innerText = "1,199KB";
}

function download(type) {
  var file = "software/";

  if (type == "gempkcs") { //GemPKCS Runtime 
    file += "GemPKCSRuntime.exe";
  } else if (type == "ikey") {
    file += "SAC_8.2_20140328.zip";
  } else if (type == "ez100pu") { //�i��Ū�d���X�ʵ{��
    if ((os == "Windows 98") || (os == "Windows 98 SE")) {
      file += "EZUSB v6.1 for Win98_ME_NT(UHC).exe";
    } else if ((os == "Windows 2000") || (os == "Windows XP")) {
      file += "EZUSB v6.1 for Win2000_XP.exe";
    } else { //Windows Vista
      file += "EZUSB v6.4 for VISTA32_64 bit.exe";
    }
  } else if (type == "gempc410") { //GemPC410Ū�d���X�ʵ{��
    file += "GemPC410.exe";
  } else if (type == "utility") { //���Ұ������ҶE�_�{��
    file += "CTBCEnvCheck_CN.zip";
  } else if (type == "del registry") { //�R��Gempkcs�n����
    file += "DelGemsafe8k.exe";
  } else if (type == "csp") { //Microsoft Base CSP
    if (navigator.systemLanguage == "zh-tw") {
      file += "Windows-KB909520-v1.000-x86-CHT.exe";
    } else if (navigator.systemLanguage == "zh-cn") {
      file += "Windows-KB909520-v1.000-x86-CHS.exe";
    } else if (navigator.systemLanguage == "en-us") {
      file += "Windows-KB909520-v1.000-x86-ENU.exe";
    }
  } else if (type == "CHTCom") {
    file += "sm2certPlugin_ctbc.exe";
  } else if (type == "feitian") {
    file += "CTBC_USBKEY.zip";
  } else if (type == "CHTLS") { //20190114 Larry add for localserver
    //file += "CTBC_eTrust_LocalServer_CN.exe";
	file += "CTBC_eTrust_LocalServer_CN_2.0.10.7.zip";
  } else if (type == "CHTLS_OneClick") { //20220912 Josh add for oneclicks
    //file += "CTBC_eTrust_LocalServer_OneClick.exe";
	file += "CTBC_eTrust_LocalServer_CN_OneClick_2.0.10.7.zip";
  } else if (type == "loginCom") {
    if ((navigator.platform == "Win32") || (navigator.platform == "Windows")) {
      if (navigator.userAgent.indexOf("MSIE") > 0 || navigator.userAgent.indexOf("msie") > 0 || navigator.userAgent.indexOf("Trident") > 0 || navigator.userAgent.indexOf("trident") > 0) {
        if (navigator.userAgent.indexOf("ARM") > 0) {
          //win8 RAM Touch
        } else {
          file += "CTBCALL.zip";
        }
      } else {
        //NotIE'
        file += "CTBCALL.zip";
      }
    } else if ((navigator.platform == "Win64")) {
      if (navigator.userAgent.indexOf("MSIE") > 0 || navigator.userAgent.indexOf("msie") > 0 || navigator.userAgent.indexOf("Trident") > 0 || navigator.userAgent.indexOf("trident") > 0) {
        if (navigator.userAgent.indexOf("WOW64") > 0 || navigator.userAgent.indexOf("wow64") > 0) {
          file += "CTBCNBLoginX.zip";
        } else {
          file += "CTBCALL.zip";
        }
      } else {
        //NotIE
        file += "CTBCALL.zip";
      }
    } else {
      //Not support Browser
    }
  } else if (type == "loginComNew") {
    file += "CTBCALL.zip";
  }
  // add by fox 240513
  else if (type == "AP2APCNLSR") {
    file += "CTBC_AP2AP_LocalServer_CN_2.1.6.6.zip";
  } else if (type == "AP2APCNUsb") {
    file += "CTBC_USBKEY_AP2AP_SIGN.zip";
  }

  window.location.href = file;
}

function OperatingSystem() {
  if (navigator.appName.indexOf("Microsoft") >= 0) {
    temp = navigator.appVersion.substring(navigator.appVersion.indexOf(";") + 1, navigator.appVersion.indexOf(")"));
    temp = temp.substring(temp.indexOf(";") + 1);
  } else if (navigator.appName.indexOf("Netscape") >= 0) {
    if (navigator.userAgent.indexOf("Netscape6") > 0) {
      temp = navigator.appVersion.substring(navigator.appVersion.indexOf("(") + 1, navigator.appVersion.indexOf(";"));
    } else if (navigator.appName.substring(0, 8) == "Netscape") {
      temp = navigator.appVersion.substring(navigator.appVersion.indexOf("(") + 1, navigator.appVersion.indexOf(";"));
    }
  }

  if (temp.indexOf(";") < 0) {
    temp = temp.substring(temp.indexOf("Win"));
  } else {
    temp = temp.substring(temp.indexOf("Win"), temp.indexOf(";"));
  }
  switch (temp) {
    case "Windows NT 5.0":
      os_str = "Windows 2000";
      break;

    case "Windows NT 5.1":
      os_str = "Windows XP";
      break;

    case "Windows NT 5.2":
      if (navigator.userAgent.indexOf("WOW64") != -1) {
        os_str = "Windows XP x64";
      } else {
        os_str = "Windows Server 2003";
      }
      break;

    case "Windows NT 6.0":
      if (navigator.userAgent.indexOf("WOW64") != -1) {
        os_str = "Windows Vista X64";
      } else {
        os_str = "Windows Vista";
      }
      break;
    case "Windows NT 6.1":
      if (navigator.userAgent.indexOf("WOW64") != -1) {
        os_str = "Windows 7 X64";
      } else {
        os_str = "Windows 7";
      }
      break;

    case "Windows NT 6.2":
      if (navigator.userAgent.indexOf("WOW64") != -1) {
        os_str = "Windows 8 X64";
      } else {
        os_str = "Windows 8";
      }
      break;
    //start of add by z00027669
    case "Windows NT 6.3":
      if (navigator.userAgent.indexOf("WOW64") != -1) {
        os_str = "Windows 8.1 X64";
      } else {
        os_str = "Windows 8.1";
      }
      break;
    case "Windows 4.9":
    case "Windows Millennium Edition":
    case "Windows ME":
      os_str = "Windows ME";
      break;

    case "Windows 98":
    case "Windows 4.1":
      os_str = "Windows 98";
      break;

    case "Windows 98 Second Edition":
      os_str = "Windows 98 SE";
      break;

    default:
      os_str = temp;
      if ((temp.indexOf("Windows NT") > -1) && (parseFloat(temp.replace("Windows NT", "")) < 4)) {
        return false;
      } else if ((temp.indexOf("Windows") > -1) && (!isNaN(temp.replace("Windows", "")))) {
        if (parseFloat(temp.replace("Windows", "")) < 98) {
          return false;
        }
      }
  }

  return os_str;
}
