function errorCode2Message(nRc, data) {
    if (nRc == 0x82000001)
    { /* 0x82開頭為自訂Token的錯誤代碼 */
        ret_msg = "錯誤代碼：0x82000001  說明：CRYPTO_PKCS7_TYPE_ERROR: Crypto TYPE錯誤";
    }
    else if (nRc == 0x82000002)
    {
        ret_msg = "錯誤代碼：0x82000002  說明：CRYPTO_PKCS7_GET_SIGNER: Crypto SIGNE錯誤";
    }
    else if (nRc == 0x82000003)
    {
        ret_msg = "錯誤代碼：0x82000003  說明：CRYPTO_PKCS7_SIGN_ERROR: Crypto SIGN錯誤";
    }
    else if (nRc == 0x82000004)
    {
        ret_msg = "錯誤代碼：0x82000004  說明：CRYPTO_PKCS7_VERIFY_FAIL: Crypto VERIFY錯誤";
    }
    else if (nRc == 0x82000005)
    {
        ret_msg = "錯誤代碼：0x82000005  說明：CRYPTO_PKCS7_ENCRYPT_ERROR: Crypto ENCRYPT錯誤";
    }
    else if (nRc == 0x82000006)
    {
        ret_msg = "錯誤代碼：0x82000006  說明：CRYPTO_PKCS7_DECRYPT_FAIL: Crypto DECRYPT錯誤";
    }
    else if (nRc == 0x82000026)
    {
        ret_msg = "錯誤代碼：0x82000026  說明：憑證解析錯誤(X509_NAME_get_index_by_NID錯誤)";
    }
    else if (nRc == 0x82000011)
    {
        ret_msg = "錯誤代碼：0x82000011  說明：時間格式轉換錯誤";
    }
    else if (nRc == 0x82000021)
    {
        ret_msg = "錯誤代碼：0x82000021  說明：找不到載具驅動函式庫";
    }
    else if (nRc == 0x82000022)
    {
        ret_msg = "錯誤代碼：0x82000022  說明：產生CSR過程中發生X509_REQ_sign錯誤";
    }
    else if (nRc == 0x82000023)
    {
        ret_msg = "錯誤代碼：0x82000023  說明：檢驗CSR內容時發現找不到金鑰";
    }
    else if (nRc == 0x82000024)
    {
        ret_msg = "錯誤代碼：0x82000024  說明：檢驗CSR內容時發現X509_REQ_verify錯誤";
    }
    else if (nRc == 0x82000025)
    {
        ret_msg = "錯誤代碼：0x82000025  說明：憑證內容讀取錯誤(X509_NAME_print_ex錯誤)";
    }
    else if (nRc == 0x82000026)
    {
        ret_msg = "錯誤代碼：0x82000026  說明：憑證解析錯誤(X509_NAME_get_index_by_NID錯誤)";
    }
    else if (nRc == 0x82000031)
    {
        ret_msg = "錯誤代碼：0x82000031  說明：載具內找不到特定的object";
    }
    else if (nRc == 0x82000032)
    {
        ret_msg = "錯誤代碼：0x82000032  說明：載具內找不到特定的CN";
    }
    else if (nRc == 0x81000001)
    { /* 0x81開頭為元件所定義的錯誤代碼 */
        ret_msg = "錯誤代碼：0x81000001  說明：使用者取消操作";
    }
    else if (nRc == 0x81000002)
    {
        ret_msg = "錯誤代碼：0x81000002  說明：未輸入載具密碼";
    }
    else if (nRc == 0x81000003)
    {
        ret_msg = "錯誤代碼：0x81000003  說明：未輸入圖形辨識碼";
    }
    else if (nRc == 0x81000004)
    {
        ret_msg = "錯誤代碼：0x81000004  說明：圖形辨識碼輸入錯誤";
    }
    else if (nRc == 0x81000005)
    {
        ret_msg = "錯誤代碼：0x81000005  說明：動態鍵盤確定鍵輸入錯誤";
    }
    else if (nRc == 0x81000006)
    {
        ret_msg = "錯誤代碼：0x81000006  說明：輸入新密碼與再次輸入新密碼不相符";
    }
    else if (nRc == 0x81000007)
    {
        ret_msg = "錯誤代碼：0x81000007  說明：未在指定時間內執行插拔載具動作";
    }
    else if (nRc == 0x81000008)
    {
        ret_msg = "錯誤代碼：0x81000008  說明：非合法網域使用";
    }
    else if (nRc == 0x81000009)
    {
        ret_msg = "錯誤代碼：0x81000009  說明：找不到載具驅動函式庫";
    }
    else if (nRc == 0x8100000A)
    {
        ret_msg = "錯誤代碼：0x8100000A  說明：找不到載具";
    }
    else if (nRc == 0x8100000B)
    {
        ret_msg = "錯誤代碼：0x8100000B  說明：憑證不存在或使用者未點選";
    }
    else if (nRc == 0x8100000C)
    {
        ret_msg = "錯誤代碼：0x8100000C  說明：載具中不存在任何金鑰";
    }
    else if (nRc == 0x8100000D)
    {
        ret_msg = "錯誤代碼：0x8100000D  說明：憑證有錯誤";
    }
    else if (nRc == 0x8100000E)
    {
        ret_msg = "錯誤代碼：0x8100000E  說明：找不到和憑證相對應的金鑰";
    }
    else if (nRc == 0x8100000F)
    {
        ret_msg = "錯誤代碼：0x8100000F  說明：載具中找不到Object(金鑰和憑證)";
    }
    else if (nRc == 0x81000010)
    {
        ret_msg = "錯誤代碼：0x81000010  說明：簽章輸出資料錯誤(長度=0)";
    }
    else if (nRc == 0x81000011)
    {
        ret_msg = "錯誤代碼：0x81000011  說明：拒絕重複寫入憑證";
    }
    else if (nRc == 0x81000012)
    {
        ret_msg = "錯誤代碼：0x81000012  說明：載具Session開啟失敗";
    }
    else if (nRc == 0x81000013)
    {
        ret_msg = "錯誤代碼：0x81000013  說明：讀取載具資訊失敗";
    }
    else if (nRc == 0x81000014)
    {
        ret_msg = "錯誤代碼：0x81000014  說明：新PIN碼不為數字組成";
    }
    else if (nRc == 0x81000015)
    {
        ret_msg = "錯誤代碼：0x81000015  說明：新PIN碼不為6~12碼";
    }
    else if (nRc == 0x84000017)
    {
        ret_msg = "錯誤代碼：0x81000017  說明：元件加解密異常";
    }
    else if (nRc == 0x84000018)
    {
        ret_msg = "錯誤代碼：0x81000018  說明：元件加解密異常";
    }
    else if (nRc == 0x84000019)
    {
        ret_msg = "錯誤代碼：0x81000019  說明：元件加解密異常";
    }
    else if (nRc == 0x8400001A)
    {
        ret_msg = "錯誤代碼：0x8100001A  說明：元件加解密異常";
    }
    else if (nRc == 0x8400001F)
    {
        ret_msg = "錯誤代碼：0x8100001F  說明：元件記憶體錯誤";
    }
    else if (nRc == 0x81000100)
    {
        ret_msg = "錯誤代碼：0x81000100  說明：找不到Cilent端IP資訊";
    }
    else if (nRc == 0x81000101)
    {
        ret_msg = "錯誤代碼：0x81000101  說明：找不到Cilent端MAC資訊";
    }
    else if (nRc == 0x81000102)
    {
        ret_msg = "錯誤代碼：0x81000102  說明：MIME Encode過程發生錯誤";
    }
    else if (nRc == 0x81000103)
    {
        ret_msg = "錯誤代碼：0x81000103  說明：MIME Encode attach檔案時發生錯誤";
    }
    else if (nRc == 0x81000104)
    {
        ret_msg = "錯誤代碼：0x81000104  說明：註冊檔資料型態錯誤";
    }
    else if (nRc == 0x00000000)
    {
        ret_msg = "錯誤代碼：0x00000000  說明：CKR_OK: 函式執行成功";
    }
    else if (nRc == 0x00000001)
    {
        ret_msg = "錯誤代碼：0x00000001  說明：CKR_CANCEL: 函式異常終止";
    }
    else if (nRc == 0x00000002)
    {
        ret_msg = "錯誤代碼：0x00000002  說明：CKR_HOST_MEMORY: 記憶體配置失敗";
    }
    else if (nRc == 0x00000003)
    {
        ret_msg = "錯誤代碼：0x00000003  說明：CKR_SLOT_ID_INVALID: 指定的slot ID無效";
    }
    else if (nRc == 0x00000005)
    {
        ret_msg = "錯誤代碼：0x00000005  說明：CKR_GENERAL_ERROR: 遇到了一個無法恢復的錯誤";
    }
    else if (nRc == 0x00000006)
    {
        ret_msg = "錯誤代碼：0x00000006  說明：CKR_FUNCTION_FAILED: 請求的函式無法被執行";
    }
    else if (nRc == 0x00000007)
    {
        ret_msg = "錯誤代碼：0x00000007  說明：CKR_ARGUMENTS_BAD: 輸入參數錯誤";
    }
    else if (nRc == 0x00000020)
    {
        ret_msg = "錯誤代碼：0x00000020  說明：CKR_DATA_INVALID: 加密操作的明文輸入數據是無效的";
    }
    else if (nRc == 0x00000021)
    {
        ret_msg = "錯誤代碼：0x00000021  說明：CKR_DATA_LEN_RANGE: 加密操作的明文輸入數據長度有誤";
    }
    else if (nRc == 0x00000030)
    {
        ret_msg = "錯誤代碼：0x00000030  說明：CKR_DEVICE_ERROR: 載具異常";
    }
    else if (nRc == 0x00000031)
    {
        ret_msg = "錯誤代碼：0x00000031  說明：CKR_DEVICE_MEMORY: 載具沒有足夠的記憶體空間";
    }
    else if (nRc == 0x00000032)
    {
        ret_msg = "錯誤代碼：0x00000032  說明：CKR_DEVICE_REMOVED: 函式執行過程中載具被移除";
    }
    else if (nRc == 0x00000040)
    {
        ret_msg = "錯誤代碼：0x00000040  說明：CKR_ENCRYPTED_DATA_INVALID: 解密操作的加密輸入為無效密文";
    }
    else if (nRc == 0x00000041)
    {
        ret_msg = "錯誤代碼：0x00000041  說明：CKR_ENCRYPTED_DATA_LEN_RANGE: 解密操作的加密輸入長度有誤而成為無效密文";
    }
    else if (nRc == 0x00000050)
    {
        ret_msg = "錯誤代碼：0x00000050  說明：CKR_FUNCTION_CANCELED: 函式在執行中被取消";
    }
    else if (nRc == 0x00000051)
    {
        ret_msg = "錯誤代碼：0x00000051  說明：CKR_FUNCTION_NOT_PARALLEL: 在指定的session中沒有函式併行執行";
    }
    else if (nRc == 0x00000054)
    {
        ret_msg = "錯誤代碼：0x00000054  說明：CKR_FUNCTION_NOT_SUPPORTED: Cryptoki函式庫不支援該請求函式";
    }
    else if (nRc == 0x00000060)
    {
        ret_msg = "錯誤代碼：0x00000060  說明：CKR_KEY_HANDLE_INVALID: 指定的密鑰handle無效";
    }
    else if (nRc == 0x00000062)
    {
        ret_msg = "錯誤代碼：0x00000062  說明：CKR_KEY_SIZE_RANGE: 儘管請求密鑰加密操作原則上可以執行，但該Cryptoki函式庫實際上並不能完成，這是因為提供的密鑰的尺寸超出了它能管理的密鑰尺寸的範圍";
    }
    else if (nRc == 0x00000063)
    {
        ret_msg = "錯誤代碼：0x00000063  說明：CKR_KEY_TYPE_INCONSISTENT: 指定的密鑰不是配合指定的機制使用的正確類型的密鑰";
    }
    else if (nRc == 0x00000082)
    {
        ret_msg = "錯誤代碼：0x00000082  說明：CKR_OBJECT_HANDLE_INVALID: Object handle無效";
    }
    else if (nRc == 0x000000A0)
    {
        ret_msg = "錯誤代碼：0x000000A0  說明：CKR_PIN_INCORRECT: 密碼驗證失敗";
    }
    else if (nRc == 0x000000A1)
    {
        ret_msg = "錯誤代碼：0x000000A1  說明：CKR_PIN_INVALID: 輸入的PIN碼含無效字符，或與密碼強度設定不符";
    }
    else if (nRc == 0x000000A2)
    {
        ret_msg = "錯誤代碼：0x000000A2  說明：CKR_PIN_LEN_RANGE: 輸入的PIN碼長度太長或太短";
    }
    else if (nRc == 0x000000A3)
    {
        ret_msg = "錯誤代碼：0x000000A3  說明：CKR_PIN_EXPIRED: 載具PIN碼到期";
    }
    else if (nRc == 0x000000A4)
    {
        ret_msg = "錯誤代碼：0x000000A4  說明：CKR_PIN_LOCKED: 載具PIN碼鎖定";
    }
    else if (nRc == 0x000000B0)
    {
        ret_msg = "錯誤代碼：0x000000B0  說明：CKR_SESSION_CLOSED: 函式執行過程中Session被關閉";
    }
    else if (nRc == 0x000000B1)
    {
        ret_msg = "錯誤代碼：0x000000B1  說明：CKR_SESSION_COUNT: Session開啟失敗，因為載具已開啟太多Session";
    }
    else if (nRc == 0x000000B3)
    {
        ret_msg = "錯誤代碼：0x000000B3  說明：CKR_SESSION_HANDLE_INVALID: Session handle無效";
    }
    else if (nRc == 0x000000B4)
    {
        ret_msg = "錯誤代碼：0x000000B4  說明：CKR_SESSION_PARALLEL_NOT_SUPPORTED: 載具不支援併行Session";
    }
    else if (nRc == 0x000000B5)
    {
        ret_msg = "錯誤代碼：0x000000B5  說明：CKR_SESSION_READ_ONLY: Session為唯讀因此無法完成想要的執行動作";
    }
    else if (nRc == 0x000000B6)
    {
        ret_msg = "錯誤代碼：0x000000B6  說明：CKR_SESSION_EXISTS: Session已經開啟因此載具無法被初始化";
    }
    else if (nRc == 0x000000B7)
    {
        ret_msg = "錯誤代碼：0x000000B7  說明：CKR_SESSION_READ_ONLY_EXISTS: 可唯讀Session已經存在因此SO無法登入";
    }
    else if (nRc == 0x000000B8)
    {
        ret_msg = "錯誤代碼：0x000000B8  說明：CKR_SESSION_READ_WRITE_SO_EXISTS: 讀寫SO Session已經存在，因此無法開啟唯讀Session";
    }
    else if (nRc == 0x000000C0)
    {
        ret_msg = "錯誤代碼：0x000000C0  說明：CKR_SIGNATURE_INVALID: 簽章無效";
    }
    else if (nRc == 0x000000C1)
    {
        ret_msg = "錯誤代碼：0x000000C1  說明：CKR_SIGNATURE_LEN_RANGE: 簽章長度有誤而成為無效簽章";
    }
    else if (nRc == 0x000000E0)
    {
        ret_msg = "錯誤代碼：0x000000E0  說明：CKR_TOKEN_NOT_PRESENT: 載具不存在";
    }
    else if (nRc == 0x000000E1)
    {
        ret_msg = "錯誤代碼：0x000000E1  說明：CKR_TOKEN_NOT_RECOGNIZED: Cryptoki函式庫或slot無法識別該載具";
    }
    else if (nRc == 0x000000E2)
    {
        ret_msg = "錯誤代碼：0x000000E2  說明：CKR_TOKEN_WRITE_PROTECTED: 載具有防止寫入保護，因此無法執行請求的動作";
    }
    else if (nRc == 0x00000100)
    {
        ret_msg = "錯誤代碼：0x00000100  說明：CKR_USER_ALREADY_LOGGED_IN: 該使用者已經登入，無法允許重複登入";
    }
    else if (nRc == 0x00000101)
    {
        ret_msg = "錯誤代碼：0x00000101  說明：CKR_USER_NOT_LOGGED_IN: 使用者未登入";
    }
    else if (nRc == 0x00000102)
    {
        ret_msg = "錯誤代碼：0x00000102  說明：CKR_USER_PIN_NOT_INITIALIZED: PIN碼尚未被初始化";
    }
    else if (nRc == 0x00000103)
    {
        ret_msg = "錯誤代碼：0x00000103  說明：CKR_USER_TYPE_INVALID: 使用者類型無效(有效類型為CKU_SO/CKU_USER)";
    }
    else if (nRc == 0x00000104)
    {
        ret_msg = "錯誤代碼：0x00000104  說明：CKR_USER_ANOTHER_ALREADY_LOGGED_IN:已經有其他使用者透過同一個應用程式登入，因此無法再允許登入";
    }
    else if (nRc == 0x00000105)
    {
        ret_msg = "錯誤代碼：0x00000105  說明：CKR_USER_TOO_MANY_TYPES: 已經有其他使用者透過另一個應用程式登入，因此無法再允許登入";
    }
    else if (nRc == 0x00000150)
    {
        ret_msg = "錯誤代碼：0x00000150  說明：CKR_BUFFER_TOO_SMALL: 緩衝區不足";
    }
    else if (nRc == 0x00000190)
    {
        ret_msg = "錯誤代碼：0x00000190  說明：CKR_CRYPTOKI_NOT_INITIALIZED: Cryptoki函式庫未初始化因而函數不能執行";
    }
    else if (nRc < 0x81000000)
    {
        ret_msg = "錯誤代碼：" + "0x" + parseInt(nRc, 10).toString(16) + "  說明：PKCS#11 錯誤";
    }
    //end region need fox to check
    else if (nRc == 0x81000200)
    {
        ret_msg = "錯誤代碼：0x81000200  說明：交易時連線錯誤:與主機連線發生問題";
    }
    else if (nRc == 0x81000201)
    {
        ret_msg = "錯誤代碼：0x81000201  說明：交易時連線錯誤:接收主機回應訊息逾時";
    }
    else if (nRc == 0x81000202)
    {
        ret_msg = "錯誤代碼：0x81000202  說明：交易時連線錯誤:主機回應資料訊息格式不正確";
    }
    else if (nRc == 0x81000203)
    {
        ret_msg = "錯誤代碼：0x81000203  說明：交易時連線錯誤:主機無回應訊息";
    }
    else if (nRc == 0x81000300)
    {
        ret_msg = "錯誤代碼：0x81000300  說明：本機端時間異常";
    }
    else if (nRc == 0x81000301)
    {
        ret_msg = "錯誤代碼：0x81000301  說明：元件初始化連線逾時";
    }
    else if (nRc == 0x81000302)
    {
        ret_msg = "錯誤代碼：0x81000302  說明：元件初始化驗章失敗";
    }
    else if (nRc == 0x81000303)
    {
        ret_msg = "錯誤代碼：0x81000303  說明：元件解析json失敗";
    }
    else if (nRc == 0x81000304)
    {
        ret_msg = "錯誤代碼：0x81000304  說明：元件呼叫方法異常";
    }
    else if (nRc == 0x81000305)
    {
        ret_msg = "錯誤代碼：0x81000305  說明：元件json參數錯誤";
    }
    else if (nRc == 0x81000306)
    {
        ret_msg = "錯誤代碼：0x81000306  說明：元件json參數錯誤";
    }
    else if (nRc == 0x81000307)
    {
        ret_msg = "錯誤代碼：0x81000307  說明：元件呼叫方法異常";
    }
    else if (nRc == 0x81000308)
    {
        ret_msg = "錯誤代碼：0x81000308  說明：UCTTime錯誤";
    }
    else if (nRc == 0x81000309)
    {
        ret_msg = "錯誤代碼：0x81000309  說明：元件異常";
    }
    else if (nRc == 0x82100001)
    {
        ret_msg = "錯誤代碼：0x82100001  說明：未授權的網站";
    }
    else if (nRc == 0x82100002)
    {
        ret_msg = "錯誤代碼：0x82100002  說明：錯誤的連線路徑";
    }
    else if (nRc == 0x82100003)
    {
        ret_msg = "錯誤代碼：0x82100003  說明：需求指令有誤";
    }
    else if (nRc == 0x82100021)
    {
        ret_msg = "錯誤代碼：0x82100021  說明：AcquireContextError";
    }
    else if (nRc == 0x82100022)
    {
        ret_msg = "錯誤代碼：0x82100022  說明：ReleaseContextError";
    }
    else if (nRc == 0x82100023)
    {
        ret_msg = "錯誤代碼：0x82100023  說明：GenKeyError";
    }
    else if (nRc == 0x82100024)
    {
        ret_msg = "錯誤代碼：0x82100024  說明：DestroyKeyError";
    }
    else if (nRc == 0x82100025)
    {
        ret_msg = "錯誤代碼：0x82100025  說明：GetUserKeyError";
    }
    else if (nRc == 0x82100026)
    {
        ret_msg = "錯誤代碼：0x82100026  說明：CryptExportKeyError";
    }
    else if (nRc == 0x82100027)
    {
        ret_msg = "錯誤代碼：0x82100027  說明：SetKeyParamError";
    }
    else if (nRc == 0x82100028)
    {
        ret_msg = "錯誤代碼：0x82100028  說明：GetKeyParamError";
    }
    else if (nRc == 0x82100029)
    {
        ret_msg = "錯誤代碼：0x82100029  說明：SetProvParamError";
    }
    else if (nRc == 0x82100030)
    {
        ret_msg = "錯誤代碼：0x82100030  說明：CreateHashError";
    }
    else if (nRc == 0x82100031)
    {
        ret_msg = "錯誤代碼：0x82100031  說明：HashDataError";
    }
    else if (nRc == 0x82100032)
    {
        ret_msg = "錯誤代碼：0x82100032  說明：CryptSignHashError";
    }
    else if (nRc == 0x82100033)
    {
        ret_msg = "錯誤代碼：0x82100033  說明：CryptMallocError";
    }
    else if (nRc == 0x82100034)
    {
        ret_msg = "錯誤代碼：0x82100034  說明：DestroyHashError";
    }
    else if (nRc == 0x82100035)
    {
        ret_msg = "錯誤代碼：0x82100035  說明：CryptGetProvParamError";
    }
    else if (nRc == 0x81000020)
    {
        ret_msg = "錯誤代碼:0x81000020  說明:RawSign簽章錯誤";
    }
    else if (nRc == 0x81000021)
    {
        ret_msg = "錯誤代碼:0x81000021  說明:RawSign簽章驗證錯誤";
    }
    else if (nRc == 0x81000024)
    {
        ret_msg = "錯誤代碼:0x81000024  說明:digest Info資料過大";
    }
    else if (nRc == 0x81000025)
    {
        ret_msg = "錯誤代碼:0x81000025  說明:P1簽章錯誤";
    }
    else if (nRc == 0x81000026)
    {
        ret_msg = "錯誤代碼:0x81000026  說明:P1簽章驗證錯誤";
    }
    else if (nRc == 0x82000033)
    {
        ret_msg = "錯誤代碼:0x82000033  說明:digest Info資料過大";
    }
    else if (nRc == 0x82000034)
    {
        ret_msg = "錯誤代碼:0x82000034  說明:P1簽章錯誤";
    }
    else if (nRc == 0x82000100)
    {
        ret_msg = "錯誤代碼:0x82000100  說明:LOAD_PKCS11LIB_ERROR";
    }
    else if (nRc == 0x82000101)
    {
        ret_msg = "錯誤代碼:0x82000101  說明:READER_NOT_SELECT_ERROR";
    }
    else if (nRc == 0x82000102)
    {
        ret_msg = "錯誤代碼:0x82000102  說明:USER_TYPE_ERROR";
    }
    else if (nRc == 0x82000103)
    {
        ret_msg = "錯誤代碼:0x82000103  說明:OBJECT_NUMBER_ERROR";
    }
    else if (nRc == 0x82000104)
    {
        ret_msg = "錯誤代碼:0x82000104  說明:KEYID_NOT_DEFINED_ERROR";
    }
    else if (nRc == 0x82000105)
    {
        ret_msg = "錯誤代碼:0x82000105  說明:KEYSIZE_NOT_DEFIND_EERROR";
    }
    else if (nRc == 0x82000106)
    {
        ret_msg = "錯誤代碼:0x82000106  說明:SELECT_CARDID_ERROR";
    }
    else if (nRc == 0x82000107)
    {
        ret_msg = "錯誤代碼:0x82000107  說明:UNSUPPROT_PINTYPE";
    }
    else if (nRc == 0x82000108)
    {
        ret_msg = "錯誤代碼:0x82000108  說明:NULL_PINNUMBER";
    }
    else if (nRc == 0x82000109)
    {
        ret_msg = "錯誤代碼:0x82000109  說明:TOKEN_NOT_PRESENT";
    }
    else if (nRc == 0x8200010A)
    {
        ret_msg = "錯誤代碼:0x8200010A  說明:NOT_BSTRTYPE";
    }
    else if (nRc == 0x8200010B)
    {
        ret_msg = "錯誤代碼:0x8200010B  說明:DECODE_BASE64_ERROR";
    }
    else if (nRc == 0x8200010C)
    {
        ret_msg = "錯誤代碼:0x8200010C  說明:TOKEN_UNSUPPORTED_FUNCTION";
    }
    else if (nRc == 0x8200010D)
    {
        ret_msg = "錯誤代碼:0x8200010D  說明:EMPTY_CHALLENGE_CDOE";
    }
    else if (nRc == 0x8200010E)
    {
        ret_msg = "錯誤代碼:0x8200010E  說明:NOT_VALID_HEXSTRING_FORMAT";
    }
    else if (nRc == 0x8200010E)
    {
        ret_msg = "錯誤代碼:0x8200010E  說明:NOT_VALID_HEXSTRING_FORMAT";
    }
    else if (nRc == 0x8200010F)
    {
        ret_msg = "錯誤代碼:0x8200010F  說明:EMPTY_OBJECT_VALUE";
    }
    else if (nRc == 0x82000110)
    {
        ret_msg = "錯誤代碼:0x82000110  說明:EMPTY_USER_PIN";
    }
    else if (nRc == 0x82000111)
    {
        ret_msg = "錯誤代碼:0x82000111  說明:WRONG_MESSAGE_FORMAT";
    }
    else if (nRc == 0x82000112)
    {
        ret_msg = "錯誤代碼:0x82000112  說明:WRONG_SOPIN_GEN_DATE";
    }
    else if (nRc == 0x82000113)
    {
        ret_msg = "錯誤代碼:0x82000113  說明:DECRYPT_DATA_FAIL";
    }
    else if ((nRc >= 0x81100001) && (nRc <= 0x81100006))
    {
        /*var tempDec = nRc;
        var tempDec2 = 0x81200000;
        var errorcode = parseInt(tempDec - tempDec2, 10).toString(16);

        ret_msg = "錯誤代碼：" + "0x" + parseInt(nRc, 10).toString(16) + "  說明：交易發生錯誤。錯誤碼：" + "0x" + errorcode;*/
    	if (nRc == 0x81100001) { /* 0x811開頭為元件定義: 上傳資料後，OpMode=EXEC連線回應的RETURNCODE值加上元件自定義值0x81100000，詳細錯誤需查閱property: ERRORCODE */
    		ret_msg = data.errMsg;
	    } else if (nRc == 0x81100002) {
	        errorCode = getErrorCode(data.errMsg, 'ERRORCODE');
	    	
	        if (errorCode == "015") {
	            ret_msg = "錯誤代碼：CA-Server 015  說明：驗證客戶資料時發生問題，請確認是否插入正確的憑證";
	        } else if (errorCode == "018") {
	            ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
	        } else if (errorCode == "019") {
	        	ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
	        } else if (errorCode == "026") {
	        	ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
	        } else {
	            ret_msg = "錯誤代碼：CA-Server " + errorCode + "  說明：系統發生錯誤，請聯絡相關人員";
	        }
	    } else if (nRc == 0x81100003) {
	        errorCode = getErrorCode(data.errMsg, 'ERRORCODE');
	        ret_msg = "錯誤代碼：CA-Server " + errorCode + "  說明：系統發生錯誤，請聯絡相關人員";
	    } else if (nRc == 0x81100004) {
	        ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
	    } else if (nRc == 0x81100005) {
	    	ret_msg = data.errMsg;
	    } else if (nRc == 0x81100006) {
	    	ret_msg = data.errMsg;
	    }
    }
    else if ((nRc >= 0x81200001) && (nRc <= 0x812FFFFF))
    {
        var tempDec = nRc;
        var tempDec2 = 0x81200000;
        var errorcode = parseInt(tempDec - tempDec2, 10).toString(16);

        ret_msg = "錯誤代碼：" + "0x" + parseInt(nRc, 10).toString(16) + "  說明：存取Windows Registry錯誤。錯誤碼：" + "0x" + errorcode;
    }
    else
    {
        ret_msg = "0x" + parseInt(nRc, 10).toString(16);
    }
    return ret_msg;
}

function errorCode2Message_CN(nRc, data) {
    if (nRc == 0x82000001)
    { /* 0x82开头为自订Token的错误代码 */
        ret_msg = "错误代码：0x82000001 说明：CRYPTO_PKCS7_TYPE_ERROR: Crypto TYPE错误";
    }
    else if (nRc == 0x82000002)
    {
        ret_msg = "错误代码：0x82000002 说明：CRYPTO_PKCS7_GET_SIGNER: Crypto SIGNE错误";
    }
    else if (nRc == 0x82000003)
    {
        ret_msg = "错误代码：0x82000003 说明：CRYPTO_PKCS7_SIGN_ERROR: Crypto SIGN错误";
    }
    else if (nRc == 0x82000004)
    {
        ret_msg = "错误代码：0x82000004 说明：CRYPTO_PKCS7_VERIFY_FAIL: Crypto VERIFY错误";
    }
    else if (nRc == 0x82000005)
    {
        ret_msg = "错误代码：0x82000005 说明：CRYPTO_PKCS7_ENCRYPT_ERROR: Crypto ENCRYPT错误";
    }
    else if (nRc == 0x82000006)
    {
        ret_msg = "错误代码：0x82000006 说明：CRYPTO_PKCS7_DECRYPT_FAIL: Crypto DECRYPT错误";
    }
    else if (nRc == 0x82000026)
    {
        ret_msg = "错误代码：0x82000026 说明：凭证解析错误(X509_NAME_get_index_by_NID错误)";
    }
    else if (nRc == 0x82000011)
    {
        ret_msg = "错误代码：0x82000011 说明：时间格式转换错误";
    }
    else if (nRc == 0x82000021)
    {
        ret_msg = "错误代码：0x82000021 说明：找不到载具驱动函式库";
    }
    else if (nRc == 0x82000022)
    {
        ret_msg = "错误代码：0x82000022 说明：产生CSR过程中发生X509_REQ_sign错误";
    }
    else if (nRc == 0x82000023)
    {
        ret_msg = "错误代码：0x82000023 说明：检验CSR内容时发现找不到金钥";
    }
    else if (nRc == 0x82000024)
    {
        ret_msg = "错误代码：0x82000024 说明：检验CSR内容时发现X509_REQ_verify错误";
    }
    else if (nRc == 0x82000025)
    {
        ret_msg = "错误代码：0x82000025 说明：凭证内容读取错误(X509_NAME_print_ex错误)";
    }
    else if (nRc == 0x82000026)
    {
        ret_msg = "错误代码：0x82000026 说明：凭证解析错误(X509_NAME_get_index_by_NID错误)";
    }
    else if (nRc == 0x82000031)
    {
        ret_msg = "错误代码：0x82000031 说明：载具内找不到特定的object";
    }
    else if (nRc == 0x82000032)
    {
        ret_msg = "错误代码：0x82000032 说明：载具内找不到特定的CN";
    }
    else if (nRc == 0x81000001)
    { /* 0x81开头为元件所定义的错误代码 */
        ret_msg = "错误代码：0x81000001 说明：使用者取消操作";
    }
    else if (nRc == 0x81000002)
    {
        ret_msg = "错误代码：0x81000002 说明：未输入载具密码";
    }
    else if (nRc == 0x81000003)
    {
        ret_msg = "错误代码：0x81000003 说明：未输入图形辨识码";
    }
    else if (nRc == 0x81000004)
    {
        ret_msg = "错误代码：0x81000004 说明：图形辨识码输入错误";
    }
    else if (nRc == 0x81000005)
    {
        ret_msg = "错误代码：0x81000005 说明：动态键盘确定键输入错误";
    }
    else if (nRc == 0x81000006)
    {
        ret_msg = "错误代码：0x81000006 说明：输入新密码与再次输入新密码不相符";
    }
    else if (nRc == 0x81000007)
    {
        ret_msg = "错误代码：0x81000007 说明：未在指定时间内执行插拔载具动作";
    }
    else if (nRc == 0x81000008)
    {
        ret_msg = "错误代码：0x81000008 说明：非合法网域使用";
    }
    else if (nRc == 0x81000009)
    {
        ret_msg = "错误代码：0x81000009 说明：找不到载具驱动函式库";
    }
    else if (nRc == 0x8100000A)
    {
        ret_msg = "错误代码：0x8100000A 说明：找不到载具";
    }
    else if (nRc == 0x8100000B)
    {
        ret_msg = "错误代码：0x8100000B 说明：凭证不存在或使用者未点选";
    }
    else if (nRc == 0x8100000C)
    {
        ret_msg = "错误代码：0x8100000C 说明：载具中不存在任何金钥";
    }
    else if (nRc == 0x8100000D)
    {
        ret_msg = "错误代码：0x8100000D 说明：凭证有错误";
    }
    else if (nRc == 0x8100000E)
    {
        ret_msg = "错误代码：0x8100000E 说明：找不到和凭证相对应的金钥";
    }
    else if (nRc == 0x8100000F)
    {
        ret_msg = "错误代码：0x8100000F 说明：载具中找不到Object(金钥和凭证)";
    }
    else if (nRc == 0x81000010)
    {
        ret_msg = "错误代码：0x81000010 说明：签章输出资料错误(长度=0)";
    }
    else if (nRc == 0x81000011)
    {
        ret_msg = "错误代码：0x81000011 说明：拒绝重复写入凭证";
    }
    else if (nRc == 0x81000012)
    {
        ret_msg = "错误代码：0x81000012 说明：载具Session开启失败";
    }
    else if (nRc == 0x81000013)
    {
        ret_msg = "错误代码：0x81000013 说明：读取载具资讯失败";
    }
    else if (nRc == 0x81000014)
    {
        ret_msg = "错误代码：0x81000014 说明：新PIN码不为数字组成";
    }
    else if (nRc == 0x81000015)
    {
        ret_msg = "错误代码：0x81000015 说明：新PIN码不为6~12码";
    }
    else if (nRc == 0x84000017)
    {
        ret_msg = "错误代码：0x81000017 说明：元件加解密异常";
    }
    else if (nRc == 0x84000018)
    {
        ret_msg = "错误代码：0x81000018 说明：元件加解密异常";
    }
    else if (nRc == 0x84000019)
    {
        ret_msg = "错误代码：0x81000019 说明：元件加解密异常";
    }
    else if (nRc == 0x8400001A)
    {
        ret_msg = "错误代码：0x8100001A 说明：元件加解密异常";
    }
    else if (nRc == 0x8400001F)
    {
        ret_msg = "错误代码：0x8100001F 说明：元件记忆体错误";
    }
    else if (nRc == 0x81000100)
    {
        ret_msg = "错误代码：0x81000100 说明：找不到Cilent端IP资讯";
    }
    else if (nRc == 0x81000101)
    {
        ret_msg = "错误代码：0x81000101 说明：找不到Cilent端MAC资讯";
    }
    else if (nRc == 0x81000102)
    {
        ret_msg = "错误代码：0x81000102 说明：MIME Encode过程发生错误";
    }
    else if (nRc == 0x81000103)
    {
        ret_msg = "错误代码：0x81000103 说明：MIME Encode attach档案时发生错误";
    }
    else if (nRc == 0x81000104)
    {
        ret_msg = "错误代码：0x81000104 说明：注册档资料型态错误";
    }
    else if (nRc == 0x00000000)
    {
        ret_msg = "错误代码：0x00000000 说明：CKR_OK: 函式执行成功";
    }
    else if (nRc == 0x00000001)
    {
        ret_msg = "错误代码：0x00000001 说明：CKR_CANCEL: 函式异常终止";
    }
    else if (nRc == 0x00000002)
    {
        ret_msg = "错误代码：0x00000002 说明：CKR_HOST_MEMORY: 记忆体配置失败";
    }
    else if (nRc == 0x00000003)
    {
        ret_msg = "错误代码：0x00000003 说明：CKR_SLOT_ID_INVALID: 指定的slot ID无效";
    }
    else if (nRc == 0x00000005)
    {
        ret_msg = "错误代码：0x00000005 说明：CKR_GENERAL_ERROR: 遇到了一个无法恢复的错误";
    }
    else if (nRc == 0x00000006)
    {
        ret_msg = "错误代码：0x00000006 说明：CKR_FUNCTION_FAILED: 请求的函式无法被执行";
    }
    else if (nRc == 0x00000007)
    {
        ret_msg = "错误代码：0x00000007 说明：CKR_ARGUMENTS_BAD: 输入参数错误";
    }
    else if (nRc == 0x00000020)
    {
        ret_msg = "错误代码：0x00000020 说明：CKR_DATA_INVALID: 加密操作的明文输入数据是无效的";
    }
    else if (nRc == 0x00000021)
    {
        ret_msg = "错误代码：0x00000021 说明：CKR_DATA_LEN_RANGE: 加密操作的明文输入数据长度有误";
    }
    else if (nRc == 0x00000030)
    {
        ret_msg = "错误代码：0x00000030 说明：CKR_DEVICE_ERROR: 载具异常";
    }
    else if (nRc == 0x00000031)
    {
        ret_msg = "错误代码：0x00000031 说明：CKR_DEVICE_MEMORY: 载具没有足够的记忆体空间";
    }
    else if (nRc == 0x00000032)
    {
        ret_msg = "错误代码：0x00000032 说明：CKR_DEVICE_REMOVED: 函式执行过程中载具被移除";
    }
    else if (nRc == 0x00000040)
    {
        ret_msg = "错误代码：0x00000040 说明：CKR_ENCRYPTED_DATA_INVALID: 解密操作的加密输入为无效密文";
    }
    else if (nRc == 0x00000041)
    {
        ret_msg = "错误代码：0x00000041 说明：CKR_ENCRYPTED_DATA_LEN_RANGE: 解密操作的加密输入长度有误而成为无效密文";
    }
    else if (nRc == 0x00000050)
    {
        ret_msg = "错误代码：0x00000050 说明：CKR_FUNCTION_CANCELED: 函式在执行中被取消";
    }
    else if (nRc == 0x00000051)
    {
        ret_msg = "错误代码：0x00000051 说明：CKR_FUNCTION_NOT_PARALLEL: 在指定的session中没有函式并行执行";
    }
    else if (nRc == 0x00000054)
    {
        ret_msg = "错误代码：0x00000054 说明：CKR_FUNCTION_NOT_SUPPORTED: Cryptoki函式库不支援该请求函式";
    }
    else if (nRc == 0x00000060)
    {
        ret_msg = "错误代码：0x00000060 说明：CKR_KEY_HANDLE_INVALID: 指定的密钥handle无效";
    }
    else if (nRc == 0x00000062)
    {
        ret_msg = "错误代码：0x00000062 说明：CKR_KEY_SIZE_RANGE: 尽管请求密钥加密操作原则上可以执行，但该Cryptoki函式库实际上并不能完成，这是因为提供的密钥的尺寸超出了它能管理的密钥尺寸的范围";
    }
    else if (nRc == 0x00000063)
    {
        ret_msg = "错误代码：0x00000063 说明：CKR_KEY_TYPE_INCONSISTENT: 指定的密钥不是配合指定的机制使用的正确类型的密钥";
    }
    else if (nRc == 0x00000082)
    {
        ret_msg = "错误代码：0x00000082 说明：CKR_OBJECT_HANDLE_INVALID: Object handle无效";
    }
    else if (nRc == 0x000000A0)
    {
        ret_msg = "错误代码：0x000000A0 说明：CKR_PIN_INCORRECT: 密码验证失败";
    }
    else if (nRc == 0x000000A1)
    {
        ret_msg = "错误代码：0x000000A1 说明：CKR_PIN_INVALID: 输入的PIN码含无效字符，或与密码强度设定不符";
    }
    else if (nRc == 0x000000A2)
    {
        ret_msg = "错误代码：0x000000A2 说明：CKR_PIN_LEN_RANGE: 输入的PIN码长度太长或太短";
    }
    else if (nRc == 0x000000A3)
    {
        ret_msg = "错误代码：0x000000A3 说明：CKR_PIN_EXPIRED: 载具PIN码到期";
    }
    else if (nRc == 0x000000A4)
    {
        ret_msg = "错误代码：0x000000A4 说明：CKR_PIN_LOCKED: 载具PIN码锁定";
    }
    else if (nRc == 0x000000B0)
    {
        ret_msg = "错误代码：0x000000B0 说明：CKR_SESSION_CLOSED: 函式执行过程中Session被关闭";
    }
    else if (nRc == 0x000000B1)
    {
        ret_msg = "错误代码：0x000000B1 说明：CKR_SESSION_COUNT: Session开启失败，因为载具已开启太多Session";
    }
    else if (nRc == 0x000000B3)
    {
        ret_msg = "错误代码：0x000000B3 说明：CKR_SESSION_HANDLE_INVALID: Session handle无效";
    }
    else if (nRc == 0x000000B4)
    {
        ret_msg = "错误代码：0x000000B4 说明：CKR_SESSION_PARALLEL_NOT_SUPPORTED: 载具不支援并行Session";
    }
    else if (nRc == 0x000000B5)
    {
        ret_msg = "错误代码：0x000000B5 说明：CKR_SESSION_READ_ONLY: Session为唯读因此无法完成想要的执行动作";
    }
    else if (nRc == 0x000000B6)
    {
        ret_msg = "错误代码：0x000000B6 说明：CKR_SESSION_EXISTS: Session已经开启因此载具无法被初始化";
    }
    else if (nRc == 0x000000B7)
    {
        ret_msg = "错误代码：0x000000B7 说明：CKR_SESSION_READ_ONLY_EXISTS: 可唯读Session已经存在因此SO无法登入";
    }
    else if (nRc == 0x000000B8)
    {
        ret_msg = "错误代码：0x000000B8 说明：CKR_SESSION_READ_WRITE_SO_EXISTS: 读写SO Session已经存在，因此无法开启唯读Session";
    }
    else if (nRc == 0x000000C0)
    {
        ret_msg = "错误代码：0x000000C0 说明：CKR_SIGNATURE_INVALID: 签章无效";
    }
    else if (nRc == 0x000000C1)
    {
        ret_msg = "错误代码：0x000000C1 说明：CKR_SIGNATURE_LEN_RANGE: 签章长度有误而成为无效签章";
    }
    else if (nRc == 0x000000E0)
    {
        ret_msg = "错误代码：0x000000E0 说明：CKR_TOKEN_NOT_PRESENT: 载具不存在";
    }
    else if (nRc == 0x000000E1)
    {
        ret_msg = "错误代码：0x000000E1 说明：CKR_TOKEN_NOT_RECOGNIZED: Cryptoki函式库或slot无法识别该载具";
    }
    else if (nRc == 0x000000E2)
    {
        ret_msg = "错误代码：0x000000E2 说明：CKR_TOKEN_WRITE_PROTECTED: 载具有防止写入保护，因此无法执行请求的动作";
    }
    else if (nRc == 0x00000100)
    {
        ret_msg = "错误代码：0x00000100 说明：CKR_USER_ALREADY_LOGGED_IN: 该使用者已经登入，无法允许重复登入";
    }
    else if (nRc == 0x00000101)
    {
        ret_msg = "错误代码：0x00000101 说明：CKR_USER_NOT_LOGGED_IN: 使用者未登入";
    }
    else if (nRc == 0x00000102)
    {
        ret_msg = "错误代码：0x00000102 说明：CKR_USER_PIN_NOT_INITIALIZED: PIN码尚未被初始化";
    }
    else if (nRc == 0x00000103)
    {
        ret_msg = "错误代码：0x00000103 说明：CKR_USER_TYPE_INVALID: 使用者类型无效(有效类型为CKU_SO/CKU_USER)";
    }
    else if (nRc == 0x00000104)
    {
        ret_msg = "错误代码：0x00000104 说明：CKR_USER_ANOTHER_ALREADY_LOGGED_IN:已经有其他使用者透过同一个应用程式登入，因此无法再允许登入";
    }
    else if (nRc == 0x00000105)
    {
        ret_msg = "错误代码：0x00000105 说明：CKR_USER_TOO_MANY_TYPES: 已经有其他使用者透过另一个应用程式登入，因此无法再允许登入";
    }
    else if (nRc == 0x00000150)
    {
        ret_msg = "错误代码：0x00000150 说明：CKR_BUFFER_TOO_SMALL: 缓冲区不足";
    }
    else if (nRc == 0x00000190)
    {
        ret_msg = "错误代码：0x00000190 说明：CKR_CRYPTOKI_NOT_INITIALIZED: Cryptoki函式库未初始化因而函数不能执行";
    }
    else if (nRc < 0x81000000)
    {
        ret_msg = "错误代码：" + "0x" + parseInt(nRc, 10).toString(16) + " 说明：PKCS#11 错误";
    }
    //end region need fox to check
    else if (nRc == 0x81000200)
    {
        ret_msg = "错误代码：0x81000200 说明：交易时连线错误:与主机连线发生问题";
    }
    else if (nRc == 0x81000201)
    {
        ret_msg = "错误代码：0x81000201 说明：交易时连线错误:接收主机回应讯息逾时";
    }
    else if (nRc == 0x81000202)
    {
        ret_msg = "错误代码：0x81000202 说明：交易时连线错误:主机回应资料讯息格式不正确";
    }
    else if (nRc == 0x81000203)
    {
        ret_msg = "错误代码：0x81000203 说明：交易时连线错误:主机无回应讯息";
    }
    else if (nRc == 0x81000300)
    {
        ret_msg = "错误代码：0x81000300 说明：本机端时间异常";
    }
    else if (nRc == 0x81000301)
    {
        ret_msg = "错误代码：0x81000301 说明：元件初始化连线逾时";
    }
    else if (nRc == 0x81000302)
    {
        ret_msg = "错误代码：0x81000302 说明：元件初始化验章失败";
    }
    else if (nRc == 0x81000303)
    {
        ret_msg = "错误代码：0x81000303 说明：元件解析json失败";
    }
    else if (nRc == 0x81000304)
    {
        ret_msg = "错误代码：0x81000304 说明：元件呼叫方法异常";
    }
    else if (nRc == 0x81000305)
    {
        ret_msg = "错误代码：0x81000305 说明：元件json参数错误";
    }
    else if (nRc == 0x81000306)
    {
        ret_msg = "错误代码：0x81000306 说明：元件json参数错误";
    }
    else if (nRc == 0x81000307)
    {
        ret_msg = "错误代码：0x81000307 说明：元件呼叫方法异常";
    }
    else if (nRc == 0x81000308)
    {
        ret_msg = "错误代码：0x81000308 说明：UCTTime错误";
    }
    else if (nRc == 0x81000309)
    {
        ret_msg = "错误代码：0x81000309 说明：元件异常";
    }
    else if (nRc == 0x82100001)
    {
        ret_msg = "错误代码：0x82100001 说明：未授权的网站";
    }
    else if (nRc == 0x82100002)
    {
        ret_msg = "错误代码：0x82100002 说明：错误的连线路径";
    }
    else if (nRc == 0x82100003)
    {
        ret_msg = "错误代码：0x82100003 说明：需求指令有误";
    }
    else if (nRc == 0x82100021)
    {
        ret_msg = "错误代码：0x82100021 说明：AcquireContextError";
    }
    else if (nRc == 0x82100022)
    {
        ret_msg = "错误代码：0x82100022 说明：ReleaseContextError";
    }
    else if (nRc == 0x82100023)
    {
        ret_msg = "错误代码：0x82100023 说明：GenKeyError";
    }
    else if (nRc == 0x82100024)
    {
        ret_msg = "错误代码：0x82100024 说明：DestroyKeyError";
    }
    else if (nRc == 0x82100025)
    {
        ret_msg = "错误代码：0x82100025 说明：GetUserKeyError";
    }
    else if (nRc == 0x82100026)
    {
        ret_msg = "错误代码：0x82100026 说明：CryptExportKeyError";
    }
    else if (nRc == 0x82100027)
    {
        ret_msg = "错误代码：0x82100027 说明：SetKeyParamError";
    }
    else if (nRc == 0x82100028)
    {
        ret_msg = "错误代码：0x82100028 说明：GetKeyParamError";
    }
    else if (nRc == 0x82100029)
    {
        ret_msg = "错误代码：0x82100029 说明：SetProvParamError";
    }
    else if (nRc == 0x82100030)
    {
        ret_msg = "错误代码：0x82100030 说明：CreateHashError";
    }
    else if (nRc == 0x82100031)
    {
        ret_msg = "错误代码：0x82100031 说明：HashDataError";
    }
    else if (nRc == 0x82100032)
    {
        ret_msg = "错误代码：0x82100032 说明：CryptSignHashError";
    }
    else if (nRc == 0x82100033)
    {
        ret_msg = "错误代码：0x82100033 说明：CryptMallocError";
    }
    else if (nRc == 0x82100034)
    {
        ret_msg = "错误代码：0x82100034 说明：DestroyHashError";
    }
    else if (nRc == 0x82100035)
    {
        ret_msg = "错误代码：0x82100035 说明：CryptGetProvParamError";
    }
    else if (nRc == 0x81000020)
    {
        ret_msg = "错误代码:0x81000020 说明:RawSign签章错误";
    }
    else if (nRc == 0x81000021)
    {
        ret_msg = "错误代码:0x81000021 说明:RawSign签章验证错误";
    }
    else if (nRc == 0x81000024)
    {
        ret_msg = "错误代码:0x81000024 说明:digest Info资料过大";
    }
    else if (nRc == 0x81000025)
    {
        ret_msg = "错误代码:0x81000025 说明:P1签章错误";
    }
    else if (nRc == 0x81000026)
    {
        ret_msg = "错误代码:0x81000026 说明:P1签章验证错误";
    }
    else if (nRc == 0x82000033)
    {
        ret_msg = "错误代码:0x82000033 说明:digest Info资料过大";
    }
    else if (nRc == 0x82000034)
    {
        ret_msg = "错误代码:0x82000034 说明:P1签章错误";
    }
    else if (nRc == 0x82000100)
    {
        ret_msg = "错误代码:0x82000100 说明:LOAD_PKCS11LIB_ERROR";
    }
    else if (nRc == 0x82000101)
    {
        ret_msg = "错误代码:0x82000101 说明:READER_NOT_SELECT_ERROR";
    }
    else if (nRc == 0x82000102)
    {
        ret_msg = "错误代码:0x82000102 说明:USER_TYPE_ERROR";
    }
    else if (nRc == 0x82000103)
    {
        ret_msg = "错误代码:0x82000103 说明:OBJECT_NUMBER_ERROR";
    }
    else if (nRc == 0x82000104)
    {
        ret_msg = "错误代码:0x82000104 说明:KEYID_NOT_DEFINED_ERROR";
    }
    else if (nRc == 0x82000105)
    {
        ret_msg = "错误代码:0x82000105 说明:KEYSIZE_NOT_DEFIND_EERROR";
    }
    else if (nRc == 0x82000106)
    {
        ret_msg = "错误代码:0x82000106 说明:SELECT_CARDID_ERROR";
    }
    else if (nRc == 0x82000107)
    {
        ret_msg = "错误代码:0x82000107 说明:UNSUPPROT_PINTYPE";
    }
    else if (nRc == 0x82000108)
    {
        ret_msg = "错误代码:0x82000108 说明:NULL_PINNUMBER";
    }
    else if (nRc == 0x82000109)
    {
        ret_msg = "错误代码:0x82000109 说明:TOKEN_NOT_PRESENT";
    }
    else if (nRc == 0x8200010A)
    {
        ret_msg = "错误代码:0x8200010A 说明:NOT_BSTRTYPE";
    }
    else if (nRc == 0x8200010B)
    {
        ret_msg = "错误代码:0x8200010B 说明:DECODE_BASE64_ERROR";
    }
    else if (nRc == 0x8200010C)
    {
        ret_msg = "错误代码:0x8200010C 说明:TOKEN_UNSUPPORTED_FUNCTION";
    }
    else if (nRc == 0x8200010D)
    {
        ret_msg = "错误代码:0x8200010D 说明:EMPTY_CHALLENGE_CDOE";
    }
    else if (nRc == 0x8200010E)
    {
        ret_msg = "错误代码:0x8200010E 说明:NOT_VALID_HEXSTRING_FORMAT";
    }
    else if (nRc == 0x8200010E)
    {
        ret_msg = "错误代码:0x8200010E 说明:NOT_VALID_HEXSTRING_FORMAT";
    }
    else if (nRc == 0x8200010F)
    {
        ret_msg = "错误代码:0x8200010F 说明:EMPTY_OBJECT_VALUE";
    }
    else if (nRc == 0x82000110)
    {
        ret_msg = "错误代码:0x82000110 说明:EMPTY_USER_PIN";
    }
    else if (nRc == 0x82000111)
    {
        ret_msg = "错误代码:0x82000111 说明:WRONG_MESSAGE_FORMAT";
    }
    else if (nRc == 0x82000112)
    {
        ret_msg = "错误代码:0x82000112 说明:WRONG_SOPIN_GEN_DATE";
    }
    else if (nRc == 0x82000113)
    {
        ret_msg = "错误代码:0x82000113 说明:DECRYPT_DATA_FAIL";
    }
    else if ((nRc >= 0x81100001) && (nRc <= 0x81100006))
    {
        /*var tempDec = nRc;
        var tempDec2 = 0x81200000;
        var errorcode = parseInt(tempDec - tempDec2, 10).toString(16);

        ret_msg = "错误代码：" + "0x" + parseInt(nRc, 10).toString(16) + " 说明：交易发生错误。错误码：" + "0x" + errorcode;*/
    	if (nRc == 0x81100001) { /* 0x811開頭為元件定義: 上傳資料後，OpMode=EXEC連線回應的RETURNCODE值加上元件自定義值0x81100000，詳細錯誤需查閱property: ERRORCODE */
        		ret_msg = data.errMsg;
        } else if (nRc == 0x81100002) {
            errorCode = getErrorCode(data.errMsg, 'ERRORCODE');
        	
            if (errorCode == "015") {
                ret_msg = "错误代码：CA-Server 015  说明：验证客户资料时发生问题，请确认是否插入正确的证书";
            } else if (errorCode == "018") {
                ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
            } else if (errorCode == "019") {
            	ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
            } else if (errorCode == "026") {
            	ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
            } else {
                ret_msg = "错误代码：CA-Server " + errorCode + "  说明：系统发生错误，请联络相关人员";
            }
        } else if (nRc == 0x81100003) {
            errorCode = getErrorCode(data.errMsg, 'ERRORCODE');
            ret_msg = "错误代码：CA-Server " + errorCode + "  说明：系统发生错误，请联络相关人员";
        } else if (nRc == 0x81100004) {
            ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
        } else if (nRc == 0x81100005) {
        	ret_msg = data.errMsg;
        } else if (nRc == 0x81100006) {
        	ret_msg = data.errMsg;
        }
    	
    }
    else if ((nRc >= 0x81200001) && (nRc <= 0x812FFFFF))
    {
        var tempDec = nRc;
        var tempDec2 = 0x81200000;
        var errorcode = parseInt(tempDec - tempDec2, 10).toString(16);

        ret_msg = "错误代码：" + "0x" + parseInt(nRc, 10).toString(16) + " 说明：存取Windows Registry错误。错误码：" + "0x" + errorcode;
    }
    else
    {
        ret_msg = "0x" + parseInt(nRc, 10).toString(16);
    }
    return ret_msg;
}

function errorCode2Message_ENG(nRc, data) {
    if(nRc == 0x82000001)
    { /*0x82 begins with a custom token error code */
        ret_msg = "Error code: 0x82000001 Info: CRYPTO_PKCS7_TYPE_ERROR: Crypto TYPE error";
    }
    else if (nRc == 0x82000002)
    {
        ret_msg = "Error code: 0x82000002 Info: CRYPTO_PKCS7_GET_SIGNER: Crypto SIGNE error";
    }
    else if (nRc == 0x82000003)
    {
        ret_msg = "Error code: 0x82000003 Info: CRYPTO_PKCS7_SIGN_ERROR: Crypto SIGN error";
    }
    else if (nRc == 0x82000004)
    {
        ret_msg = "Error code: 0x82000004 Info: CRYPTO_PKCS7_VERIFY_FAIL: Crypto VERIFY error";
    }
    else if (nRc == 0x82000005)
    {
        ret_msg = "Error code: 0x82000005 Info: CRYPTO_PKCS7_ENCRYPT_ERROR: Crypto ENCRYPT error";
    }
    else if (nRc == 0x82000006)
    {
        ret_msg = "Error code: 0x82000006 Info: CRYPTO_PKCS7_DECRYPT_FAIL: Crypto DECRYPT error";
    }
    else if (nRc == 0x82000026)
    {
        ret_msg = "Error code: 0x82000026 Info: Document parsing error (X509_NAME_get_index_by_NID error)";
    }
    else if (nRc == 0x82000011)
    {
        ret_msg = "Error code: 0x82000011 Info: Time format conversion error";
    }
    else if (nRc == 0x82000021)
    {
        ret_msg = "Error code: 0x82000021 Info: The Token driver library could not be found";
    }
    else if (nRc == 0x82000022)
    {
        ret_msg = "Error code: 0x82000022 Info: An X509_REQ_sign error occurred during the CSR generation";
    }
    else if (nRc == 0x82000023)
    {
        ret_msg = "Error code: 0x82000023 Info: Found that the key was not found when checking the CSR content";
    }
    else if (nRc == 0x82000024)
    {
        ret_msg = "Error code: 0x82000024 Info: Found X509_REQ_verify error when checking CSR content";
    }
    else if (nRc == 0x82000025)
    {
        ret_msg = "Error code: 0x82000025 Info: certificate content read error (X509_NAME_print_ex error)";
    }
    else if (nRc == 0x82000026)
    {
        ret_msg = "Error code: 0x82000026 Info: Document parsing error (X509_NAME_get_index_by_NID error)";
    }
    else if (nRc == 0x82000031)
    {
        ret_msg = "Error code: 0x82000031 Info: A specific object could not be found in the Token";
    }
    else if (nRc == 0x82000032)
    {
        ret_msg = "Error code: 0x82000032 Info: A specific CN could not be found in the Token";
    }
    else if (nRc == 0x81000001)
    { /*0x81 begins with the error code defined by the component */
        ret_msg = "Error code: 0x81000001 Info: User cancels operation";
    }
    else if (nRc == 0x81000002)
    {
        ret_msg = "Error code: 0x81000002 Info: Token password not entered";
    }
    else if (nRc == 0x81000003)
    {
        ret_msg = "Error code: 0x81000003 Info: no graphic identification code entered";
    }
    else if (nRc == 0x81000004)
    {
        ret_msg = "Error code: 0x81000004 Info: Graphic ID input error";
    }
    else if (nRc == 0x81000005)
    {
        ret_msg = "Error code: 0x81000005 Info: Dynamic keyboard determines key input error";
    }
    else if (nRc == 0x81000006)
    {
        ret_msg = "Error code: 0x81000006 Info: Entering a new password does not match the new password again";
    }
    else if (nRc == 0x81000007)
    {
        ret_msg = "Error code: 0x81000007 Info: The insertion and removal of the Token has not been performed within the specified time";
    }
    else if (nRc == 0x81000008)
    {
        ret_msg = "Error code: 0x81000008 Info: Use for non-legal domains";
    }
    else if (nRc == 0x81000009)
    {
        ret_msg = "Error code: 0x81000009 Info: The Token driver library could not be found";
    }
    else if (nRc == 0x8100000A)
    {
        ret_msg = "Error code: 0x8100000A Info: Token not found";
    }
    else if (nRc == 0x8100000B)
    {
        ret_msg = "Error code: 0x8100000B Info: The certificate does not exist or the user has not clicked";
    }
    else if (nRc == 0x8100000C)
    {
        ret_msg = "Error code: 0x8100000C Info: No key exists in the Token";
    }
    else if (nRc == 0x8100000D)
    {
        ret_msg = "Error code: 0x8100000D Info: The certificate has an error";
    }
    else if (nRc == 0x8100000E)
    {
        ret_msg = "Error code: 0x8100000E Info: The key corresponding to the certificate could not be found";
    }
    else if (nRc == 0x8100000F)
    {
        ret_msg = "Error code: 0x8100000F Info: Object (key and credential) not found in the Token";
    }
    else if (nRc == 0x81000010)
    {
        ret_msg = "Error code: 0x81000010 Info: Signature output data error (length = 0)";
    }
    else if (nRc == 0x81000011)
    {
        ret_msg = "Error code: 0x81000011 Info: Reject duplicate write credentials";
    }
    else if (nRc == 0x81000012)
    {
        ret_msg = "Error code: 0x81000012 Info: Token Session failed to open";
    }
    else if (nRc == 0x81000013)
    {
        ret_msg = "Error code: 0x81000013 Info: Failed to read the Token information";
    }
    else if (nRc == 0x81000014)
    {
        ret_msg = "Error code: 0x81000014 Info: The new PIN code is not composed of numbers";
    }
    else if (nRc == 0x81000015)
    {
        ret_msg = "Error code: 0x81000015 Info: The new PIN code is not 6~12 yards";
    }
    else if (nRc == 0x84000017)
    {
        ret_msg = "Error code: 0x81000017 Info: Component encryption and decryption exception";
    }
    else if (nRc == 0x84000018)
    {
        ret_msg = "Error code: 0x81000018 Info: Component encryption and decryption exception";
    }
    else if (nRc == 0x84000019)
    {
        ret_msg = "Error code: 0x81000019 Info: Component encryption and decryption exception";
    }
    else if (nRc == 0x8400001A)
    {
        ret_msg = "Error code: 0x8100001A Info: Component encryption and decryption exception";
    }
    else if (nRc == 0x8400001F)
    {
        ret_msg = "Error code: 0x8100001F Info: Component memory error";
    }
    else if (nRc == 0x81000100)
    {
        ret_msg = "Error code: 0x81000100 Info: Cannot find Cilent IP information";
    }
    else if (nRc == 0x81000101)
    {
        ret_msg = "Error code: 0x81000101 Info: Cilent side MAC information could not be found";
    }
    else if (nRc == 0x81000102)
    {
        ret_msg = "Error code: 0x81000102 Info: An error occurred in the MIME Encode procedure";
    }
    else if (nRc == 0x81000103)
    {
        ret_msg = "Error code: 0x81000103 Info: An error occurred while MIME Encode attach file";
    }
    else if (nRc == 0x81000104)
    {
        ret_msg = "Error code: 0x81000104 Info: Registration file data type error";
    }
    else if (nRc == 0x00000000)
    {
        ret_msg = "Error code: 0x00000000 Info: CKR_OK: Function executed successfully";
    }
    else if (nRc == 0x00000001)
    {
        ret_msg = "Error code: 0x00000001 Info: CKR_CANCEL: The function terminated abnormally";
    }
    else if (nRc == 0x00000002)
    {
        ret_msg = "Error code: 0x00000002 Info: CKR_HOST_MEMORY: Memory configuration failed";
    }
    else if (nRc == 0x00000003)
    {
        ret_msg = "Error code: 0x00000003 Info: CKR_SLOT_ID_INVALID: The specified slot ID is invalid";
    }
    else if (nRc == 0x00000005)
    {
        ret_msg = "Error code: 0x00000005 Info: CKR_GENERAL_ERROR: An unrecoverable error was encountered";
    }
    else if (nRc == 0x00000006)
    {
        ret_msg = "Error code: 0x00000006 Info: CKR_FUNCTION_FAILED: The requested function could not be executed";
    }
    else if (nRc == 0x00000007)
    {
        ret_msg = "Error code: 0x00000007 Info: CKR_ARGUMENTS_BAD: Input parameter error";
    }
    else if (nRc == 0x00000020)
    {
        ret_msg = "Error code: 0x00000020 Info: CKR_DATA_INVALID: The plaintext input data for the encryption operation is invalid";
    }
    else if (nRc == 0x00000021)
    {
        ret_msg = "Error code: 0x00000021 Info: CKR_DATA_LEN_RANGE: The plaintext input data length of the encryption operation is incorrect";
    }
    else if (nRc == 0x00000030)
    {
        ret_msg = "Error code: 0x00000030 Info: CKR_DEVICE_ERROR: Token exception";
    }
    else if (nRc == 0x00000031)
    {
        ret_msg = "Error code: 0x00000031 Info: CKR_DEVICE_MEMORY: The carrier does not have enough memory space";
    }
    else if (nRc == 0x00000032)
    {
        ret_msg = "Error code: 0x00000032 Info: CKR_DEVICE_REMOVED: The Token was removed during the execution of the function";
    }
    else if (nRc == 0x00000040)
    {
        ret_msg = "Error code: 0x00000040 Info: CKR_ENCRYPTED_DATA_INVALID: The encrypted input of the decryption operation is invalid ciphertext";
    }
    else if (nRc == 0x00000041)
    {
        ret_msg = "Error code: 0x00000041 Info: CKR_ENCRYPTED_DATA_LEN_RANGE: The encryption input length of the decryption operation is incorrect and becomes invalid ciphertext";
    }
    else if (nRc == 0x00000050)
    {
        ret_msg = "Error code: 0x00000050 Info: CKR_FUNCTION_CANCELED: The function was canceled during execution";
    }
    else if (nRc == 0x00000051)
    {
        ret_msg = "Error code: 0x00000051 Info: CKR_FUNCTION_NOT_PARALLEL: There is no function to execute in parallel in the specified session";
    }
    else if (nRc == 0x00000054)
    {
        ret_msg = "Error code: 0x00000054 Info: CKR_FUNCTION_NOT_SUPPORTED: The Cryptoki library does not support the request function";
    }
    else if (nRc == 0x00000060)
    {
        ret_msg = "Error code: 0x00000060 Info: CKR_KEY_HANDLE_INVALID: The specified key handle is invalid";
    }
    else if (nRc == 0x00000062)
    {
        ret_msg = "Error code: 0x00000062 Info: CKR_KEY_SIZE_RANGE: Although the request key encryption operation can be performed in principle, the Cryptoki library does not actually complete because the size of the supplied key exceeds the density it can manage. Range of key sizes";
    }
    else if (nRc == 0x00000063)
    {
        ret_msg = "Error code: 0x00000063 Info: CKR_KEY_TYPE_INCONSISTENT: The specified key is not the correct type of key used with the specified mechanism";
    }
    else if (nRc == 0x00000082)
    {
        ret_msg = "Error code: 0x00000082 Info: CKR_OBJECT_HANDLE_INVALID: Object handle is invalid";
    }
    else if (nRc == 0x000000A0)
    {
        ret_msg = "Error code: 0x000000A0 Info: CKR_PIN_INCORRECT: Password verification failed";
    }
    else if (nRc == 0x000000A1)
    {
        ret_msg = "Error code: 0x000000A1 Info: CKR_PIN_INVALID: The entered PIN code contains invalid characters or does not match the password strength setting";
    }
    else if (nRc == 0x000000A2)
    {
        ret_msg = "Error code: 0x000000A2 Info: CKR_PIN_LEN_RANGE: The entered PIN code is too long or too short";
    }
    else if (nRc == 0x000000A3)
    {
        ret_msg = "Error code: 0x000000A3 Info: CKR_PIN_EXPIRED: Token PIN expired";
    }
    else if (nRc == 0x000000A4)
    {
        ret_msg = "Error code: 0x000000A4 Info: CKR_PIN_LOCKED: Token PIN lock";
    }
    else if (nRc == 0x000000B0)
    {
        ret_msg = "Error code: 0x000000B0 Info: CKR_SESSION_CLOSED: Session is closed during function execution";
    }
    else if (nRc == 0x000000B1)
    {
        ret_msg = "Error code: 0x000000B1 Info: CKR_SESSION_COUNT: Session failed to start because the carrier has too many Sessions enabled";
    }
    else if (nRc == 0x000000B3)
    {
        ret_msg = "Error code: 0x000000B3 Info: CKR_SESSION_HANDLE_INVALID: Session handle is invalid";
    }
    else if (nRc == 0x000000B4)
    {
        ret_msg = "Error code: 0x000000B4 Info: CKR_SESSION_PARALLEL_NOT_SUPPORTED: The carrier does not support parallel sessions";
    }
    else if (nRc == 0x000000B5)
    {
        ret_msg = "Error code: 0x000000B5 Info: CKR_SESSION_READ_ONLY: Session is read-only and therefore cannot perform the desired execution action";
    }
    else if (nRc == 0x000000B6)
    {
        ret_msg = "Error code: 0x000000B6 Info: CKR_SESSION_EXISTS: Session is already open so the Token cannot be initialized";
    }
    else if (nRc == 0x000000B7)
    {
        ret_msg = "Error code: 0x000000B7 Info: CKR_SESSION_READ_ONLY_EXISTS: The read-only session already exists so the SO cannot log in";
    }
    else if (nRc == 0x000000B8)
    {
        ret_msg = "Error code: 0x000000B8 Info: CKR_SESSION_READ_WRITE_SO_EXISTS: The read-write SO Session already exists, so the read-only Session cannot be opened";
    }
    else if (nRc == 0x000000C0)
    {
        ret_msg = "Error code: 0x000000C0 Info: CKR_SIGNATURE_INVALID: Invalid signature";
    }
    else if (nRc == 0x000000C1)
    {
        ret_msg = "Error code: 0x000000C1 Info: CKR_SIGNATURE_LEN_RANGE: The signature length is incorrect and becomes invalid signature";
    }
    else if (nRc == 0x000000E0)
    {
        ret_msg = "Error code: 0x000000E0 Info: CKR_TOKEN_NOT_PRESENT: Token does not exist";
    }
    else if (nRc == 0x000000E1)
    {
        ret_msg = "Error code: 0x000000E1 Info: CKR_TOKEN_NOT_RECOGNIZED: The Cryptoki library or slot does not recognize the carrier";
    }
    else if (nRc == 0x000000E2)
    {
        ret_msg = "Error code: 0x000000E2 Info: CKR_TOKEN_WRITE_PROTECTED: The action with write protection is prevented, so the requested action cannot be performed";
    }
    else if (nRc == 0x00000100)
    {
        ret_msg = "Error code: 0x00000100 Info: CKR_USER_ALREADY_LOGGED_IN: The user has logged in and cannot allow repeated logins";
    }
    else if (nRc == 0x00000101)
    {
        ret_msg = "Error code: 0x00000101 Info: CKR_USER_NOT_LOGGED_IN: User not logged in";
    }
    else if (nRc == 0x00000102)
    {
        ret_msg = "Error code: 0x00000102 Info: CKR_USER_PIN_NOT_INITIALIZED: The PIN has not been initialized";
    }
    else if (nRc == 0x00000103)
    {
        ret_msg = "Error code: 0x00000103 Info: CKR_USER_TYPE_INVALID: Invalid consumer type (valid type is CKU_SO/CKU_USER)";
    }
    else if (nRc == 0x00000104)
    {
        ret_msg = "Error code: 0x00000104 Info: CKR_USER_ANOTHER_ALREADY_LOGGED_IN: There are already other users logging in through the same application, so login is no longer allowed";
    }
    else if (nRc == 0x00000105)
    {
        ret_msg = "Error code: 0x00000105 Info: CKR_USER_TOO_MANY_TYPES: There are already other users logging in through another application, so logins are no longer allowed";
    }
    else if (nRc == 0x00000150)
    {
        ret_msg = "Error code: 0x00000150 Info: CKR_BUFFER_TOO_SMALL: insufficient buffer";
    }
    else if (nRc == 0x00000190)
    {
        ret_msg = "Error code: 0x00000190 Info: CKR_CRYPTOKI_NOT_INITIALIZED: The Cryptoki library is not initialized and the function cannot be executed";
    }
    else if (nRc < 0x81000000)
    {
        ret_msg = "Error code:" + "0x" + parseInt(nRc, 10).toString(16) + " Info: PKCS#11 error";
    }
    //end region need fox to check
    else if (nRc == 0x81000200)
    {
        ret_msg = "Error code: 0x81000200 Info: Connection error during transaction: There is a problem connecting to the host";
    }
    else if (nRc == 0x81000201)
    {
        ret_msg = "Error code: 0x81000201 Info: Connection error during transaction: Receive host response message timeout";
    }
    else if (nRc == 0x81000202)
    {
        ret_msg = "Error code: 0x81000202 Info: Connection error during transaction: The host response data message format is incorrect";
    }
    else if (nRc == 0x81000203)
    {
        ret_msg = "Error code: 0x81000203 Info: Connection error during transaction: Host no response message";
    }
    else if (nRc == 0x81000300)
    {
        ret_msg = "Error code: 0x81000300 Info: The local end time is abnormal";
    }
    else if (nRc == 0x81000301)
    {
        ret_msg = "Error code: 0x81000301 Info: Component initialization connection timeout";
    }
    else if (nRc == 0x81000302)
    {
        ret_msg = "Error code: 0x81000302 Info: Component initialization failed.";
    }
    else if (nRc == 0x81000303)
    {
        ret_msg = "Error code: 0x81000303 Info: Component parsing json failed";
    }
    else if (nRc == 0x81000304)
    {
        ret_msg = "Error code: 0x81000304 Info: Component call method is abnormal";
    }
    else if (nRc == 0x81000305)
    {
        ret_msg = "Error code: 0x81000305 Info: Component json parameter error";
    }
    else if (nRc == 0x81000306)
    {
        ret_msg = "Error code: 0x81000306 Info: Component json parameter error";
    }
    else if (nRc == 0x81000307)
    {
        ret_msg = "Error code: 0x81000307 Info: Component call method is abnormal";
    }
    else if (nRc == 0x81000308)
    {
        ret_msg = "Error code: 0x81000308 Info: UCTTime error";
    }
    else if (nRc == 0x81000309)
    {
        ret_msg = "Error code: 0x81000309 Info: Component exception";
    }
    else if (nRc == 0x82100001)
    {
        ret_msg = "Error code: 0x82100001 Info: Unauthorized website";
    }
    else if (nRc == 0x82100002)
    {
        ret_msg = "Error code: 0x82100002 Info: Wrong connection path";
    }
    else if (nRc == 0x82100003)
    {
        ret_msg = "Error code: 0x82100003 Info: The demand instruction is incorrect";
    }
    else if (nRc == 0x82100021)
    {
        ret_msg = "Error code: 0x82100021 Info: AcquireContextError";
    }
    else if (nRc == 0x82100022)
    {
        ret_msg = "Error code: 0x82100022 Info: ReleaseContextError";
    }
    else if (nRc == 0x82100023)
    {
        ret_msg = "Error code: 0x82100023 Info: GenKeyError";
    }
    else if (nRc == 0x82100024)
    {
        ret_msg = "Error code: 0x82100024 Info: DestroyKeyError";
    }
    else if (nRc == 0x82100025)
    {
        ret_msg = "Error code: 0x82100025 Info: GetUserKeyError";
    }
    else if (nRc == 0x82100026)
    {
        ret_msg = "Error code: 0x82100026 Info: CryptExportKeyError";
    }
    else if (nRc == 0x82100027)
    {
        ret_msg = "Error code: 0x82100027 Info: SetKeyParamError";
    }
    else if (nRc == 0x82100028)
    {
        ret_msg = "Error code: 0x82100028 Info: GetKeyParamError";
    }
    else if (nRc == 0x82100029)
    {
        ret_msg = "Error code: 0x82100029 Info: SetProvParamError";
    }
    else if (nRc == 0x82100030)
    {
        ret_msg = "Error code: 0x82100030 Info: CreateHashError";
    }
    else if (nRc == 0x82100031)
    {
        ret_msg = "Error code: 0x82100031 Info: HashDataError";
    }
    else if (nRc == 0x82100032)
    {
        ret_msg = "Error code: 0x82100032 Info: CryptSignHashError";
    }
    else if (nRc == 0x82100033)
    {
        ret_msg = "Error code: 0x82100033 Info: CryptMallocError";
    }
    else if (nRc == 0x82100034)
    {
        ret_msg = "Error code: 0x82100034 Info: DestroyHashError";
    }
    else if (nRc == 0x82100035)
    {
        ret_msg = "Error code: 0x82100035 Info: CryptGetProvParamError";
    }
    else if (nRc == 0x81000020)
    {
        ret_msg = "Error code: 0x81000020 Info: RawSign signature error";
    }
    else if (nRc == 0x81000021)
    {
        ret_msg = "Error code: 0x81000021 Info: RawSign signature verification error";
    }
    else if (nRc == 0x81000024)
    {
        ret_msg = "Error code: 0x81000024 Info: digest Info is too large";
    }
    else if (nRc == 0x81000025)
    {
        ret_msg = "Error code: 0x81000025 Info: P1 signature error";
    }
    else if (nRc == 0x81000026)
    {
        ret_msg = "Error code: 0x81000026 Info: P1 signature verification error";
    }
    else if (nRc == 0x82000033)
    {
        ret_msg = "Error code: 0x82000033 Info: digest Info is too large";
    }
    else if (nRc == 0x82000034)
    {
        ret_msg = "Error code: 0x82000034 Info: P1 signature error";
    }
    else if (nRc == 0x82000100)
    {
        ret_msg = "Error code: 0x82000100 Info: LOAD_PKCS11LIB_ERROR";
    }
    else if (nRc == 0x82000101)
    {
        ret_msg = "Error code: 0x82000101 Info: READER_NOT_SELECT_ERROR";
    }
    else if (nRc == 0x82000102)
    {
        ret_msg = "Error code: 0x82000102 Info: USER_TYPE_ERROR";
    }
    else if (nRc == 0x82000103)
    {
        ret_msg = "Error code: 0x82000103 Info: OBJECT_NUMBER_ERROR";
    }
    else if (nRc == 0x82000104)
    {
        ret_msg = "Error code: 0x82000104 Info: KEYID_NOT_DEFINED_ERROR";
    }
    else if (nRc == 0x82000105)
    {
        ret_msg = "Error code: 0x82000105 Info: KEYSIZE_NOT_DEFIND_EERROR";
    }
    else if (nRc == 0x82000106)
    {
        ret_msg = "Error code: 0x82000106 Info: SELECT_CARDID_ERROR";
    }
    else if (nRc == 0x82000107)
    {
        ret_msg = "Error code: 0x82000107 Info: UNSUPPROT_PINTYPE";
    }
    else if (nRc == 0x82000108)
    {
        ret_msg = "Error code: 0x82000108 Info: NULL_PINNUMBER";
    }
    else if (nRc == 0x82000109)
    {
        ret_msg = "Error code: 0x82000109 Info: TOKEN_NOT_PRESENT";
    }
    else if (nRc == 0x8200010A)
    {
        ret_msg = "Error code: 0x8200010A Info: NOT_BSTRTYPE";
    }
    else if (nRc == 0x8200010B)
    {
        ret_msg = "Error code: 0x8200010B Info: DECODE_BASE64_ERROR";
    }
    else if (nRc == 0x8200010C)
    {
        ret_msg = "Error code: 0x8200010C Info: TOKEN_UNSUPPORTED_FUNCTION";
    }
    else if (nRc == 0x8200010D)
    {
        ret_msg = "Error code: 0x8200010D Info: EMPTY_CHALLENGE_CDOE";
    }
    else if (nRc == 0x8200010E)
    {
        ret_msg = "Error code: 0x8200010E Info: NOT_VALID_HEXSTRING_FORMAT";
    }
    else if (nRc == 0x8200010E)
    {
        ret_msg = "Error code: 0x8200010E Info: NOT_VALID_HEXSTRING_FORMAT";
    }
    else if (nRc == 0x8200010F)
    {
        ret_msg = "Error code: 0x8200010F Info: EMPTY_OBJECT_VALUE";
    }
    else if (nRc == 0x82000110)
    {
        ret_msg = "Error code: 0x82000110 Info: EMPTY_USER_PIN";
    }
    else if (nRc == 0x82000111)
    {
        ret_msg = "Error code: 0x82000111 Info: WRONG_MESSAGE_FORMAT";
    }
    else if (nRc == 0x82000112)
    {
        ret_msg = "Error code: 0x82000112 Info: WRONG_SOPIN_GEN_DATE";
    }
    else if (nRc == 0x82000113)
    {
        ret_msg = "Error code: 0x82000113 Info: DECRYPT_DATA_FAIL";
    }
    else if ((nRc >= 0x81100001) && (nRc <= 0x81100006))
    {
        /*var tempDec = nRc;
        var tempDec2 = 0x81200000;
        var errorcode = parseInt(tempDec - tempDec2, 10).toString(16);

        ret_msg = "Error code:" + "0x" + parseInt(nRc, 10).toString(16) + " Info: An error occurred in the transaction. Error code: " + "0x" + errorcode;*/
    	if (nRc == 0x81100001) { /* 0x811開頭為元件定義: 上傳資料後，OpMode=EXEC連線回應的RETURNCODE值加上元件自定義值0x81100000，詳細錯誤需查閱property: ERRORCODE */
    		ret_msg = data.errMsg;
	    } else if (nRc == 0x81100002) {
	        errorCode = getErrorCode(data.errMsg, 'ERRORCODE');
	    	
	        if (errorCode == "015") {
	            ret_msg = "Error Code:CA-Server 015  Info:Verify Client Data Error, please make sure you have the right certificate";
	        } else if (errorCode == "018") {
	            ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
	        } else if (errorCode == "019") {
	        	ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
	        } else if (errorCode == "026") {
	        	ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
	        } else {
	            ret_msg = "Error Code:CA-Server " + errorCode + "  Info:System error, please contact support";
	        }
	    } else if (nRc == 0x81100003) {
	        errorCode = getErrorCode(data.errMsg, 'ERRORCODE');
	        ret_msg = "Error Code:CA-Server " + errorCode + "  Info:System error, please contact support";
	    } else if (nRc == 0x81100004) {
	        ret_msg = ParseErrorMessage(data.errMsg, 'DETAIL');
	    } else if (nRc == 0x81100005) {
	    	ret_msg = data.errMsg;
	    } else if (nRc == 0x81100006) {
	    	ret_msg = data.errMsg;
	    }
    }
    else if ((nRc >= 0x81200001) && (nRc <= 0x812FFFFF))
    {
        var tempDec = nRc;
        var tempDec2 = 0x81200000;
        var errorcode = parseInt(tempDec - tempDec2, 10).toString(16);

        ret_msg = "Error code:" + "0x" + parseInt(nRc, 10).toString(16) + " Info: Access Windows Registry error. Error code: " + "0x" + errorcode;
    }
    else
    {
        ret_msg = "0x" + parseInt(nRc, 10).toString(16);
    }
    return ret_msg;
}

function getErrorCode(errMsg, name) {
    var vars = errMsg.split("&&");
    var varStr = '';
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == name) {
            varStr = pair[1];
        }
    }
    return varStr;
}

function ParseErrorMessage(errMsg, name) {
    var vars = errMsg.split("&&");
    var varStr = '';
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == name) {
            var rep = pair[1].replace(/\\u/g, "||");
            rep = rep.toUpperCase();
            var varArr = rep.split("||");
            for (var j = 1; j < varArr.length; j++) {
                var uni = '"\\u' + varArr[j] + '"';
                if (/^[A-F\d]{4}$/.test(varArr[j])) {
                    varStr = varStr + eval(uni);
                }
            }
            return varStr;
        }
    }
    alert('Query Variable ' + name + ' not found');
}