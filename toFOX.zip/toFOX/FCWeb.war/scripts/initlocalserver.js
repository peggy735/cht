
var RSACryptPubkey = "-----BEGIN PUBLIC KEY-----MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzSWBRzvvz6DscUytlz17jpghDLcAIk57aiZJVJXTkaQNDSsp1RlDznnvfZIbgU5Uxd2T0/Ke0wCNvcNiCJu1yYWZTx6uyt+yZL+4uj43at/2NWiNwakJTM/7xJqXIJBOIodBxIYhZEtdcmvItNRK/TSHfm8iUJGodq7uEgnV0Su0qpPJXitEQR3XRxiaTpKFQkDTbL3PJeUmbdDGLD/okI3co+3zlw6tUT05WVt9/2WmFPawTC/tOF39CstzBqXaZ+xeugKxf/8Rq6fJJVgKftaB6IHIIg/5uQOIfK66cN2OnqRV3SzBqpBJLuoBTUb6JVTvu7QB86v0WvT25mVaawIDAQAB-----END PUBLIC KEY-----";
var aesKey = '2ab0ea0064f5cc77533409b1c5c3c95f1eeee1d97e09e7494bdf9acbac7715f1'; 
var strEncryptSessionkey = 'K50/qCzcnc4eOYM0Z967FYuRbQwTd2WVyFObtpH6IVPLu9ncTvl2vYF/WkiDKLsO3A8VTvl7IbCjmoReiObxjnV5LvQh7XpKZCc2YvVPWbA1DSaNICrFKNUVAmxi3vXUB/yXFLt8pqCupZAboEQ2kvk9sKEy9L/Q8BU1D37319o/uHHWezSV/Va8WbfsM8xK0HHeGNaGWCqo+/pQgavKmT3yBD14aPRe4y5TrVF2Wj0pcSYxZrpSDnbaRKcEAu7A0gPEoCjoPp2zOUK5I6C4wKXGuO7s574Rt4xyk0YoL0wpd8zPvXLDl8AHuHtEwV0Zmh/w/TGBIRhj6iGTfw0pww==';
var localServer_UUID = "b44199a9-51ea-48b0-b3b8-0c8a6620745a";
var aesIv = '';
// local server status
var pluginVersion = '';
var initConnectSuccess = false;

var pluginPorts = ['16016', '16017', '16018', '16019', '16020'];
var pluginPortIndex = 0;

// RA web info
//var RAWEBurl = 'http://192.168.33.24:7003';
var RAWEBurl = "http://172.20.10.2:9003";
var formName = 'frmmain';
var ServletPathESECURE = RAWEBurl + '/RAWeb/dealTransEx.do';

var base64EncodeChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
var base64DecodeChars = new Array(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63,
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);

function getCertServerUrl() {
    return 'https://localhost:' + pluginPorts[pluginPortIndex] + '/CHTCertTokenServer/';
}

function load(callbackFunction) {
	$.blockUI({ fadeIn: 0 });
    doRSAEncrypt();
    initPort({
        onSuccess: function (responseText) {
            try {
                if (responseText) {
                    var data = JSON.parse(responseText);
                    if (data.uuid != localServer_UUID) { //非綁定localServer，因此仍要繼續掃port
                        return -1;
                    }
                    if (data.ret == 0x0) { //網頁連線成功後，自動執行initConnect
                        //alert('Plugin Port:' + pluginPorts[pluginPortIndex]);
                       // $.unblockUI();
                        initConnect(callbackFunction);
						
                        return 0;
                    } else {
                        ShowErrorMessage(data.ret);
                        $.unblockUI();
                        return 0;
                    }
                } else {
                    //alert('responseText is empty');
                    return -1;
                }
            } catch (err) { //使用IE，如果port被其他程式佔去，可能會回404，因此仍要繼續掃port
                return -1;
            }

            $.unblockUI();
        },
        onError: function (errMsg) {
            alert(errMsg);
            $.unblockUI();
			
			//Larry 1080117
			window.location.href="./Envdownload.jsp";
        }
    });
}

function initPort(callbacks) {
    callbacks = callbacks || {};
    var onSuccessCallback = callbacks.onSuccess || function () { };
    var onErrorCallback = callbacks.onError || function () { };
    var result;

    $.blockUI({ fadeIn: 0 });

    //Larry 1080117
    if (pluginPortIndex == pluginPorts.length) {
		alert("請先安裝新版CTBC網銀交易元件");
        
        result = 0;
    }

    sendHttpRequest(getCertServerUrl() + 'checkport', 'POST', '', {
        onSuccess: function (responseText) {
            result = onSuccessCallback(responseText);
            if (result != 0) {
                pluginPortIndex++;
                initPort(callbacks);
            }
        },
        onError: function () {
            pluginPortIndex++;
            initPort(callbacks);
        }
    }, false);
}

//若需更新sessionkey，須再執行一次initConnect
function initConnect(callbackFunction) {
    $.blockUI({ fadeIn: 0 });
    var request = {
        func: 'initConnect',
        strInitData: strEncryptSessionkey
    };

    sendHttpRequest(getCertServerUrl(), 'POST', JSON.stringify(request), {
        onSuccess: function (responseText) {
            if (responseText) {
                var data = JSON.parse(responseText);
                if (data.ret == 0x0) { //連線初始化成功
                    initConnectSuccess = true;
					callbackFunction();
					//alert("連線成功");
                } else {
                    ShowErrorMessage(data.ret);
                }
            }

            $.unblockUI();
        }
    }, false);
}

function doRSAEncrypt(cipherText) {
    var encrypt = new JSEncrypt();
    encrypt.setPublicKey(RSACryptPubkey);
    var encrypted = encrypt.encrypt(aesKey);
    strEncryptSessionkey = encrypted;
}

function doAESEncrypt(plainText) {
    var key = CryptoJS_LSR.enc.Hex.parse(aesKey);
    aesIv = "8be168d2e0071f67ed6f30127f5998d2";
    var iv = CryptoJS_LSR.enc.Hex.parse(aesIv);
    var encrypted = CryptoJS_LSR.AES.encrypt(plainText, key, { iv: iv });
    return encrypted;
}

function doAESDecrypt(cipherText) {
    var key = CryptoJS_LSR.enc.Hex.parse(aesKey);
    aesIv = "8be168d2e0071f67ed6f30127f5998d2";
    var iv = CryptoJS_LSR.enc.Hex.parse(aesIv);
    var decrypted = CryptoJS_LSR.AES.decrypt(cipherText, key, { iv: iv });
    return decrypted.toString(CryptoJS_LSR.enc.Utf8);
}

function sendHttpRequest(url, action, sendStr, callbacks, shouldEncrypt) {
    callbacks = callbacks || {};
    var onSuccessCallback = callbacks.onSuccess || function () { };
    var onErrorCallback = callbacks.onError || function () { };
    var xmlhttp = new XMLHttpRequest();
    try {
        xmlhttp.open(action, url, true);
        //跨瀏覽器元件掃port需要設定timeout
        //避免使用者有個localhost剛剛好用了同個port同個path 過了十分鐘才return response
        if (url.indexOf('checkport') !== -1) {
            xmlhttp.timeout = 5000;
        }
        xmlhttp.onload = function () {
            var responseText = xmlhttp.responseText;
            if (shouldEncrypt) {
                var data = JSON.parse(responseText);
                console.log(data);
                var nRc = data.ret;
                if (nRc == 0x0) {
                    responseText = doAESDecrypt(data.content);
                    onSuccessCallback(responseText);
                } else {
                    onErrorCallback(data.ret, data);
                  //  $.unblockUI();
                }
            } else {
                onSuccessCallback(responseText);
            }
        };

        xmlhttp.onerror = function () {
            onErrorCallback();
        };

        if (shouldEncrypt) {
            var cipherText = doAESEncrypt(sendStr);
            sendStr = "{\"func\":\"Connected\",\"content\":\"" + cipherText + "\"}";
        }

        xmlhttp.send(sendStr);
    } catch (err) {
        //處理localServer http連線錯誤狀況
        if (!xmlhttp && typeof xmlhttp != "undefined" && xmlhttp != 0) {
            alert("readyState:" + xmlhttp.readyState + ",status:" + xmlhttp.status + ",err:" + err.message);
        } else {
            //alert("err:" + err.message);
        }

         $.unblockUI();
    }
}

function ShowErrorMessage(nRc, data) {
    alert(errorCode2Message(nRc, data));
}
function sendHttpRequest2(url, action, sendStr, shouldEncrypt) {

    var xmlhttp = new XMLHttpRequest();
    try {
        xmlhttp.open(action, url, false);
        //跨瀏覽器元件掃port需要設定timeout
        //避免使用者有個localhost剛剛好用了同個port同個path 過了十分鐘才return response
        if (url.indexOf('checkport') !== -1) {
            xmlhttp.timeout = 5000;
        }
        xmlhttp.onload = function () {
            var responseText = xmlhttp.responseText;
                var data = JSON.parse(responseText);
                var nRc = data.ret;
                if (nRc == 0x0) {
                    responseText = doAESDecrypt(data.content);
					   if (responseText != "") {
                        var data = JSON.parse(responseText);
                        var nRc = data.ret;
                        if (nRc == 0x0) {
                            DSCert = data.strB64PKCS10;
							document.getElementById("CSRB64Value").value=DSCert;
                        } else {
                            SubmitErrorMessage(nRc, data);
                        }
                    } 
				
                } else {
                 SubmitErrorMessage(nRc, data);
                }
           
        };

        xmlhttp.onerror = function () {
            sendHttpRequestRetry(url, action, sendStr, callbacks, shouldEncrypt);
            //onErrorCallback();
        };

        if (shouldEncrypt) {
            var cipherText = doAESEncrypt(sendStr);
            sendStr = "{\"func\":\"Connected\",\"content\":\"" + cipherText + "\"}";
        }

        xmlhttp.send(sendStr);
    } catch (err) {
        //處理localServer http連線錯誤狀況
        if (!xmlhttp && typeof xmlhttp != "undefined" && xmlhttp != 0) {
            alert("readyState:" + xmlhttp.readyState + ",status:" + xmlhttp.status + ",err:" + err.message);
        } else {
            alert("err:" + err.message);
        }

        $.unblockUI();
    }
}


function sendHttpRequestRetry(url, action, sendStr, callbacks, shouldEncrypt) {
    callbacks = callbacks || {};
    var onSuccessCallback = callbacks.onSuccess || function () { };
    var onErrorCallback = callbacks.onError || function () { };
    var xmlhttp = new XMLHttpRequest();
    try {
        xmlhttp.open(action, url, true);
        //跨瀏覽器元件掃port需要設定timeout
        //避免使用者有個localhost剛剛好用了同個port同個path 過了十分鐘才return response
        if (url.indexOf('checkport') !== -1) {
            xmlhttp.timeout = 5000;
        }
        xmlhttp.onload = function () {
            var responseText = xmlhttp.responseText;
            if (shouldEncrypt) {
                var data = JSON.parse(responseText);
                var nRc = data.ret;
                if (nRc == 0x0) {
                    responseText = doAESDecrypt(data.content);
                    onSuccessCallback(responseText);
                } else {
                    onErrorCallback(data.ret, data);
                }
            } else {
                onSuccessCallback(responseText);
            }
        };

        xmlhttp.onerror = function () {
            onErrorCallback();
        };

        if (shouldEncrypt) {
            var cipherText = doAESEncrypt(sendStr);
            sendStr = "{\"func\":\"Connected\",\"content\":\"" + cipherText + "\"}";
        }

        xmlhttp.send(sendStr);
    } catch (err) {
        //處理localServer http連線錯誤狀況
        if (!xmlhttp && typeof xmlhttp != "undefined" && xmlhttp != 0) {
            alert("readyState:" + xmlhttp.readyState + ",status:" + xmlhttp.status + ",err:" + err.message);
        } else {
            alert("err:" + err.message);
        }

        $.unblockUI();
    }
}

function determineLanguage() {
	var lang = document.getElementById('language').value;
	if (lang == "zh_TW") {
		lang = 1;
	} else if (lang == "zh_CN") {
		lang = 2 ;
	} else {
		lang = 0;
	}
	return lang;
}