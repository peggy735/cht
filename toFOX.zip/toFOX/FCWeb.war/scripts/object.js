//document.write("<embed type='application/x-ctcbcryptoapi' width='0' height='0' id='TokenCom' name='TokenCom'></embed>");
//document.write('<object codebase="ECOM4SP.cab#Version=2,0,0,12" classid="clsid:25243EAF-95BB-4286-8881-FAC2D0277C7D" id="SP11FileUpload_Control"></object>');
//document.write('<object id="TokenCom" type="application/x-sm2certplugin" width="0" height="0"></object>');
document.write('<object id="CTBCPKIAPI" type="application/x-sm2certplugin" width="0" height="0"></object>'); //Seek 20131220 //Seek 20140115
